package javax.microedition.rms;
public class InvalidRecordIDException extends RecordStoreException { public InvalidRecordIDException(String m){super(m);} }
