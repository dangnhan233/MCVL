# PID 2001 raw-payload instrumentation

## Change
- File: `mcvl-android/app/src/main/java/com/mcvl/android/EmbeddedLocalServer.java`
- Capture point: `writeResponse()`, before the packet's PID/length and enclosing frame are serialized.
- Filter: outgoing PID 2001 only.
- Captured bytes: exactly `Packet.data` (`p.data`), without PID, length fields, response packet count, or frame header.
- Output folder: Android app-specific external files directory `pid2001_capture`; falls back to app-private files directory if external files storage is unavailable.
- Output per packet: `.bin` raw bytes and `.txt` sidecar containing PID, error flag, byte length, capture epoch milliseconds, and SHA-256.
- Capture exceptions are logged and swallowed so capture failure does not intentionally interrupt the original response.
- No movement handler or packet payload is modified.

## Retrieve on Android
Look under `Android/data/<app-package>/files/pid2001_capture/` for the `.bin` and `.txt` files. If Android's file manager hides `Android/data`, use Android Studio Device Explorer or `adb pull` from the app-specific external files directory. Logcat tag: `MCVL_PID2001_CAPTURE`.

## Validation
Static checks confirm the capture is invoked only when `p.pid == P_MAP`, writes `p.data` as-is, and occurs before PID/length/frame serialization. The movement handler is byte-for-byte unchanged. An Android build was not run here; use the supplied `build_apk.sh` with the project's JDK/Android SDK setup.
