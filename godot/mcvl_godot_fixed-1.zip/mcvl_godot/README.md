# MCVL – Godot 4
- maps/map_XX/: tileset.png/.tres, objects/, layout.json (layout tự thiết kế), preview.png, map.tscn
- map_loader.gd: nạp layout.json -> TileMapLayer + Sprite2D (gốc ở chân vật thể)
- layout.json: width, height, ground[] (chỉ số ô), blocked[] (1 = nước), objects[{file,x,y}], spawn
- Layout KHÔNG phải bản gốc (bản gốc do server gửi). Sửa layout.json hoặc vẽ lại trong TileMapLayer.
