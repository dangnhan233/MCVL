import org.objectweb.asm.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Robust reference resolver: collects all method/field references from the game
 * classes and resolves them by parsing the class files present on the classpath
 * (directories and jars) with ASM -- no reflection, no class loading.
 *
 * usage: ResolveTool <gameDir> <cp1:cp2:...>
 */
public class ResolveTool {

    static final Map<String, ClassInfo> INDEX = new HashMap<>();

    static class ClassInfo {
        String name, superName;
        List<String> interfaces = new ArrayList<>();
        Set<String> methods = new HashSet<>();   // name+desc
        Set<String> fields = new HashSet<>();    // name+desc
    }

    public static void main(String[] args) throws Exception {
        File gameDir = new File(args[0]);
        String[] cps = args[1].split(":");
        for (String cp : cps) {
            if (cp.isEmpty()) continue;
            File f = new File(cp);
            if (f.isDirectory()) indexDir(f);
            else if (cp.endsWith(".jar")) indexJar(f);
        }
        System.out.println("indexed classes: " + INDEX.size());

        Set<String> methods = new TreeSet<>();
        Set<String> fields = new TreeSet<>();
        File[] list = gameDir.listFiles((d, n) -> n.endsWith(".class"));
        Arrays.sort(list);
        for (File f : list) {
            ClassReader cr = new ClassReader(Files.readAllBytes(f.toPath()));
            cr.accept(new ClassVisitor(Opcodes.ASM9) {
                public MethodVisitor visitMethod(int a, String n, String d, String s, String[] e) {
                    return new MethodVisitor(Opcodes.ASM9) {
                        public void visitMethodInsn(int op, String o, String mn, String md, boolean itf) {
                            if (!o.startsWith("[")) methods.add(o + "." + mn + md);
                        }
                        public void visitFieldInsn(int op, String o, String fn, String fd) {
                            fields.add(o + "." + fn + ":" + fd);
                        }
                    };
                }
            }, 0);
        }

        List<String> missing = new ArrayList<>();
        for (String m : methods) {
            int dot = m.lastIndexOf('.');
            String owner = m.substring(0, dot);
            String rest = m.substring(dot + 1);
            int par = rest.indexOf('(');
            if (!resolvesMethod(owner, rest.substring(0, par), rest.substring(par))) missing.add("METHOD " + m);
        }
        for (String f : fields) {
            int dot = f.lastIndexOf('.');
            String owner = f.substring(0, dot);
            String rest = f.substring(dot + 1);
            int col = rest.indexOf(':');
            if (!resolvesField(owner, rest.substring(0, col), rest.substring(col + 1))) missing.add("FIELD  " + f);
        }
        System.out.println("=== UNRESOLVED (" + missing.size() + ") ===");
        for (String s : missing) System.out.println(s);
    }

    static boolean resolvesMethod(String owner, String name, String desc) {
        Set<String> seen = new HashSet<>();
        Deque<String> q = new ArrayDeque<>();
        q.add(owner);
        while (!q.isEmpty()) {
            String c = q.poll();
            if (c == null || !seen.add(c)) continue;
            ClassInfo ci = INDEX.get(c);
            if (ci == null) continue;
            if (ci.methods.contains(name + desc)) return true;
            if (ci.superName != null) q.add(ci.superName);
            q.addAll(ci.interfaces);
        }
        return false;
    }

    static boolean resolvesField(String owner, String name, String desc) {
        Set<String> seen = new HashSet<>();
        Deque<String> q = new ArrayDeque<>();
        q.add(owner);
        while (!q.isEmpty()) {
            String c = q.poll();
            if (c == null || !seen.add(c)) continue;
            ClassInfo ci = INDEX.get(c);
            if (ci == null) continue;
            if (ci.fields.contains(name + desc)) return true;
            if (ci.superName != null) q.add(ci.superName);
            q.addAll(ci.interfaces);
        }
        return false;
    }

    static void indexDir(File dir) throws IOException {
        Files.walk(dir.toPath()).filter(p -> p.toString().endsWith(".class")).forEach(p -> {
            try { index(Files.readAllBytes(p)); } catch (Exception ignored) {}
        });
    }

    static void indexJar(File jar) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(jar))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                if (e.getName().endsWith(".class")) {
                    try { index(readAll(zis)); } catch (Exception ignored) {}
                }
            }
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
        return out.toByteArray();
    }

    static void index(byte[] data) {
        ClassReader cr = new ClassReader(data);
        ClassInfo ci = new ClassInfo();
        ci.name = cr.getClassName();
        ci.superName = cr.getSuperName();
        cr.accept(new ClassVisitor(Opcodes.ASM9) {
            public void visit(int v, int acc, String n, String sig, String sup, String[] itfs) {
                if (itfs != null) ci.interfaces.addAll(Arrays.asList(itfs));
            }
            public MethodVisitor visitMethod(int a, String n, String d, String s, String[] e) {
                ci.methods.add(n + d);
                return null;
            }
            public FieldVisitor visitField(int a, String n, String d, String s, Object val) {
                ci.fields.add(n + d);
                return null;
            }
        }, ClassReader.SKIP_CODE);
        INDEX.put(ci.name, ci);
    }
}
