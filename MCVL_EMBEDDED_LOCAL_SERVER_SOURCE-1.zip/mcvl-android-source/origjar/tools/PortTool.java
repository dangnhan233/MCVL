import org.objectweb.asm.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.util.*;

/**
 * Bytecode porting tool for the MCVL J2ME game.
 *
 * mode=rewrite  <inDir> <outDir>
 *     Rewrites every  Class.getResourceAsStream(String)  call into
 *     com.mcvl.game.Res.open(String)  so the ported game reads its data from
 *     the Android asset bridge instead of the JAR classpath.
 *
 * mode=verify   <gameDir> <cp1:cp2:...>
 *     Collects every method/field reference from the game classes and checks
 *     that it resolves against the given classpath (compat classes, android.jar,
 *     JDK). Prints the unresolved references.
 */
public class PortTool {

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("usage: PortTool <rewrite|verify> ...");
            System.exit(2);
        }
        if (args[0].equals("rewrite")) {
            rewrite(new File(args[1]), new File(args[2]));
        } else if (args[0].equals("verify")) {
            verify(new File(args[1]), args[2]);
        } else {
            System.err.println("unknown mode " + args[0]);
            System.exit(2);
        }
    }

    // ---------------------------------------------------------------- rewrite
    static void rewrite(File inDir, File outDir) throws IOException {
        outDir.mkdirs();
        int files = 0, rewrites = 0;
        File[] list = inDir.listFiles((d, n) -> n.endsWith(".class"));
        Arrays.sort(list);
        for (File f : list) {
            byte[] b = Files.readAllBytes(f.toPath());
            ClassReader cr = new ClassReader(b);
            ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
            final int[] cnt = {0};
            ClassVisitor cv = new ClassVisitor(Opcodes.ASM9, cw) {
                @Override
                public MethodVisitor visitMethod(int access, String name, String desc,
                                                 String sig, String[] ex) {
                    MethodVisitor mv = super.visitMethod(access, name, desc, sig, ex);
                    return new MethodVisitor(Opcodes.ASM9, mv) {
                        @Override
                        public void visitLdcInsn(Object value) {
                            if ("210.211.99.77:9001".equals(value)) {
                                super.visitLdcInsn("127.0.0.1:9001");
                            } else {
                                super.visitLdcInsn(value);
                            }
                        }

                        @Override
                        public void visitMethodInsn(int opcode, String owner, String mname,
                                                    String mdesc, boolean itf) {
                            if (opcode == Opcodes.INVOKEVIRTUAL
                                    && owner.equals("java/lang/Class")
                                    && mname.equals("getResourceAsStream")
                                    && mdesc.equals("(Ljava/lang/String;)Ljava/io/InputStream;")) {
                                // stack: [..., Class, String]  ->  [..., String]
                                // Class sits BELOW the String arg, so SWAP then POP
                                // removes the Class receiver (both are category-1 refs).
                                super.visitInsn(Opcodes.SWAP);
                                super.visitInsn(Opcodes.POP);
                                super.visitMethodInsn(Opcodes.INVOKESTATIC,
                                        "com/mcvl/game/Res", "open",
                                        "(Ljava/lang/String;)Ljava/io/InputStream;", false);
                                cnt[0]++;
                            } else {
                                super.visitMethodInsn(opcode, owner, mname, mdesc, itf);
                            }
                        }
                    };
                }
            };
            cr.accept(cv, 0);
            Files.write(new File(outDir, f.getName()).toPath(), cw.toByteArray());
            files++;
            rewrites += cnt[0];
        }
        System.out.println("rewrite: " + files + " classes, " + rewrites + " call sites rewritten");
    }

    // ---------------------------------------------------------------- verify
    static void verify(File gameDir, String cp) throws Exception {
        String[] parts = cp.split(":");
        List<URL> urls = new ArrayList<>();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            urls.add(new File(p).toURI().toURL());
        }
        URLClassLoader loader = new URLClassLoader(urls.toArray(new URL[0]),
                ClassLoader.getPlatformClassLoader());

        Set<String> methods = new TreeSet<>();
        Set<String> fields = new TreeSet<>();
        File[] list = gameDir.listFiles((d, n) -> n.endsWith(".class"));
        Arrays.sort(list);
        for (File f : list) {
            ClassReader cr = new ClassReader(Files.readAllBytes(f.toPath()));
            cr.accept(new ClassVisitor(Opcodes.ASM9) {
                @Override
                public MethodVisitor visitMethod(int a, String n, String d, String s, String[] e) {
                    return new MethodVisitor(Opcodes.ASM9) {
                        public void visitMethodInsn(int op, String o, String mn, String md, boolean itf) {
                            if (!o.startsWith("[")) methods.add(o + "." + mn + md);
                        }
                        public void visitFieldInsn(int op, String o, String fn, String fd) {
                            fields.add(o + "." + fn + ":" + fd);
                        }
                    };
                }
            }, 0);
        }

        System.out.println("referenced methods: " + methods.size() + ", fields: " + fields.size());
        List<String> missing = new ArrayList<>();
        for (String m : methods) {
            int dot = m.lastIndexOf('.');
            String owner = m.substring(0, dot);
            String rest = m.substring(dot + 1);
            int par = rest.indexOf('(');
            String name = rest.substring(0, par);
            String desc = rest.substring(par);
            if (!resolvesMethod(loader, owner, name, desc)) missing.add("METHOD " + m);
        }
        for (String f : fields) {
            int dot = f.lastIndexOf('.');
            String owner = f.substring(0, dot);
            String rest = f.substring(dot + 1);
            int col = rest.indexOf(':');
            String name = rest.substring(0, col);
            String desc = rest.substring(col + 1);
            if (!resolvesField(loader, owner, name, desc)) missing.add("FIELD  " + f);
        }
        // Filter to only report references to our compat namespaces + anything unresolved
        System.out.println("=== UNRESOLVED (" + missing.size() + ") ===");
        for (String s : missing) System.out.println(s);
    }

    static boolean resolvesMethod(ClassLoader loader, String owner, String name, String desc) {
        try {
            Class<?> c = Class.forName(owner.replace('/', '.'), false, loader);
            while (c != null) {
                for (java.lang.reflect.Method m : c.getDeclaredMethods()) {
                    if (m.getName().equals(name) && Type.getMethodDescriptor(m).equals(desc)) return true;
                }
                for (Class<?> itf : c.getInterfaces()) {
                    if (resolvesMethod(loader, Type.getInternalName(itf), name, desc)) return true;
                }
                c = c.getSuperclass();
            }
        } catch (Throwable t) {
            return false;
        }
        return false;
    }

    static boolean resolvesField(ClassLoader loader, String owner, String name, String desc) {
        try {
            Class<?> c = Class.forName(owner.replace('/', '.'), false, loader);
            while (c != null) {
                for (java.lang.reflect.Field f : c.getDeclaredFields()) {
                    if (f.getName().equals(name) && Type.getDescriptor(f.getType()).equals(desc)) return true;
                }
                for (Class<?> itf : c.getInterfaces()) {
                    if (resolvesField(loader, Type.getInternalName(itf), name, desc)) return true;
                }
                c = c.getSuperclass();
            }
        } catch (Throwable t) {
            return false;
        }
        return false;
    }
}
