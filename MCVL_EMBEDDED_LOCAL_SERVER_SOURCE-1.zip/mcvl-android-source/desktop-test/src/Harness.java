import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Method;
import java.util.Hashtable;
import javax.imageio.ImageIO;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

public class Harness {
    static volatile boolean repaint=false;
    static BufferedImage frame;
    static int frames=0;
    public static void main(String[] a) throws Exception {
        Display.setScreenSize(240,320);
        Hashtable<String,String> props=new Hashtable<String,String>();
        props.put("MIDlet-Version","2.0.3");
        MIDlet.setAppProperties(props);
        Renderer.setSink(new Renderer.Sink(){public void onRepaint(){repaint=true;}});

        Class<?> cls=Class.forName("SFMIDlet");
        MIDlet m=(MIDlet)cls.getDeclaredConstructor().newInstance();
        Method start=cls.getDeclaredMethod("startApp");
        start.setAccessible(true);
        start.invoke(m);
        System.out.println("startApp OK, current="+Display.getCurrentDisplayable());

        long end=System.currentTimeMillis()+6000;
        while(System.currentTimeMillis()<end){
            if(repaint){
                repaint=false;
                Displayable d=Display.getCurrentDisplayable();
                if(d instanceof Canvas){
                    frame=new BufferedImage(240,320,BufferedImage.TYPE_INT_RGB);
                    Graphics g=new Graphics(frame.createGraphics(),240,320,null);
                    ((Canvas)d).__paint(g);
                    frames++;
                    if(frames==1||frames==30||frames==60||frames==120||frames==200){
                        ImageIO.write(frame,"png",new File("/workspace/desktop-test/frame_"+frames+".png"));
                        System.out.println("rendered frame "+frames);
                    }
                }
            }
            Thread.sleep(5);
        }
        System.out.println("TOTAL FRAMES RENDERED: "+frames);
        if(frame!=null)ImageIO.write(frame,"png",new File("/workspace/desktop-test/frame_last.png"));
        System.out.println("DONE");
        System.exit(0);
    }
}
