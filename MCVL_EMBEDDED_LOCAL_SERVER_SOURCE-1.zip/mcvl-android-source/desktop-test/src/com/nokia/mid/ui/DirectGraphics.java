package com.nokia.mid.ui;
public interface DirectGraphics {
    int FLIP_HORIZONTAL=0x2000,FLIP_VERTICAL=0x4000;
    void setARGBColor(int c); int getAlphaComponent();
    void drawImage(javax.microedition.lcdui.Image img,int x,int y,int anchor,int manipulation);
    void drawTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c);
    void fillTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c);
    void drawPolygon(int[] x,int xo,int[] y,int yo,int n,int c);
    void fillPolygon(int[] x,int xo,int[] y,int yo,int n,int c);
}
