package com.nokia.mid.ui;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
public final class DirectUtils {
    private DirectUtils(){}
    public static DirectGraphics getDirectGraphics(Graphics g){return new Impl(g);}
    static final class Impl implements DirectGraphics {
        final Graphics g; int alpha=255;
        Impl(Graphics g){this.g=g;}
        public void setARGBColor(int c){alpha=(c>>>24)&255;g.setColor(c&0xFFFFFF);}
        public int getAlphaComponent(){return alpha;}
        public void drawImage(Image i,int x,int y,int a,int m){g.drawImage(i,x,y,a);}
        public void drawTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);
            g.drawLine(x1,y1,x2,y2);g.drawLine(x2,y2,x3,y3);g.drawLine(x3,y3,x1,y1);g.setColor(s);}
        public void fillTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);g.fillTriangle(x1,y1,x2,y2,x3,y3);g.setColor(s);}
        public void drawPolygon(int[] x,int xo,int[] y,int yo,int n,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);
            for(int i=0;i<n;i++){int j=(i+1)%n;g.drawLine(x[xo+i],y[yo+i],x[xo+j],y[yo+j]);}g.setColor(s);}
        public void fillPolygon(int[] x,int xo,int[] y,int yo,int n,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);
            for(int i=1;i<n-1;i++)g.fillTriangle(x[xo],y[yo],x[xo+i],y[yo+i],x[xo+i+1],y[yo+i+1]);g.setColor(s);}
    }
}
