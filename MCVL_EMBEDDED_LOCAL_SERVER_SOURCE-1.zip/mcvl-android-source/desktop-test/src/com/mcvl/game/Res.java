package com.mcvl.game;
import java.io.*;
public final class Res {
    public static String BASE="/workspace/mcvl-android/app/src/main/assets";
    static final byte[] PNG={(byte)0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
    private Res(){}
    public static InputStream open(String path){
        String p=path.startsWith("/")?path.substring(1):path;
        try { return new FileInputStream(new File(BASE,p)); }
        catch(IOException e){ return new ByteArrayInputStream(new byte[0]); }
    }
    public static byte[] readImageBytes(String path) throws IOException {
        InputStream in=open(path); ByteArrayOutputStream o=new ByteArrayOutputStream();
        byte[] b=new byte[8192]; int n; while((n=in.read(b))>0)o.write(b,0,n); in.close();
        return normalize(o.toByteArray());
    }
    static byte[] normalize(byte[] d){
        if(d.length>=8 && d[0]==PNG[0]&&d[1]==PNG[1]&&d[2]==PNG[2]&&d[3]==PNG[3])return d;
        if(d.length>=4){int len=((d[0]&255)<<24)|((d[1]&255)<<16)|((d[2]&255)<<8)|(d[3]&255);
            if(len>0&&len<=d.length-4){byte[] o=new byte[len+8];System.arraycopy(PNG,0,o,0,8);System.arraycopy(d,4,o,8,len);return o;}}
        return d;
    }
}
