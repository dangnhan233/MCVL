package javax.wireless.messaging;
import java.io.IOException;
public interface MessageConnection extends javax.microedition.io.Connection {
    String TEXT_MESSAGE="text",BINARY_MESSAGE="binary";
    Message newMessage(String type);
    Message newMessage(String type,String addr);
    int numberOfSegments(Message m);
    Message receive() throws IOException;
    void send(Message m) throws IOException;
    void setMessageListener(MessageListener l) throws IOException;
}
