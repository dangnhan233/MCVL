package javax.microedition.media;
import java.io.InputStream;
import javax.microedition.media.control.VolumeControl;
public final class Manager {
    private Manager(){}
    public static Player createPlayer(String loc) throws MediaException {return new Silent();}
    public static Player createPlayer(String loc,long t) throws MediaException {return new Silent();}
    public static Player createPlayer(InputStream s,String type) throws MediaException {return new Silent();}
    public static void playTone(int n,int d,int v) throws MediaException {}
    public static String[] getSupportedContentTypes(String p){return new String[]{"audio/x-wav","audio/midi"};}
    public static String[] getSupportedProtocols(String c){return new String[]{"file","http"};}
    static final class Silent implements Player, VolumeControl {
        int state=UNREALIZED; int level=100; boolean muted;
        public void realize(){} public void prefetch(){} public void start(){} public void stop(){}
        public void deallocate(){} public void close(){} public void setLoopCount(int c){}
        public void setMediaTime(long t){} public long getMediaTime(){return 0;}
        public long getDuration(){return TIME_UNKNOWN;} public String getContentType(){return "audio/x-wav";}
        public void addPlayerListener(PlayerListener l){} public void removePlayerListener(PlayerListener l){}
        public Control getControl(String t){return t!=null&&t.endsWith("VolumeControl")?this:null;}
        public Control[] getControls(){return new Control[]{this};}
        public void setMute(boolean m){muted=m;} public boolean isMuted(){return muted;}
        public int setLevel(int l){level=Math.max(0,Math.min(100,l));return level;} public int getLevel(){return level;}
    }
}
