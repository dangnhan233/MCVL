package javax.microedition.media;
public interface PlayerListener {
    String STARTED="started",STOPPED="stopped",END_OF_MEDIA="endOfMedia",DURATION_UPDATED="durationUpdated",
        DEVICE_UNAVAILABLE="deviceUnavailable",DEVICE_AVAILABLE="deviceAvailable",VOLUME_CHANGED="volumeChanged",
        CLOSED="closed",ERROR="error";
    void playerUpdate(Player p,String event,Object data);
}
