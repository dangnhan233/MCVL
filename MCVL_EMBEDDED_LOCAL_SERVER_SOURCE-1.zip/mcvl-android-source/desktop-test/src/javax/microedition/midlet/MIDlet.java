package javax.microedition.midlet;
import java.util.Hashtable;
public abstract class MIDlet {
    private static Hashtable<String,String> props=new Hashtable<String,String>();
    private static Runnable destroyCb;
    protected MIDlet(){}
    public static void setAppProperties(Hashtable<String,String> p){props=p==null?new Hashtable<String,String>():p;}
    public static void setDestroyCallback(Runnable r){destroyCb=r;}
    public String getAppProperty(String k){return props.get(k);}
    public final void notifyDestroyed(){if(destroyCb!=null)destroyCb.run();}
    public final void notifyPaused(){}
    public final void resumeRequest(){}
    public final boolean platformRequest(String u){return false;}
    protected abstract void startApp();
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean u);
    public final void __startApp(){startApp();}
    public final void __pauseApp(){pauseApp();}
    public final void __destroyApp(boolean u){destroyApp(u);}
}
