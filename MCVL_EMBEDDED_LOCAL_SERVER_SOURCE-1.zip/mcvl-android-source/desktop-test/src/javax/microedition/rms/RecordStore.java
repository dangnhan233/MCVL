package javax.microedition.rms;
import java.util.*;
public class RecordStore {
    private static final Map<String,RecordStore> stores=new HashMap<String,RecordStore>();
    private final Map<Integer,byte[]> records=new TreeMap<Integer,byte[]>();
    private int next=1; private boolean open=true;
    private RecordStore(){}
    public static RecordStore openRecordStore(String name,boolean create) throws RecordStoreException {
        RecordStore rs=stores.get(name);
        if(rs==null){ if(!create)throw new RecordStoreNotFoundException(name); rs=new RecordStore(); stores.put(name,rs); }
        rs.open=true; return rs;
    }
    public void closeRecordStore() throws RecordStoreException {open=false;}
    public static void deleteRecordStore(String name) throws RecordStoreException {stores.remove(name);}
    public int getNumRecords(){return records.size();}
    public int getSizeAvailable(){return 65536;}
    public int getSize(){int s=0;for(byte[] b:records.values())s+=b.length;return s;}
    public byte[] getRecord(int id) throws RecordStoreException {byte[] b=records.get(id);if(b==null)throw new InvalidRecordIDException(""+id);return b;}
    public int addRecord(byte[] data,int off,int len) throws RecordStoreException {
        byte[] b=new byte[len]; if(data!=null)System.arraycopy(data,off,b,0,len);
        int id=next++; records.put(id,b); return id;
    }
    public void setRecord(int id,byte[] data,int off,int len) throws RecordStoreException {
        if(!records.containsKey(id))throw new InvalidRecordIDException(""+id);
        byte[] b=new byte[len]; if(data!=null)System.arraycopy(data,off,b,0,len); records.put(id,b);
    }
    public void deleteRecord(int id) throws RecordStoreException {records.remove(id);}
    public int getNextRecordID(){return next;}
    public int getRecordSize(int id) throws RecordStoreException {byte[] b=records.get(id);return b==null?0:b.length;}
    public String getName(){return "";}
    public long getLastModified(){return 0;}
}
