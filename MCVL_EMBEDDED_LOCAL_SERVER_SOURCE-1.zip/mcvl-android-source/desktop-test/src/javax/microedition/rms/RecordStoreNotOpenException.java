package javax.microedition.rms;
public class RecordStoreNotOpenException extends RecordStoreException { public RecordStoreNotOpenException(String m){super(m);} }
