package javax.microedition.lcdui;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
public class Graphics {
    public static final int HCENTER=1,VCENTER=2,LEFT=4,RIGHT=8,TOP=16,BOTTOM=32,BASELINE=64;
    public static final int SOLID=0,DOTTED=1;
    public static final int TRANS_NONE=0,TRANS_ROT90=5,TRANS_ROT180=3,TRANS_ROT270=6,
        TRANS_MIRROR=2,TRANS_MIRROR_ROT90=7,TRANS_MIRROR_ROT180=1,TRANS_MIRROR_ROT270=4;
    final Graphics2D g; final int width,height;
    Font font=Font.getDefaultFont(); int color=0; int strokeStyle=SOLID;
    int tx=0,ty=0,clipX=0,clipY=0,clipW,clipH; Image target;
    public Graphics(Graphics2D g,int w,int h,Image t){this.g=g;this.width=w;this.height=h;
        this.clipW=w;this.clipH=h;this.target=t;g.setStroke(new BasicStroke(1f));setColor(0);}
    public void setColor(int rgb){color=rgb&0xFFFFFF;g.setColor(new Color(color));}
    public void setColor(int r,int gg,int b){setColor(((r&255)<<16)|((gg&255)<<8)|(b&255));}
    public int getColor(){return color;}
    public int getRedComponent(){return (color>>16)&255;}
    public int getGreenComponent(){return (color>>8)&255;}
    public int getBlueComponent(){return color&255;}
    public void setGrayScale(int v){v&=255;setColor((v<<16)|(v<<8)|v);}
    public int getGrayScale(){return (getRedComponent()*299+getGreenComponent()*587+getBlueComponent()*114)/1000;}
    public void setFont(Font f){if(f!=null){font=f;g.setFont(f.awt);}}
    public Font getFont(){return font;}
    public void translate(int x,int y){tx+=x;ty+=y;g.translate(x,y);}
    public int getTranslateX(){return tx;} public int getTranslateY(){return ty;}
    public void setClip(int x,int y,int w,int h){clipX=x;clipY=y;clipW=w;clipH=h;g.setClip(x,y,w,h);}
    public void clipRect(int x,int y,int w,int h){g.clipRect(x,y,w,h);}
    public int getClipX(){return clipX;} public int getClipY(){return clipY;}
    public int getClipWidth(){return clipW;} public int getClipHeight(){return clipH;}
    public void setStrokeStyle(int s){strokeStyle=s;g.setStroke(new BasicStroke(1f));}
    public int getStrokeStyle(){return strokeStyle;}
    public void drawLine(int x1,int y1,int x2,int y2){g.drawLine(x1,y1,x2,y2);}
    public void drawRect(int x,int y,int w,int h){g.drawRect(x,y,w,h);}
    public void fillRect(int x,int y,int w,int h){g.fillRect(x,y,w,h);}
    public void drawRoundRect(int x,int y,int w,int h,int aw,int ah){g.drawRoundRect(x,y,w,h,aw,ah);}
    public void fillRoundRect(int x,int y,int w,int h,int aw,int ah){g.fillRoundRect(x,y,w,h,aw,ah);}
    public void drawArc(int x,int y,int w,int h,int sa,int aa){g.drawArc(x,y,w,h,sa,aa);}
    public void fillArc(int x,int y,int w,int h,int sa,int aa){g.fillArc(x,y,w,h,sa,aa);}
    public void fillTriangle(int x1,int y1,int x2,int y2,int x3,int y3){
        g.fillPolygon(new int[]{x1,x2,x3},new int[]{y1,y2,y3},3);}
    static int ax(int x,int w,int a){ if((a&HCENTER)!=0)return x-w/2; if((a&RIGHT)!=0)return x-w; return x;}
    static int ay(int y,int h,int a){ if((a&VCENTER)!=0)return y-h/2; if((a&BOTTOM)!=0)return y-h; return y;}
    public void drawImage(Image img,int x,int y,int anchor){
        if(img==null||img.buf==null)return;
        g.drawImage(img.buf,ax(x,img.getWidth(),anchor),ay(y,img.getHeight(),anchor),null);}
    public void drawRegion(Image src,int xs,int ys,int w,int h,int tr,int xd,int yd,int anchor){
        if(src==null||src.buf==null)return;
        BufferedImage sub=src.buf.getSubimage(xs,ys,w,h);
        int dw=w,dh=h; if(tr==TRANS_ROT90||tr==TRANS_ROT270||tr==TRANS_MIRROR_ROT90||tr==TRANS_MIRROR_ROT270){dw=h;dh=w;}
        int dx=ax(xd,dw,anchor),dy=ay(yd,dh,anchor);
        AffineTransform at=new AffineTransform();
        switch(tr){
          case TRANS_ROT90: at.translate(dx+dh,dy); at.rotate(Math.toRadians(90)); break;
          case TRANS_ROT180: at.translate(dx+dw,dy+dh); at.rotate(Math.toRadians(180)); break;
          case TRANS_ROT270: at.translate(dx,dy+dw); at.rotate(Math.toRadians(270)); break;
          case TRANS_MIRROR: at.translate(dx+dw,dy); at.scale(-1,1); break;
          case TRANS_MIRROR_ROT180: at.translate(dx,dy+dh); at.scale(1,-1); break;
          default: at.translate(dx,dy);
        }
        g.drawImage(sub,at,null);}
    public void drawRGB(int[] rgb,int off,int scan,int x,int y,int w,int h,boolean proc){
        BufferedImage bi=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        for(int j=0;j<h;j++)for(int i=0;i<w;i++)bi.setRGB(i,j,rgb[off+j*scan+i]|0xFF000000);
        g.drawImage(bi,x,y,null);}
    public void copyArea(int xs,int ys,int w,int h,int xd,int yd,int anchor){
        if(target==null||target.buf==null)return;
        BufferedImage sub=target.buf.getSubimage(xs,ys,w,h);
        g.drawImage(sub,ax(xd,w,anchor),ay(yd,h,anchor),null);}
    public void drawString(String s,int x,int y,int anchor){ if(s==null)return;
        FontMetrics m=g.getFontMetrics(); int w=m.stringWidth(s);
        int dx=ax(x,w,anchor); int dy=y;
        if((anchor&VCENTER)!=0)dy=y+(m.getAscent()-m.getDescent())/2;
        else if((anchor&BOTTOM)!=0)dy=y-m.getDescent();
        else if((anchor&BASELINE)==0)dy=y+m.getAscent();
        g.drawString(s,dx,dy);}
    public void drawSubstring(String s,int off,int len,int x,int y,int anchor){ if(s==null)return; drawString(s.substring(off,off+len),x,y,anchor);}
    public void drawChar(char c,int x,int y,int anchor){ drawString(String.valueOf(c),x,y,anchor);}
    public void drawChars(char[] d,int off,int len,int x,int y,int anchor){ drawString(new String(d,off,len),x,y,anchor);}
    public int getDisplayColor(int c){return c;}
    public Image getTargetImage(){return target;}
}
