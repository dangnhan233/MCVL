package javax.microedition.lcdui.game;
import javax.microedition.lcdui.Canvas;
public class GameCanvas extends Canvas {
    public static final int UP_PRESSED=0x0002,DOWN_PRESSED=0x0040,LEFT_PRESSED=0x0004,
        RIGHT_PRESSED=0x0020,FIRE_PRESSED=0x0100,GAME_A_PRESSED=0x0200,GAME_B_PRESSED=0x0400,
        GAME_C_PRESSED=0x0800,GAME_D_PRESSED=0x1000;
    private final boolean sup;
    public GameCanvas(boolean s){super();sup=s;}
    public int getKeyStates(){return 0;}
    public void flushGraphics(){repaint();}
    public void flushGraphics(int x,int y,int w,int h){repaint();}
}
