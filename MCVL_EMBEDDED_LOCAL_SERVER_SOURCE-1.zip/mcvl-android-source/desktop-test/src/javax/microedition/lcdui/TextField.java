package javax.microedition.lcdui;
public class TextField extends Item {
    public static final int ANY=0,EMAILADDR=1,NUMERIC=2,PHONENUMBER=3,URL=4,DECIMAL=5,
        PASSWORD=0x10000,UNEDITABLE=0x20000,SENSITIVE=0x40000,NON_PREDICTIVE=0x80000,INITIAL_CAPS_WORD=0x100000,INITIAL_CAPS_SENTENCE=0x200000;
    public static final int CONSTRAINT_MASK=0xFFFF;
    String text; int max,constraints;
    public TextField(String l,String t,int m,int c){label=l;text=t==null?"":t;max=m;constraints=c;}
    public String getString(){return text;}
    public void setString(String t){text=t==null?"":t;}
    public int size(){return text.length();}
    public int getMaxSize(){return max;}
    public void setMaxSize(int m){max=m;}
    public int getConstraints(){return constraints;}
    public void setConstraints(int c){constraints=c;}
    public void insert(String s,int pos){text=text.substring(0,pos)+s+text.substring(pos);}
    public void delete(int off,int len){text=text.substring(0,off)+text.substring(off+len);}
    public void setChars(char[] d,int off,int len){text=new String(d,off,len);}
    public int getCaretPosition(){return text.length();}
}
