package javax.microedition.lcdui;
import javax.microedition.midlet.MIDlet;
public class Display {
    private static Display inst; private static int w=240,h=320; private static Displayable current;
    private Display(){}
    public static Display getDisplay(MIDlet m){if(inst==null)inst=new Display();return inst;}
    public static void setScreenSize(int a,int b){if(a>0&&b>0){w=a;h=b;}}
    public static int getScreenWidth(){return w;} public static int getScreenHeight(){return h;}
    public void setCurrent(Displayable d){if(current!=null)current.notifyHidden();current=d;if(current!=null)current.notifyShown();}
    public void setCurrent(Alert a,Displayable d){setCurrent(d);}
    public Displayable getCurrent(){return current;}
    public static Displayable getCurrentDisplayable(){return current;}
    public void callSerially(Runnable r){if(r!=null)r.run();}
    public boolean isColor(){return true;} public int numColors(){return 16777216;}
    public int numAlphaLevels(){return 256;}
    public static void requestRepaint(){Renderer.request();}
    public static void serviceRepaints(){}
}
