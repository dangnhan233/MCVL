package javax.microedition.lcdui;
public abstract class Item {
    String label="";
    public void setLabel(String l){label=l;}
    public String getLabel(){return label;}
}
