package javax.microedition.lcdui;
public class StringItem extends Item {
    String text;
    public StringItem(String l,String t){label=l;text=t;}
    public String getText(){return text;} public void setText(String t){text=t;}
}
