package javax.microedition.lcdui;
public class Command {
    public static final int OK=4,BACK=2,CANCEL=3,EXIT=7,HELP=5,ITEM=8,SCREEN=1,STOP=6;
    String label; int type,priority;
    public Command(String l,int t,int p){label=l;type=t;priority=p;}
    public Command(String s,String l,int t,int p){this(l,t,p);}
    public String getLabel(){return label;} public int getCommandType(){return type;}
    public int getPriority(){return priority;}
}
