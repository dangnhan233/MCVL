package javax.microedition.lcdui;
import java.awt.*;
import java.awt.image.BufferedImage;
public class Font {
    public static final int FACE_SYSTEM=0,FACE_MONOSPACE=32,FACE_PROPORTIONAL=64;
    public static final int STYLE_PLAIN=0,STYLE_BOLD=1,STYLE_ITALIC=2,STYLE_UNDERLINED=4;
    public static final int SIZE_SMALL=8,SIZE_MEDIUM=0,SIZE_LARGE=16;
    final java.awt.Font awt;
    private Font(java.awt.Font f){this.awt=f;}
    public static Font getFont(int face,int style,int size){
        int s = size==SIZE_SMALL?10 : size==SIZE_LARGE?18 : 12;
        int st = (style&STYLE_BOLD)!=0?java.awt.Font.BOLD:java.awt.Font.PLAIN;
        if((style&STYLE_ITALIC)!=0)st|=java.awt.Font.ITALIC;
        String name = face==FACE_MONOSPACE?java.awt.Font.MONOSPACED:java.awt.Font.SANS_SERIF;
        return new Font(new java.awt.Font(name,st,s));}
    public static Font getDefaultFont(){return getFont(FACE_SYSTEM,STYLE_PLAIN,SIZE_MEDIUM);}
    public int getHeight(){return metrics().getHeight();}
    public int getBaselinePosition(){return metrics().getAscent();}
    public int stringWidth(String s){return s==null?0:metrics().stringWidth(s);}
    public int charWidth(char c){return metrics().charWidth(c);}
    public int getFace(){return FACE_SYSTEM;}
    public int getStyle(){return awt.isBold()?STYLE_BOLD:STYLE_PLAIN;}
    public int getSize(){return SIZE_MEDIUM;}
    public boolean isBold(){return awt.isBold();}
    public boolean isItalic(){return awt.isItalic();}
    public boolean isUnderlined(){return false;}
    private FontMetrics metrics(){
        BufferedImage bi=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
        return bi.createGraphics().getFontMetrics(awt);}
}
