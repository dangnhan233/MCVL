package javax.microedition.lcdui;
public class Alert extends Screen {
    String text; Image image; AlertType type; int timeout=2000;
    public Alert(String t){title=t;}
    public Alert(String t,String a,Image i,AlertType ty){title=t;text=a;image=i;type=ty;}
    public void setTimeout(int t){timeout=t;}
    public int getTimeout(){return timeout;}
    public void setString(String s){text=s;}
    public String getString(){return text;}
    public void setType(AlertType t){type=t;}
    public AlertType getType(){return type;}
}
