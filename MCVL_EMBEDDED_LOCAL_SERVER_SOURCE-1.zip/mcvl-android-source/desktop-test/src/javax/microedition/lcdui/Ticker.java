package javax.microedition.lcdui;
public class Ticker { String s; public Ticker(String s){this.s=s;} public String getString(){return s;} }
