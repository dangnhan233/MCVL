package javax.microedition.lcdui;
import java.util.Vector;
public abstract class Displayable {
    String title=""; Ticker ticker; CommandListener listener; boolean shown;
    final Vector<Command> commands=new Vector<Command>();
    Displayable(){}
    public int getWidth(){return Display.getScreenWidth();}
    public int getHeight(){return Display.getScreenHeight();}
    public String getTitle(){return title;}
    public void setTitle(String t){title=t==null?"":t;}
    public void addCommand(Command c){if(c!=null&&!commands.contains(c))commands.addElement(c);}
    public void removeCommand(Command c){commands.removeElement(c);}
    public void setCommandListener(CommandListener l){listener=l;}
    public boolean isShown(){return shown;}
    void notifyShown(){shown=true;} void notifyHidden(){shown=false;}
}
