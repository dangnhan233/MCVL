package javax.microedition.lcdui;
public class Renderer {
    public interface Sink { void onRepaint(); }
    private static Sink sink;
    public static void setSink(Sink s){sink=s;}
    public static void request(){if(sink!=null)sink.onRepaint();}
}
