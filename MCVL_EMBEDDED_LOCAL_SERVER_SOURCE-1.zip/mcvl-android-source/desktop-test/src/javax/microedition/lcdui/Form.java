package javax.microedition.lcdui;
import java.util.Vector;
public class Form extends Screen {
    final Vector<Item> items=new Vector<Item>(); ItemStateListener listener;
    public Form(String t){title=t;}
    public Form(String t,Item[] it){title=t;if(it!=null)for(Item i:it)items.addElement(i);}
    public int append(String s){items.addElement(new StringItem(null,s));return items.size()-1;}
    public int append(Item i){items.addElement(i);return items.size()-1;}
    public int append(Image i){items.addElement(new ImageItem(null,i,0,null));return items.size()-1;}
    public void delete(int i){items.removeElementAt(i);}
    public int size(){return items.size();}
    public Item get(int i){return items.elementAt(i);}
    public void setItemStateListener(ItemStateListener l){listener=l;}
}
