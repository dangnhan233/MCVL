package javax.microedition.lcdui;
import java.util.Vector;
public class ChoiceGroup extends Item implements Choice {
    final Vector<String> strings=new Vector<String>(); final Vector<Image> images=new Vector<Image>();
    final Vector<Boolean> selected=new Vector<Boolean>(); int type;
    public ChoiceGroup(String l,int t){label=l;type=t;}
    public ChoiceGroup(String l,int t,String[] s,Image[] im){label=l;type=t;
        if(s!=null)for(int i=0;i<s.length;i++)append(s[i],im!=null&&i<im.length?im[i]:null);}
    public int append(String s,Image i){strings.addElement(s);images.addElement(i);selected.addElement(Boolean.FALSE);return strings.size()-1;}
    public void insert(int idx,String s,Image i){strings.insertElementAt(s,idx);images.insertElementAt(i,idx);selected.insertElementAt(Boolean.FALSE,idx);}
    public void delete(int i){strings.removeElementAt(i);images.removeElementAt(i);selected.removeElementAt(i);}
    public void deleteAll(){strings.removeAllElements();images.removeAllElements();selected.removeAllElements();}
    public int size(){return strings.size();}
    public String getString(int i){return strings.elementAt(i);}
    public Image getImage(int i){return images.elementAt(i);}
    public void set(int i,String s,Image im){strings.setElementAt(s,i);images.setElementAt(im,i);}
    public boolean isSelected(int i){return selected.elementAt(i);}
    public int getSelectedIndex(){for(int i=0;i<selected.size();i++)if(selected.elementAt(i))return i;return -1;}
    public int getSelectedFlags(boolean[] f){int n=0;for(int i=0;i<f.length;i++){f[i]=isSelected(i);if(f[i])n++;}return n;}
    public void setSelectedIndex(int i,boolean s){if(type==EXCLUSIVE){for(int j=0;j<selected.size();j++)selected.setElementAt(Boolean.FALSE,j);}selected.setElementAt(s,i);}
    public void setSelectedFlags(boolean[] f){for(int i=0;i<selected.size()&&i<f.length;i++)selected.setElementAt(f[i],i);}
    public void setFitPolicy(int p){} public int getFitPolicy(){return 0;}
}
