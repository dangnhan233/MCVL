package javax.microedition.lcdui;
public class ImageItem extends Item {
    Image image;
    public ImageItem(String l,Image i,int layout,String alt){label=l;image=i;}
    public Image getImage(){return image;}
}
