package javax.microedition.lcdui;
public interface Choice {
    int EXCLUSIVE=1,MULTIPLE=2,IMPLICIT=3;
    int append(String s,Image i); void insert(int i,String s,Image im); void delete(int i);
    void deleteAll(); int size(); String getString(int i); Image getImage(int i);
    void set(int i,String s,Image im); boolean isSelected(int i); int getSelectedIndex();
    int getSelectedFlags(boolean[] f); void setSelectedIndex(int i,boolean s);
    void setSelectedFlags(boolean[] f);
}
