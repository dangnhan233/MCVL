package javax.microedition.lcdui;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import com.mcvl.game.Res;
public class Image {
    public static final int TRANS_NONE=0,TRANS_ROT90=5,TRANS_ROT180=3,TRANS_ROT270=6,
        TRANS_MIRROR=2,TRANS_MIRROR_ROT90=7,TRANS_MIRROR_ROT180=1,TRANS_MIRROR_ROT270=4;
    static final byte[] PNG={(byte)0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
    final BufferedImage buf;
    Image(BufferedImage b){buf=b;}
    public static Image createImage(int w,int h){return new Image(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));}
    public static Image createImage(String path) throws IOException {
        byte[] data=Res.readImageBytes(path);
        BufferedImage b=ImageIO.read(new ByteArrayInputStream(data));
        if(b==null)throw new IOException("bad image "+path);
        BufferedImage c=new BufferedImage(b.getWidth(),b.getHeight(),BufferedImage.TYPE_INT_ARGB);
        c.getGraphics().drawImage(b,0,0,null);
        return new Image(c);
    }
    public static Image createImage(byte[] d,int off,int len) throws IOException {
        byte[] s=new byte[len]; System.arraycopy(d,off,s,0,len);
        BufferedImage b=ImageIO.read(new ByteArrayInputStream(s));
        if(b==null)throw new IOException("bad image bytes");
        return new Image(b);
    }
    public static Image createImage(Image src,int x,int y,int w,int h,int transform){
        BufferedImage sub=src.buf.getSubimage(x,y,w,h);
        int dw=w,dh=h;
        boolean rot=(transform==TRANS_ROT90||transform==TRANS_ROT270||transform==TRANS_MIRROR_ROT90||transform==TRANS_MIRROR_ROT270);
        if(rot){dw=h;dh=w;}
        BufferedImage out=new BufferedImage(dw,dh,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=out.createGraphics();
        AffineTransform at=new AffineTransform();
        switch(transform){
          case TRANS_ROT90: at.translate(dh,0); at.rotate(Math.toRadians(90)); break;
          case TRANS_ROT180: at.translate(dw,dh); at.rotate(Math.toRadians(180)); break;
          case TRANS_ROT270: at.translate(0,dw); at.rotate(Math.toRadians(270)); break;
          case TRANS_MIRROR: at.translate(dw,0); at.scale(-1,1); break;
          case TRANS_MIRROR_ROT180: at.translate(0,dh); at.scale(1,-1); break;
          default:
        }
        g.drawImage(sub,at,null); g.dispose();
        return new Image(out);
    }
    public Graphics getGraphics(){return new Graphics(buf.createGraphics(),buf.getWidth(),buf.getHeight(),this);}
    public int getWidth(){return buf.getWidth();}
    public int getHeight(){return buf.getHeight();}
    public boolean isMutable(){return true;}
    public void getRGB(int[] rgb,int off,int scan,int x,int y,int w,int h){
        buf.getRGB(x,y,w,h,rgb,off,scan);}
}
