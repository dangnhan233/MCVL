package javax.microedition.lcdui;
public class Canvas extends Displayable {
    public static final int KEY_NUM0=48,KEY_NUM1=49,KEY_NUM2=50,KEY_NUM3=51,KEY_NUM4=52,
        KEY_NUM5=53,KEY_NUM6=54,KEY_NUM7=55,KEY_NUM8=56,KEY_NUM9=57,KEY_STAR=42,KEY_POUND=35;
    public static final int UP=1,DOWN=6,LEFT=2,RIGHT=5,FIRE=8,GAME_A=9,GAME_B=10,GAME_C=11,GAME_D=12;
    private boolean full;
    public Canvas(){super();}
    public boolean isDoubleBuffered(){return true;}
    public boolean hasPointerEvents(){return true;}
    public boolean hasPointerMotionEvents(){return true;}
    public boolean hasRepeatEvents(){return false;}
    public void setFullScreenMode(boolean m){full=m;}
    public boolean isFullScreenMode(){return full;}
    public int getGameAction(int k){switch(k){case -1:return UP;case -2:return DOWN;case -3:return LEFT;
        case -4:return RIGHT;case -5:return FIRE;case -6:return GAME_A;case -7:return GAME_B;default:return 0;}}
    public int getKeyCode(int a){switch(a){case UP:return -1;case DOWN:return -2;case LEFT:return -3;
        case RIGHT:return -4;case FIRE:return -5;case GAME_A:return -6;case GAME_B:return -7;default:return 0;}}
    public String getKeyName(int k){return String.valueOf(k);}
    public void repaint(){Display.requestRepaint();}
    public void repaint(int x,int y,int w,int h){Display.requestRepaint();}
    public void serviceRepaints(){}
    public void callSerially(Runnable r){if(r!=null)r.run();}
    protected void paint(Graphics g){}
    protected void keyPressed(int k){}
    protected void keyReleased(int k){}
    protected void keyRepeated(int k){}
    protected void pointerPressed(int x,int y){}
    protected void pointerReleased(int x,int y){}
    protected void pointerDragged(int x,int y){}
    protected void showNotify(){}
    protected void hideNotify(){}
    protected void sizeChanged(int w,int h){}
    public final void __paint(Graphics g){paint(g);}
    public final void __keyPressed(int k){keyPressed(k);}
    public final void __keyReleased(int k){keyReleased(k);}
    public final void __showNotify(){showNotify();}
}
