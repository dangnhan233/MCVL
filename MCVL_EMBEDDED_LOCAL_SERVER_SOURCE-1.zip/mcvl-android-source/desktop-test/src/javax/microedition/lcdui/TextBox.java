package javax.microedition.lcdui;
public class TextBox extends Screen {
    String text; int max,constraints;
    public TextBox(String t,String x,int m,int c){title=t;text=x==null?"":x;max=m;constraints=c;}
    public String getString(){return text;}
    public void setString(String t){text=t==null?"":t;}
    public int size(){return text.length();}
    public int getMaxSize(){return max;}
    public int getConstraints(){return constraints;}
    public void insert(String s,int pos){text=text.substring(0,pos)+s+text.substring(pos);}
    public void delete(int off,int len){text=text.substring(0,off)+text.substring(off+len);}
    public int getCaretPosition(){return text.length();}
}
