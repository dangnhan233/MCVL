package javax.microedition.io;
import java.io.*;
public interface Datagram extends DataInput, DataOutput {
    String getAddress(); void setAddress(String a);
    String getAddress(String b); int getPort(); void setPort(int p);
    byte[] getData(); int getOffset(); int getLength(); void setLength(int l);
    void setData(byte[] b,int off,int len); void reset();
}
