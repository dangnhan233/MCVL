package javax.microedition.io;
public interface HttpConnection extends ContentConnection {
    String GET="GET",HEAD="HEAD",POST="POST";
    int HTTP_OK=200,HTTP_NOT_FOUND=404,HTTP_TEMP_REDIRECT=307;
    void setRequestMethod(String m) throws java.io.IOException;
    String getRequestMethod();
    String getURL();
    String getHost();
    int getPort();
    String getQuery();
    String getRequestProperty(String k);
    void setRequestProperty(String k,String v) throws java.io.IOException;
    int getResponseCode() throws java.io.IOException;
    String getResponseMessage() throws java.io.IOException;
}
