package javax.microedition.io;
import java.io.IOException;
public final class Connector {
    public static final int READ=1,WRITE=2,READ_WRITE=3;
    private Connector(){}
    public static Connection open(String name) throws IOException { throw new ConnectionNotFoundException("Not supported: "+name); }
    public static Connection open(String name,int mode) throws IOException { return open(name); }
    public static Connection open(String name,int mode,boolean timeouts) throws IOException { return open(name); }
    public static java.io.DataInputStream openDataInputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
    public static java.io.DataOutputStream openDataOutputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
    public static java.io.InputStream openInputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
    public static java.io.OutputStream openOutputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
}
