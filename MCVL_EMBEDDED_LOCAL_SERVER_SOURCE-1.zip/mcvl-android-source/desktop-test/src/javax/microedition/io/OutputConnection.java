package javax.microedition.io;
import java.io.DataOutputStream; import java.io.IOException;
public interface OutputConnection extends Connection { DataOutputStream openDataOutputStream() throws IOException; java.io.OutputStream openOutputStream() throws IOException; }
