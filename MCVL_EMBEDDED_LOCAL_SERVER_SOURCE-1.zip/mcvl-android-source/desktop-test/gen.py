#!/usr/bin/env python3
"""Generate a minimal desktop J2ME runtime so the ported game bytecode can be
smoke-tested on the JVM (headless render to a BufferedImage)."""
import os

ROOT = "/workspace/desktop-test/src"
ASSETS = "/workspace/mcvl-android/app/src/main/assets"

FILES = {}

def add(path, content):
    FILES[path] = content

# ---------------------------------------------------------------- lcdui
add("javax/microedition/lcdui/Graphics.java", r'''
package javax.microedition.lcdui;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
public class Graphics {
    public static final int HCENTER=1,VCENTER=2,LEFT=4,RIGHT=8,TOP=16,BOTTOM=32,BASELINE=64;
    public static final int SOLID=0,DOTTED=1;
    public static final int TRANS_NONE=0,TRANS_ROT90=5,TRANS_ROT180=3,TRANS_ROT270=6,
        TRANS_MIRROR=2,TRANS_MIRROR_ROT90=7,TRANS_MIRROR_ROT180=1,TRANS_MIRROR_ROT270=4;
    final Graphics2D g; final int width,height;
    Font font=Font.getDefaultFont(); int color=0; int strokeStyle=SOLID;
    int tx=0,ty=0,clipX=0,clipY=0,clipW,clipH; Image target;
    public Graphics(Graphics2D g,int w,int h,Image t){this.g=g;this.width=w;this.height=h;
        this.clipW=w;this.clipH=h;this.target=t;g.setStroke(new BasicStroke(1f));setColor(0);}
    public void setColor(int rgb){color=rgb&0xFFFFFF;g.setColor(new Color(color));}
    public void setColor(int r,int gg,int b){setColor(((r&255)<<16)|((gg&255)<<8)|(b&255));}
    public int getColor(){return color;}
    public int getRedComponent(){return (color>>16)&255;}
    public int getGreenComponent(){return (color>>8)&255;}
    public int getBlueComponent(){return color&255;}
    public void setGrayScale(int v){v&=255;setColor((v<<16)|(v<<8)|v);}
    public int getGrayScale(){return (getRedComponent()*299+getGreenComponent()*587+getBlueComponent()*114)/1000;}
    public void setFont(Font f){if(f!=null){font=f;g.setFont(f.awt);}}
    public Font getFont(){return font;}
    public void translate(int x,int y){tx+=x;ty+=y;g.translate(x,y);}
    public int getTranslateX(){return tx;} public int getTranslateY(){return ty;}
    public void setClip(int x,int y,int w,int h){clipX=x;clipY=y;clipW=w;clipH=h;g.setClip(x,y,w,h);}
    public void clipRect(int x,int y,int w,int h){g.clipRect(x,y,w,h);}
    public int getClipX(){return clipX;} public int getClipY(){return clipY;}
    public int getClipWidth(){return clipW;} public int getClipHeight(){return clipH;}
    public void setStrokeStyle(int s){strokeStyle=s;g.setStroke(new BasicStroke(1f));}
    public int getStrokeStyle(){return strokeStyle;}
    public void drawLine(int x1,int y1,int x2,int y2){g.drawLine(x1,y1,x2,y2);}
    public void drawRect(int x,int y,int w,int h){g.drawRect(x,y,w,h);}
    public void fillRect(int x,int y,int w,int h){g.fillRect(x,y,w,h);}
    public void drawRoundRect(int x,int y,int w,int h,int aw,int ah){g.drawRoundRect(x,y,w,h,aw,ah);}
    public void fillRoundRect(int x,int y,int w,int h,int aw,int ah){g.fillRoundRect(x,y,w,h,aw,ah);}
    public void drawArc(int x,int y,int w,int h,int sa,int aa){g.drawArc(x,y,w,h,sa,aa);}
    public void fillArc(int x,int y,int w,int h,int sa,int aa){g.fillArc(x,y,w,h,sa,aa);}
    public void fillTriangle(int x1,int y1,int x2,int y2,int x3,int y3){
        g.fillPolygon(new int[]{x1,x2,x3},new int[]{y1,y2,y3},3);}
    static int ax(int x,int w,int a){ if((a&HCENTER)!=0)return x-w/2; if((a&RIGHT)!=0)return x-w; return x;}
    static int ay(int y,int h,int a){ if((a&VCENTER)!=0)return y-h/2; if((a&BOTTOM)!=0)return y-h; return y;}
    public void drawImage(Image img,int x,int y,int anchor){
        if(img==null||img.buf==null)return;
        g.drawImage(img.buf,ax(x,img.getWidth(),anchor),ay(y,img.getHeight(),anchor),null);}
    public void drawRegion(Image src,int xs,int ys,int w,int h,int tr,int xd,int yd,int anchor){
        if(src==null||src.buf==null)return;
        BufferedImage sub=src.buf.getSubimage(xs,ys,w,h);
        int dw=w,dh=h; if(tr==TRANS_ROT90||tr==TRANS_ROT270||tr==TRANS_MIRROR_ROT90||tr==TRANS_MIRROR_ROT270){dw=h;dh=w;}
        int dx=ax(xd,dw,anchor),dy=ay(yd,dh,anchor);
        AffineTransform at=new AffineTransform();
        switch(tr){
          case TRANS_ROT90: at.translate(dx+dh,dy); at.rotate(Math.toRadians(90)); break;
          case TRANS_ROT180: at.translate(dx+dw,dy+dh); at.rotate(Math.toRadians(180)); break;
          case TRANS_ROT270: at.translate(dx,dy+dw); at.rotate(Math.toRadians(270)); break;
          case TRANS_MIRROR: at.translate(dx+dw,dy); at.scale(-1,1); break;
          case TRANS_MIRROR_ROT180: at.translate(dx,dy+dh); at.scale(1,-1); break;
          default: at.translate(dx,dy);
        }
        g.drawImage(sub,at,null);}
    public void drawRGB(int[] rgb,int off,int scan,int x,int y,int w,int h,boolean proc){
        BufferedImage bi=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        for(int j=0;j<h;j++)for(int i=0;i<w;i++)bi.setRGB(i,j,rgb[off+j*scan+i]|0xFF000000);
        g.drawImage(bi,x,y,null);}
    public void copyArea(int xs,int ys,int w,int h,int xd,int yd,int anchor){
        if(target==null||target.buf==null)return;
        BufferedImage sub=target.buf.getSubimage(xs,ys,w,h);
        g.drawImage(sub,ax(xd,w,anchor),ay(yd,h,anchor),null);}
    public void drawString(String s,int x,int y,int anchor){ if(s==null)return;
        FontMetrics m=g.getFontMetrics(); int w=m.stringWidth(s);
        int dx=ax(x,w,anchor); int dy=y;
        if((anchor&VCENTER)!=0)dy=y+(m.getAscent()-m.getDescent())/2;
        else if((anchor&BOTTOM)!=0)dy=y-m.getDescent();
        else if((anchor&BASELINE)==0)dy=y+m.getAscent();
        g.drawString(s,dx,dy);}
    public void drawSubstring(String s,int off,int len,int x,int y,int anchor){ if(s==null)return; drawString(s.substring(off,off+len),x,y,anchor);}
    public void drawChar(char c,int x,int y,int anchor){ drawString(String.valueOf(c),x,y,anchor);}
    public void drawChars(char[] d,int off,int len,int x,int y,int anchor){ drawString(new String(d,off,len),x,y,anchor);}
    public int getDisplayColor(int c){return c;}
    public Image getTargetImage(){return target;}
}
''')

add("javax/microedition/lcdui/Image.java", r'''
package javax.microedition.lcdui;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import com.mcvl.game.Res;
public class Image {
    public static final int TRANS_NONE=0,TRANS_ROT90=5,TRANS_ROT180=3,TRANS_ROT270=6,
        TRANS_MIRROR=2,TRANS_MIRROR_ROT90=7,TRANS_MIRROR_ROT180=1,TRANS_MIRROR_ROT270=4;
    static final byte[] PNG={(byte)0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
    final BufferedImage buf;
    Image(BufferedImage b){buf=b;}
    public static Image createImage(int w,int h){return new Image(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));}
    public static Image createImage(String path) throws IOException {
        byte[] data=Res.readImageBytes(path);
        BufferedImage b=ImageIO.read(new ByteArrayInputStream(data));
        if(b==null)throw new IOException("bad image "+path);
        BufferedImage c=new BufferedImage(b.getWidth(),b.getHeight(),BufferedImage.TYPE_INT_ARGB);
        c.getGraphics().drawImage(b,0,0,null);
        return new Image(c);
    }
    public static Image createImage(byte[] d,int off,int len) throws IOException {
        byte[] s=new byte[len]; System.arraycopy(d,off,s,0,len);
        BufferedImage b=ImageIO.read(new ByteArrayInputStream(s));
        if(b==null)throw new IOException("bad image bytes");
        return new Image(b);
    }
    public static Image createImage(Image src,int x,int y,int w,int h,int transform){
        BufferedImage sub=src.buf.getSubimage(x,y,w,h);
        int dw=w,dh=h;
        boolean rot=(transform==TRANS_ROT90||transform==TRANS_ROT270||transform==TRANS_MIRROR_ROT90||transform==TRANS_MIRROR_ROT270);
        if(rot){dw=h;dh=w;}
        BufferedImage out=new BufferedImage(dw,dh,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=out.createGraphics();
        AffineTransform at=new AffineTransform();
        switch(transform){
          case TRANS_ROT90: at.translate(dh,0); at.rotate(Math.toRadians(90)); break;
          case TRANS_ROT180: at.translate(dw,dh); at.rotate(Math.toRadians(180)); break;
          case TRANS_ROT270: at.translate(0,dw); at.rotate(Math.toRadians(270)); break;
          case TRANS_MIRROR: at.translate(dw,0); at.scale(-1,1); break;
          case TRANS_MIRROR_ROT180: at.translate(0,dh); at.scale(1,-1); break;
          default:
        }
        g.drawImage(sub,at,null); g.dispose();
        return new Image(out);
    }
    public Graphics getGraphics(){return new Graphics(buf.createGraphics(),buf.getWidth(),buf.getHeight(),this);}
    public int getWidth(){return buf.getWidth();}
    public int getHeight(){return buf.getHeight();}
    public boolean isMutable(){return true;}
    public void getRGB(int[] rgb,int off,int scan,int x,int y,int w,int h){
        buf.getRGB(x,y,w,h,rgb,off,scan);}
}
''')

add("javax/microedition/lcdui/Font.java", r'''
package javax.microedition.lcdui;
import java.awt.*;
import java.awt.image.BufferedImage;
public class Font {
    public static final int FACE_SYSTEM=0,FACE_MONOSPACE=32,FACE_PROPORTIONAL=64;
    public static final int STYLE_PLAIN=0,STYLE_BOLD=1,STYLE_ITALIC=2,STYLE_UNDERLINED=4;
    public static final int SIZE_SMALL=8,SIZE_MEDIUM=0,SIZE_LARGE=16;
    final java.awt.Font awt;
    private Font(java.awt.Font f){this.awt=f;}
    public static Font getFont(int face,int style,int size){
        int s = size==SIZE_SMALL?10 : size==SIZE_LARGE?18 : 12;
        int st = (style&STYLE_BOLD)!=0?java.awt.Font.BOLD:java.awt.Font.PLAIN;
        if((style&STYLE_ITALIC)!=0)st|=java.awt.Font.ITALIC;
        String name = face==FACE_MONOSPACE?java.awt.Font.MONOSPACED:java.awt.Font.SANS_SERIF;
        return new Font(new java.awt.Font(name,st,s));}
    public static Font getDefaultFont(){return getFont(FACE_SYSTEM,STYLE_PLAIN,SIZE_MEDIUM);}
    public int getHeight(){return metrics().getHeight();}
    public int getBaselinePosition(){return metrics().getAscent();}
    public int stringWidth(String s){return s==null?0:metrics().stringWidth(s);}
    public int charWidth(char c){return metrics().charWidth(c);}
    public int getFace(){return FACE_SYSTEM;}
    public int getStyle(){return awt.isBold()?STYLE_BOLD:STYLE_PLAIN;}
    public int getSize(){return SIZE_MEDIUM;}
    public boolean isBold(){return awt.isBold();}
    public boolean isItalic(){return awt.isItalic();}
    public boolean isUnderlined(){return false;}
    private FontMetrics metrics(){
        BufferedImage bi=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
        return bi.createGraphics().getFontMetrics(awt);}
}
''')

add("javax/microedition/lcdui/Displayable.java", r'''
package javax.microedition.lcdui;
import java.util.Vector;
public abstract class Displayable {
    String title=""; Ticker ticker; CommandListener listener; boolean shown;
    final Vector<Command> commands=new Vector<Command>();
    Displayable(){}
    public int getWidth(){return Display.getScreenWidth();}
    public int getHeight(){return Display.getScreenHeight();}
    public String getTitle(){return title;}
    public void setTitle(String t){title=t==null?"":t;}
    public void addCommand(Command c){if(c!=null&&!commands.contains(c))commands.addElement(c);}
    public void removeCommand(Command c){commands.removeElement(c);}
    public void setCommandListener(CommandListener l){listener=l;}
    public boolean isShown(){return shown;}
    void notifyShown(){shown=true;} void notifyHidden(){shown=false;}
}
''')

add("javax/microedition/lcdui/Canvas.java", r'''
package javax.microedition.lcdui;
public class Canvas extends Displayable {
    public static final int KEY_NUM0=48,KEY_NUM1=49,KEY_NUM2=50,KEY_NUM3=51,KEY_NUM4=52,
        KEY_NUM5=53,KEY_NUM6=54,KEY_NUM7=55,KEY_NUM8=56,KEY_NUM9=57,KEY_STAR=42,KEY_POUND=35;
    public static final int UP=1,DOWN=6,LEFT=2,RIGHT=5,FIRE=8,GAME_A=9,GAME_B=10,GAME_C=11,GAME_D=12;
    private boolean full;
    public Canvas(){super();}
    public boolean isDoubleBuffered(){return true;}
    public boolean hasPointerEvents(){return true;}
    public boolean hasPointerMotionEvents(){return true;}
    public boolean hasRepeatEvents(){return false;}
    public void setFullScreenMode(boolean m){full=m;}
    public boolean isFullScreenMode(){return full;}
    public int getGameAction(int k){switch(k){case -1:return UP;case -2:return DOWN;case -3:return LEFT;
        case -4:return RIGHT;case -5:return FIRE;case -6:return GAME_A;case -7:return GAME_B;default:return 0;}}
    public int getKeyCode(int a){switch(a){case UP:return -1;case DOWN:return -2;case LEFT:return -3;
        case RIGHT:return -4;case FIRE:return -5;case GAME_A:return -6;case GAME_B:return -7;default:return 0;}}
    public String getKeyName(int k){return String.valueOf(k);}
    public void repaint(){Display.requestRepaint();}
    public void repaint(int x,int y,int w,int h){Display.requestRepaint();}
    public void serviceRepaints(){}
    public void callSerially(Runnable r){if(r!=null)r.run();}
    protected void paint(Graphics g){}
    protected void keyPressed(int k){}
    protected void keyReleased(int k){}
    protected void keyRepeated(int k){}
    protected void pointerPressed(int x,int y){}
    protected void pointerReleased(int x,int y){}
    protected void pointerDragged(int x,int y){}
    protected void showNotify(){}
    protected void hideNotify(){}
    protected void sizeChanged(int w,int h){}
    public final void __paint(Graphics g){paint(g);}
    public final void __keyPressed(int k){keyPressed(k);}
    public final void __keyReleased(int k){keyReleased(k);}
    public final void __showNotify(){showNotify();}
}
''')

add("javax/microedition/lcdui/game/GameCanvas.java", r'''
package javax.microedition.lcdui.game;
import javax.microedition.lcdui.Canvas;
public class GameCanvas extends Canvas {
    public static final int UP_PRESSED=0x0002,DOWN_PRESSED=0x0040,LEFT_PRESSED=0x0004,
        RIGHT_PRESSED=0x0020,FIRE_PRESSED=0x0100,GAME_A_PRESSED=0x0200,GAME_B_PRESSED=0x0400,
        GAME_C_PRESSED=0x0800,GAME_D_PRESSED=0x1000;
    private final boolean sup;
    public GameCanvas(boolean s){super();sup=s;}
    public int getKeyStates(){return 0;}
    public void flushGraphics(){repaint();}
    public void flushGraphics(int x,int y,int w,int h){repaint();}
}
''')

add("javax/microedition/lcdui/Display.java", r'''
package javax.microedition.lcdui;
import javax.microedition.midlet.MIDlet;
public class Display {
    private static Display inst; private static int w=240,h=320; private static Displayable current;
    private Display(){}
    public static Display getDisplay(MIDlet m){if(inst==null)inst=new Display();return inst;}
    public static void setScreenSize(int a,int b){if(a>0&&b>0){w=a;h=b;}}
    public static int getScreenWidth(){return w;} public static int getScreenHeight(){return h;}
    public void setCurrent(Displayable d){if(current!=null)current.notifyHidden();current=d;if(current!=null)current.notifyShown();}
    public void setCurrent(Alert a,Displayable d){setCurrent(d);}
    public Displayable getCurrent(){return current;}
    public static Displayable getCurrentDisplayable(){return current;}
    public void callSerially(Runnable r){if(r!=null)r.run();}
    public boolean isColor(){return true;} public int numColors(){return 16777216;}
    public int numAlphaLevels(){return 256;}
    public static void requestRepaint(){Renderer.request();}
    public static void serviceRepaints(){}
}
''')

add("javax/microedition/lcdui/Renderer.java", r'''
package javax.microedition.lcdui;
public class Renderer {
    public interface Sink { void onRepaint(); }
    private static Sink sink;
    public static void setSink(Sink s){sink=s;}
    public static void request(){if(sink!=null)sink.onRepaint();}
}
''')

# trivial lcdui stubs
add("javax/microedition/lcdui/Command.java", r'''
package javax.microedition.lcdui;
public class Command {
    public static final int OK=4,BACK=2,CANCEL=3,EXIT=7,HELP=5,ITEM=8,SCREEN=1,STOP=6;
    String label; int type,priority;
    public Command(String l,int t,int p){label=l;type=t;priority=p;}
    public Command(String s,String l,int t,int p){this(l,t,p);}
    public String getLabel(){return label;} public int getCommandType(){return type;}
    public int getPriority(){return priority;}
}
''')
add("javax/microedition/lcdui/CommandListener.java", r'''
package javax.microedition.lcdui;
public interface CommandListener { void commandAction(Command c,Displayable d); }
''')
add("javax/microedition/lcdui/AlertType.java", r'''
package javax.microedition.lcdui;
public class AlertType {
    public static final AlertType INFO=new AlertType(),WARNING=new AlertType(),
        ERROR=new AlertType(),ALARM=new AlertType(),CONFIRMATION=new AlertType();
    protected AlertType(){}
    public boolean playSound(Display d){return true;}
}
''')
add("javax/microedition/lcdui/Alert.java", r'''
package javax.microedition.lcdui;
public class Alert extends Screen {
    String text; Image image; AlertType type; int timeout=2000;
    public Alert(String t){title=t;}
    public Alert(String t,String a,Image i,AlertType ty){title=t;text=a;image=i;type=ty;}
    public void setTimeout(int t){timeout=t;}
    public int getTimeout(){return timeout;}
    public void setString(String s){text=s;}
    public String getString(){return text;}
    public void setType(AlertType t){type=t;}
    public AlertType getType(){return type;}
}
''')
add("javax/microedition/lcdui/Screen.java", r'''
package javax.microedition.lcdui;
public abstract class Screen extends Displayable { Screen(){} }
''')
add("javax/microedition/lcdui/Item.java", r'''
package javax.microedition.lcdui;
public abstract class Item {
    String label="";
    public void setLabel(String l){label=l;}
    public String getLabel(){return label;}
}
''')
add("javax/microedition/lcdui/ItemStateListener.java", r'''
package javax.microedition.lcdui;
public interface ItemStateListener { void itemStateChanged(Item item); }
''')
add("javax/microedition/lcdui/StringItem.java", r'''
package javax.microedition.lcdui;
public class StringItem extends Item {
    String text;
    public StringItem(String l,String t){label=l;text=t;}
    public String getText(){return text;} public void setText(String t){text=t;}
}
''')
add("javax/microedition/lcdui/ImageItem.java", r'''
package javax.microedition.lcdui;
public class ImageItem extends Item {
    Image image;
    public ImageItem(String l,Image i,int layout,String alt){label=l;image=i;}
    public Image getImage(){return image;}
}
''')
add("javax/microedition/lcdui/Ticker.java", r'''
package javax.microedition.lcdui;
public class Ticker { String s; public Ticker(String s){this.s=s;} public String getString(){return s;} }
''')
add("javax/microedition/lcdui/Form.java", r'''
package javax.microedition.lcdui;
import java.util.Vector;
public class Form extends Screen {
    final Vector<Item> items=new Vector<Item>(); ItemStateListener listener;
    public Form(String t){title=t;}
    public Form(String t,Item[] it){title=t;if(it!=null)for(Item i:it)items.addElement(i);}
    public int append(String s){items.addElement(new StringItem(null,s));return items.size()-1;}
    public int append(Item i){items.addElement(i);return items.size()-1;}
    public int append(Image i){items.addElement(new ImageItem(null,i,0,null));return items.size()-1;}
    public void delete(int i){items.removeElementAt(i);}
    public int size(){return items.size();}
    public Item get(int i){return items.elementAt(i);}
    public void setItemStateListener(ItemStateListener l){listener=l;}
}
''')
add("javax/microedition/lcdui/TextField.java", r'''
package javax.microedition.lcdui;
public class TextField extends Item {
    public static final int ANY=0,EMAILADDR=1,NUMERIC=2,PHONENUMBER=3,URL=4,DECIMAL=5,
        PASSWORD=0x10000,UNEDITABLE=0x20000,SENSITIVE=0x40000,NON_PREDICTIVE=0x80000,INITIAL_CAPS_WORD=0x100000,INITIAL_CAPS_SENTENCE=0x200000;
    public static final int CONSTRAINT_MASK=0xFFFF;
    String text; int max,constraints;
    public TextField(String l,String t,int m,int c){label=l;text=t==null?"":t;max=m;constraints=c;}
    public String getString(){return text;}
    public void setString(String t){text=t==null?"":t;}
    public int size(){return text.length();}
    public int getMaxSize(){return max;}
    public void setMaxSize(int m){max=m;}
    public int getConstraints(){return constraints;}
    public void setConstraints(int c){constraints=c;}
    public void insert(String s,int pos){text=text.substring(0,pos)+s+text.substring(pos);}
    public void delete(int off,int len){text=text.substring(0,off)+text.substring(off+len);}
    public void setChars(char[] d,int off,int len){text=new String(d,off,len);}
    public int getCaretPosition(){return text.length();}
}
''')
add("javax/microedition/lcdui/TextBox.java", r'''
package javax.microedition.lcdui;
public class TextBox extends Screen {
    String text; int max,constraints;
    public TextBox(String t,String x,int m,int c){title=t;text=x==null?"":x;max=m;constraints=c;}
    public String getString(){return text;}
    public void setString(String t){text=t==null?"":t;}
    public int size(){return text.length();}
    public int getMaxSize(){return max;}
    public int getConstraints(){return constraints;}
    public void insert(String s,int pos){text=text.substring(0,pos)+s+text.substring(pos);}
    public void delete(int off,int len){text=text.substring(0,off)+text.substring(off+len);}
    public int getCaretPosition(){return text.length();}
}
''')
add("javax/microedition/lcdui/Choice.java", r'''
package javax.microedition.lcdui;
public interface Choice {
    int EXCLUSIVE=1,MULTIPLE=2,IMPLICIT=3;
    int append(String s,Image i); void insert(int i,String s,Image im); void delete(int i);
    void deleteAll(); int size(); String getString(int i); Image getImage(int i);
    void set(int i,String s,Image im); boolean isSelected(int i); int getSelectedIndex();
    int getSelectedFlags(boolean[] f); void setSelectedIndex(int i,boolean s);
    void setSelectedFlags(boolean[] f);
}
''')
add("javax/microedition/lcdui/ChoiceGroup.java", r'''
package javax.microedition.lcdui;
import java.util.Vector;
public class ChoiceGroup extends Item implements Choice {
    final Vector<String> strings=new Vector<String>(); final Vector<Image> images=new Vector<Image>();
    final Vector<Boolean> selected=new Vector<Boolean>(); int type;
    public ChoiceGroup(String l,int t){label=l;type=t;}
    public ChoiceGroup(String l,int t,String[] s,Image[] im){label=l;type=t;
        if(s!=null)for(int i=0;i<s.length;i++)append(s[i],im!=null&&i<im.length?im[i]:null);}
    public int append(String s,Image i){strings.addElement(s);images.addElement(i);selected.addElement(Boolean.FALSE);return strings.size()-1;}
    public void insert(int idx,String s,Image i){strings.insertElementAt(s,idx);images.insertElementAt(i,idx);selected.insertElementAt(Boolean.FALSE,idx);}
    public void delete(int i){strings.removeElementAt(i);images.removeElementAt(i);selected.removeElementAt(i);}
    public void deleteAll(){strings.removeAllElements();images.removeAllElements();selected.removeAllElements();}
    public int size(){return strings.size();}
    public String getString(int i){return strings.elementAt(i);}
    public Image getImage(int i){return images.elementAt(i);}
    public void set(int i,String s,Image im){strings.setElementAt(s,i);images.setElementAt(im,i);}
    public boolean isSelected(int i){return selected.elementAt(i);}
    public int getSelectedIndex(){for(int i=0;i<selected.size();i++)if(selected.elementAt(i))return i;return -1;}
    public int getSelectedFlags(boolean[] f){int n=0;for(int i=0;i<f.length;i++){f[i]=isSelected(i);if(f[i])n++;}return n;}
    public void setSelectedIndex(int i,boolean s){if(type==EXCLUSIVE){for(int j=0;j<selected.size();j++)selected.setElementAt(Boolean.FALSE,j);}selected.setElementAt(s,i);}
    public void setSelectedFlags(boolean[] f){for(int i=0;i<selected.size()&&i<f.length;i++)selected.setElementAt(f[i],i);}
    public void setFitPolicy(int p){} public int getFitPolicy(){return 0;}
}
''')

# ---------------------------------------------------------------- midlet
add("javax/microedition/midlet/MIDlet.java", r'''
package javax.microedition.midlet;
import java.util.Hashtable;
public abstract class MIDlet {
    private static Hashtable<String,String> props=new Hashtable<String,String>();
    private static Runnable destroyCb;
    protected MIDlet(){}
    public static void setAppProperties(Hashtable<String,String> p){props=p==null?new Hashtable<String,String>():p;}
    public static void setDestroyCallback(Runnable r){destroyCb=r;}
    public String getAppProperty(String k){return props.get(k);}
    public final void notifyDestroyed(){if(destroyCb!=null)destroyCb.run();}
    public final void notifyPaused(){}
    public final void resumeRequest(){}
    public final boolean platformRequest(String u){return false;}
    protected abstract void startApp();
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean u);
    public final void __startApp(){startApp();}
    public final void __pauseApp(){pauseApp();}
    public final void __destroyApp(boolean u){destroyApp(u);}
}
''')

# ---------------------------------------------------------------- media
add("javax/microedition/media/MediaException.java", r'''
package javax.microedition.media;
public class MediaException extends Exception { public MediaException(String m){super(m);} }
''')
add("javax/microedition/media/Control.java", r'''
package javax.microedition.media;
public interface Control {}
''')
add("javax/microedition/media/Controllable.java", r'''
package javax.microedition.media;
public interface Controllable {
    Control getControl(String type);
    Control[] getControls();
}
''')
add("javax/microedition/media/PlayerListener.java", r'''
package javax.microedition.media;
public interface PlayerListener {
    String STARTED="started",STOPPED="stopped",END_OF_MEDIA="endOfMedia",DURATION_UPDATED="durationUpdated",
        DEVICE_UNAVAILABLE="deviceUnavailable",DEVICE_AVAILABLE="deviceAvailable",VOLUME_CHANGED="volumeChanged",
        CLOSED="closed",ERROR="error";
    void playerUpdate(Player p,String event,Object data);
}
''')
add("javax/microedition/media/Player.java", r'''
package javax.microedition.media;
public interface Player extends Controllable {
    int UNREALIZED=100,REALIZED=200,PREFETCHED=300,STARTED=400,CLOSED=0,TIME_UNKNOWN=-1;
    void realize() throws MediaException;
    void prefetch() throws MediaException;
    void start() throws MediaException;
    void stop() throws MediaException;
    void deallocate();
    void close();
    void setLoopCount(int c);
    void setMediaTime(long t) throws MediaException;
    long getMediaTime();
    long getDuration();
    String getContentType();
    void addPlayerListener(PlayerListener l);
    void removePlayerListener(PlayerListener l);
}
''')
add("javax/microedition/media/control/VolumeControl.java", r'''
package javax.microedition.media.control;
import javax.microedition.media.Control;
public interface VolumeControl extends Control {
    void setMute(boolean m); boolean isMuted(); int setLevel(int l); int getLevel();
}
''')
add("javax/microedition/media/Manager.java", r'''
package javax.microedition.media;
import java.io.InputStream;
import javax.microedition.media.control.VolumeControl;
public final class Manager {
    private Manager(){}
    public static Player createPlayer(String loc) throws MediaException {return new Silent();}
    public static Player createPlayer(String loc,long t) throws MediaException {return new Silent();}
    public static Player createPlayer(InputStream s,String type) throws MediaException {return new Silent();}
    public static void playTone(int n,int d,int v) throws MediaException {}
    public static String[] getSupportedContentTypes(String p){return new String[]{"audio/x-wav","audio/midi"};}
    public static String[] getSupportedProtocols(String c){return new String[]{"file","http"};}
    static final class Silent implements Player, VolumeControl {
        int state=UNREALIZED; int level=100; boolean muted;
        public void realize(){} public void prefetch(){} public void start(){} public void stop(){}
        public void deallocate(){} public void close(){} public void setLoopCount(int c){}
        public void setMediaTime(long t){} public long getMediaTime(){return 0;}
        public long getDuration(){return TIME_UNKNOWN;} public String getContentType(){return "audio/x-wav";}
        public void addPlayerListener(PlayerListener l){} public void removePlayerListener(PlayerListener l){}
        public Control getControl(String t){return t!=null&&t.endsWith("VolumeControl")?this:null;}
        public Control[] getControls(){return new Control[]{this};}
        public void setMute(boolean m){muted=m;} public boolean isMuted(){return muted;}
        public int setLevel(int l){level=Math.max(0,Math.min(100,l));return level;} public int getLevel(){return level;}
    }
}
''')

# ---------------------------------------------------------------- rms
add("javax/microedition/rms/RecordStoreException.java", r'''
package javax.microedition.rms;
public class RecordStoreException extends Exception { public RecordStoreException(){super();} public RecordStoreException(String m){super(m);} }
''')
add("javax/microedition/rms/RecordStoreNotFoundException.java", r'''
package javax.microedition.rms;
public class RecordStoreNotFoundException extends RecordStoreException { public RecordStoreNotFoundException(String m){super(m);} }
''')
add("javax/microedition/rms/RecordStoreFullException.java", r'''
package javax.microedition.rms;
public class RecordStoreFullException extends RecordStoreException { public RecordStoreFullException(String m){super(m);} }
''')
add("javax/microedition/rms/RecordStoreNotOpenException.java", r'''
package javax.microedition.rms;
public class RecordStoreNotOpenException extends RecordStoreException { public RecordStoreNotOpenException(String m){super(m);} }
''')
add("javax/microedition/rms/InvalidRecordIDException.java", r'''
package javax.microedition.rms;
public class InvalidRecordIDException extends RecordStoreException { public InvalidRecordIDException(String m){super(m);} }
''')
add("javax/microedition/rms/RecordStore.java", r'''
package javax.microedition.rms;
import java.util.*;
public class RecordStore {
    private static final Map<String,RecordStore> stores=new HashMap<String,RecordStore>();
    private final Map<Integer,byte[]> records=new TreeMap<Integer,byte[]>();
    private int next=1; private boolean open=true;
    private RecordStore(){}
    public static RecordStore openRecordStore(String name,boolean create) throws RecordStoreException {
        RecordStore rs=stores.get(name);
        if(rs==null){ if(!create)throw new RecordStoreNotFoundException(name); rs=new RecordStore(); stores.put(name,rs); }
        rs.open=true; return rs;
    }
    public void closeRecordStore() throws RecordStoreException {open=false;}
    public static void deleteRecordStore(String name) throws RecordStoreException {stores.remove(name);}
    public int getNumRecords(){return records.size();}
    public int getSizeAvailable(){return 65536;}
    public int getSize(){int s=0;for(byte[] b:records.values())s+=b.length;return s;}
    public byte[] getRecord(int id) throws RecordStoreException {byte[] b=records.get(id);if(b==null)throw new InvalidRecordIDException(""+id);return b;}
    public int addRecord(byte[] data,int off,int len) throws RecordStoreException {
        byte[] b=new byte[len]; if(data!=null)System.arraycopy(data,off,b,0,len);
        int id=next++; records.put(id,b); return id;
    }
    public void setRecord(int id,byte[] data,int off,int len) throws RecordStoreException {
        if(!records.containsKey(id))throw new InvalidRecordIDException(""+id);
        byte[] b=new byte[len]; if(data!=null)System.arraycopy(data,off,b,0,len); records.put(id,b);
    }
    public void deleteRecord(int id) throws RecordStoreException {records.remove(id);}
    public int getNextRecordID(){return next;}
    public int getRecordSize(int id) throws RecordStoreException {byte[] b=records.get(id);return b==null?0:b.length;}
    public String getName(){return "";}
    public long getLastModified(){return 0;}
}
''')

# ---------------------------------------------------------------- io
add("javax/microedition/io/Connection.java", r'''
package javax.microedition.io;
import java.io.IOException;
public interface Connection { void close() throws IOException; }
''')
add("javax/microedition/io/InputConnection.java", r'''
package javax.microedition.io;
import java.io.DataInputStream; import java.io.IOException;
public interface InputConnection extends Connection { DataInputStream openDataInputStream() throws IOException; java.io.InputStream openInputStream() throws IOException; }
''')
add("javax/microedition/io/OutputConnection.java", r'''
package javax.microedition.io;
import java.io.DataOutputStream; import java.io.IOException;
public interface OutputConnection extends Connection { DataOutputStream openDataOutputStream() throws IOException; java.io.OutputStream openOutputStream() throws IOException; }
''')
add("javax/microedition/io/StreamConnection.java", r'''
package javax.microedition.io;
public interface StreamConnection extends InputConnection, OutputConnection {}
''')
add("javax/microedition/io/ContentConnection.java", r'''
package javax.microedition.io;
public interface ContentConnection extends StreamConnection { String getType(); String getEncoding(); long getLength(); }
''')
add("javax/microedition/io/SocketConnection.java", r'''
package javax.microedition.io;
import java.io.IOException;
public interface SocketConnection extends StreamConnection {
    byte DELAY=0,LINGER=1,KEEPALIVE=2,RCVBUF=3,SNDBUF=4;
    void setSocketOption(byte option,int value) throws IOException;
    int getSocketOption(byte option) throws IOException;
    String getAddress() throws IOException;
    String getLocalAddress() throws IOException;
    int getPort() throws IOException;
    int getLocalPort() throws IOException;
}
''')
add("javax/microedition/io/ConnectionNotFoundException.java", r'''
package javax.microedition.io;
import java.io.IOException;
public class ConnectionNotFoundException extends IOException { public ConnectionNotFoundException(){super();} public ConnectionNotFoundException(String m){super(m);} }
''')
add("javax/microedition/io/HttpConnection.java", r'''
package javax.microedition.io;
public interface HttpConnection extends ContentConnection {
    String GET="GET",HEAD="HEAD",POST="POST";
    int HTTP_OK=200,HTTP_NOT_FOUND=404,HTTP_TEMP_REDIRECT=307;
    void setRequestMethod(String m) throws java.io.IOException;
    String getRequestMethod();
    String getURL();
    String getHost();
    int getPort();
    String getQuery();
    String getRequestProperty(String k);
    void setRequestProperty(String k,String v) throws java.io.IOException;
    int getResponseCode() throws java.io.IOException;
    String getResponseMessage() throws java.io.IOException;
}
''')
add("javax/microedition/io/Datagram.java", r'''
package javax.microedition.io;
import java.io.*;
public interface Datagram extends DataInput, DataOutput {
    String getAddress(); void setAddress(String a);
    String getAddress(String b); int getPort(); void setPort(int p);
    byte[] getData(); int getOffset(); int getLength(); void setLength(int l);
    void setData(byte[] b,int off,int len); void reset();
}
''')
add("javax/microedition/io/DatagramConnection.java", r'''
package javax.microedition.io;
import java.io.IOException;
public interface DatagramConnection extends Connection {
    int getMaximumLength() throws IOException;
    int getNominalLength() throws IOException;
    void send(Datagram d) throws IOException;
    void receive(Datagram d) throws IOException;
    Datagram newDatagram(int size) throws IOException;
    Datagram newDatagram(int size,String addr) throws IOException;
    Datagram newDatagram(byte[] buf,int size) throws IOException;
    Datagram newDatagram(byte[] buf,int size,String addr) throws IOException;
}
''')
add("javax/microedition/io/Connector.java", r'''
package javax.microedition.io;
import java.io.IOException;
public final class Connector {
    public static final int READ=1,WRITE=2,READ_WRITE=3;
    private Connector(){}
    public static Connection open(String name) throws IOException { throw new ConnectionNotFoundException("Not supported: "+name); }
    public static Connection open(String name,int mode) throws IOException { return open(name); }
    public static Connection open(String name,int mode,boolean timeouts) throws IOException { return open(name); }
    public static java.io.DataInputStream openDataInputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
    public static java.io.DataOutputStream openDataOutputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
    public static java.io.InputStream openInputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
    public static java.io.OutputStream openOutputStream(String name) throws IOException { throw new ConnectionNotFoundException(name); }
}
''')

# ---------------------------------------------------------------- wireless
add("javax/wireless/messaging/Message.java", r'''
package javax.wireless.messaging;
public interface Message {
    String getAddress(); void setAddress(String a);
    java.util.Date getTimestamp();
}
''')
add("javax/wireless/messaging/TextMessage.java", r'''
package javax.wireless.messaging;
public interface TextMessage extends Message {
    String getPayloadText(); void setPayloadText(String d);
}
''')
add("javax/wireless/messaging/BinaryMessage.java", r'''
package javax.wireless.messaging;
public interface BinaryMessage extends Message {
    byte[] getPayloadData(); void setPayloadData(byte[] d);
}
''')
add("javax/wireless/messaging/MessageListener.java", r'''
package javax.wireless.messaging;
public interface MessageListener { void notifyIncomingMessage(MessageConnection c); }
''')
add("javax/wireless/messaging/MessageConnection.java", r'''
package javax.wireless.messaging;
import java.io.IOException;
public interface MessageConnection extends javax.microedition.io.Connection {
    String TEXT_MESSAGE="text",BINARY_MESSAGE="binary";
    Message newMessage(String type);
    Message newMessage(String type,String addr);
    int numberOfSegments(Message m);
    Message receive() throws IOException;
    void send(Message m) throws IOException;
    void setMessageListener(MessageListener l) throws IOException;
}
''')

# ---------------------------------------------------------------- nokia
add("com/nokia/mid/ui/DirectGraphics.java", r'''
package com.nokia.mid.ui;
public interface DirectGraphics {
    int FLIP_HORIZONTAL=0x2000,FLIP_VERTICAL=0x4000;
    void setARGBColor(int c); int getAlphaComponent();
    void drawImage(javax.microedition.lcdui.Image img,int x,int y,int anchor,int manipulation);
    void drawTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c);
    void fillTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c);
    void drawPolygon(int[] x,int xo,int[] y,int yo,int n,int c);
    void fillPolygon(int[] x,int xo,int[] y,int yo,int n,int c);
}
''')
add("com/nokia/mid/ui/DirectUtils.java", r'''
package com.nokia.mid.ui;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
public final class DirectUtils {
    private DirectUtils(){}
    public static DirectGraphics getDirectGraphics(Graphics g){return new Impl(g);}
    static final class Impl implements DirectGraphics {
        final Graphics g; int alpha=255;
        Impl(Graphics g){this.g=g;}
        public void setARGBColor(int c){alpha=(c>>>24)&255;g.setColor(c&0xFFFFFF);}
        public int getAlphaComponent(){return alpha;}
        public void drawImage(Image i,int x,int y,int a,int m){g.drawImage(i,x,y,a);}
        public void drawTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);
            g.drawLine(x1,y1,x2,y2);g.drawLine(x2,y2,x3,y3);g.drawLine(x3,y3,x1,y1);g.setColor(s);}
        public void fillTriangle(int x1,int y1,int x2,int y2,int x3,int y3,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);g.fillTriangle(x1,y1,x2,y2,x3,y3);g.setColor(s);}
        public void drawPolygon(int[] x,int xo,int[] y,int yo,int n,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);
            for(int i=0;i<n;i++){int j=(i+1)%n;g.drawLine(x[xo+i],y[yo+i],x[xo+j],y[yo+j]);}g.setColor(s);}
        public void fillPolygon(int[] x,int xo,int[] y,int yo,int n,int c){int s=g.getColor();g.setColor(c&0xFFFFFF);
            for(int i=1;i<n-1;i++)g.fillTriangle(x[xo],y[yo],x[xo+i],y[yo+i],x[xo+i+1],y[yo+i+1]);g.setColor(s);}
    }
}
''')

# ---------------------------------------------------------------- game Res
add("com/mcvl/game/Res.java", r'''
package com.mcvl.game;
import java.io.*;
public final class Res {
    public static String BASE="/workspace/mcvl-android/app/src/main/assets";
    static final byte[] PNG={(byte)0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
    private Res(){}
    public static InputStream open(String path){
        String p=path.startsWith("/")?path.substring(1):path;
        try { return new FileInputStream(new File(BASE,p)); }
        catch(IOException e){ return new ByteArrayInputStream(new byte[0]); }
    }
    public static byte[] readImageBytes(String path) throws IOException {
        InputStream in=open(path); ByteArrayOutputStream o=new ByteArrayOutputStream();
        byte[] b=new byte[8192]; int n; while((n=in.read(b))>0)o.write(b,0,n); in.close();
        return normalize(o.toByteArray());
    }
    static byte[] normalize(byte[] d){
        if(d.length>=8 && d[0]==PNG[0]&&d[1]==PNG[1]&&d[2]==PNG[2]&&d[3]==PNG[3])return d;
        if(d.length>=4){int len=((d[0]&255)<<24)|((d[1]&255)<<16)|((d[2]&255)<<8)|(d[3]&255);
            if(len>0&&len<=d.length-4){byte[] o=new byte[len+8];System.arraycopy(PNG,0,o,0,8);System.arraycopy(d,4,o,8,len);return o;}}
        return d;
    }
}
''')

# ---------------------------------------------------------------- harness
add("Harness.java", r'''
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Method;
import java.util.Hashtable;
import javax.imageio.ImageIO;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

public class Harness {
    static volatile boolean repaint=false;
    static BufferedImage frame;
    static int frames=0;
    public static void main(String[] a) throws Exception {
        Display.setScreenSize(240,320);
        Hashtable<String,String> props=new Hashtable<String,String>();
        props.put("MIDlet-Version","2.0.3");
        MIDlet.setAppProperties(props);
        Renderer.setSink(new Renderer.Sink(){public void onRepaint(){repaint=true;}});

        Class<?> cls=Class.forName("SFMIDlet");
        MIDlet m=(MIDlet)cls.getDeclaredConstructor().newInstance();
        Method start=cls.getDeclaredMethod("startApp");
        start.setAccessible(true);
        start.invoke(m);
        System.out.println("startApp OK, current="+Display.getCurrentDisplayable());

        long end=System.currentTimeMillis()+6000;
        while(System.currentTimeMillis()<end){
            if(repaint){
                repaint=false;
                Displayable d=Display.getCurrentDisplayable();
                if(d instanceof Canvas){
                    frame=new BufferedImage(240,320,BufferedImage.TYPE_INT_RGB);
                    Graphics g=new Graphics(frame.createGraphics(),240,320,null);
                    ((Canvas)d).__paint(g);
                    frames++;
                    if(frames==1||frames==30||frames==60||frames==120||frames==200){
                        ImageIO.write(frame,"png",new File("/workspace/desktop-test/frame_"+frames+".png"));
                        System.out.println("rendered frame "+frames);
                    }
                }
            }
            Thread.sleep(5);
        }
        System.out.println("TOTAL FRAMES RENDERED: "+frames);
        if(frame!=null)ImageIO.write(frame,"png",new File("/workspace/desktop-test/frame_last.png"));
        System.out.println("DONE");
        System.exit(0);
    }
}
''')

for path, content in FILES.items():
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w") as f:
        f.write(content.lstrip("\n"))
print("wrote", len(FILES), "files to", ROOT)
