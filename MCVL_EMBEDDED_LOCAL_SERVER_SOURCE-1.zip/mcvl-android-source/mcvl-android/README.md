# Minh Chủ Võ Lâm (MCVL) — Bản chuyển sang Android hiện đại

Tái cấu trúc game J2ME **"Minh Chủ Võ Lâm"** (SilentFire, v2.0.3) thành ứng dụng
Android chạy được trên máy hiện nay (Android 5.0+ / API 21 → 34).

---

## 1. Vì sao không biên dịch lại mã nguồn?

Bản gốc là một MIDlet J2ME (MIDP‑1.0 / CLDC‑1.0) đã bị **obfuscate**: 39 class với
tên `a`, `b`, `c`, `v`, … và các field trùng tên nhưng **khác type descriptor**
(ví dụ nhiều field cùng tên `a` nhưng lần lượt là `I`, `B`, `Ljava/lang/String;`).
Trình dịch ngược (CFR/Vineflower) tái tạo đúng bytecode nhưng **không thể biểu diễn
lại bằng Java hợp lệ** — sinh ra 683+ lỗi "duplicate field" và các nhãn `GOTO lblNN`
không cấu trúc được. Vì vậy **không thể biên dịch lại từ mã nguồn dịch ngược**.

### Giải pháp: chạy thẳng bytecode gốc trên lớp tương thích J2ME

Thay vì cố tái tạo mã nguồn, dự án **giữ nguyên 39 file `.class` gốc** và viết một
**lớp tương thích J2ME** (`javax.microedition.*`, `com.nokia.mid.ui.*`) chạy trên
Android. Logic game được bảo toàn 100% vì chính là bytecode gốc đang thực thi.

Chỉ có **một** điểm cần can thiệp ở mức bytecode: game đọc tài nguyên bằng
`Class.getResourceAsStream(String)` (22 chỗ). Trên Android không có classpath JAR,
nên các lời gọi này được **viết lại bằng ASM** thành `com.mcvl.game.Res.open(String)`
— một cầu nối đọc từ thư mục `assets/` của APK.

```
Class.getResourceAsStream("/img/body.png")   →   Res.open("/img/body.png")
```

---

## 2. Kiến trúc

```
┌─────────────────────────────────────────────────────────────┐
│  MainActivity  ──►  GameView (DisplayHost, gamepad ảo)       │  tầng Android
│                       │  Bitmap 240×320 ARGB_8888            │
├───────────────────────┼─────────────────────────────────────┤
│  Lớp tương thích J2ME  │                                     │
│    javax.microedition.lcdui.*   (Graphics/Image/Font/Canvas) │
│    javax.microedition.lcdui.game.GameCanvas                  │
│    javax.microedition.midlet.MIDlet                          │
│    javax.microedition.media.*   (Manager/Player)             │
│    javax.microedition.rms.*     (RecordStore)                │
│    javax.microedition.io.*      (Connector/HttpConnection)   │
│    javax.wireless.messaging.*   (SMS)                        │
│    com.nokia.mid.ui.*           (DirectGraphics)             │
├──────────────────────────────────────────────────────────────┤
│  39 class game GỐC (bytecode Java 1.1)  ──►  Res.open()       │  logic game
│  SFMIDlet, a…z, … (obfuscated)                                │
├──────────────────────────────────────────────────────────────┤
│  assets/  (622 file: .yy/.myy/.mod/.dat/.mid/…)              │  tài nguyên
└──────────────────────────────────────────────────────────────┘
```

### Luồng khởi động
1. `McvlApplication.onCreate()` → `Assets.init(ctx)`, `Manager.setContext(ctx)`,
   `MIDlet.setContext(ctx)`, nạp `MIDlet-Version` từ manifest.
2. `MainActivity` đặt `Display` trỏ tới `GameView`, rồi **reflectively** khởi tạo
   `SFMIDlet` và gọi `startApp()`.
3. `GameView.onDraw()` tạo `new Graphics(canvas, 240, 320, null)` và gọi
   `canvas.__paint(g)` — chính là `paint(Graphics)` mà game override.
4. Game tự chạy `Thread` riêng, gọi `repaint()` mỗi ~40 ms; `GameView` phát lại
   bằng `postInvalidateOnAnimation()`.

### Ánh xạ bàn phím
Game dùng mã phím hành động J2ME: `UP=-1, DOWN=-2, LEFT=-3, RIGHT=-4, FIRE=-5,
GAME_A=-6, GAME_B=-7`, cùng các phím số 48–57, 42 (`*`), 35 (`#`).
`GameView` vẽ **gamepad ảo** (D‑pad + lưới 12 phím số + 2 phím mềm A/B) và dịch
sự kiện chạm thành các mã phím này.

### Định dạng tài nguyên riêng
- `.yy` / `.myy` = ảnh PNG **đã bị cắt 8 byte signature** và thêm 4 byte độ dài
  big‑endian ở đầu → `Res`/`Image` tự phục hồi signature PNG trước khi giải mã.
- `.mod` / `.dat` / `.fill` / `.mdat` = dữ liệu game nhị phân (bản đồ, NPC, kỹ năng…).
- `.mid` = nhạc MIDI (Android không có synth MIDI → giảm còn im lặng, không lỗi).

---

## 3. Cấu trúc thư mục

```
mcvl-android/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/
│   │   ├── javax/microedition/…      ← lớp tương thích J2ME (62 file)
│   │   ├── com/nokia/mid/ui/…        ← DirectGraphics
│   │   ├── com/mcvl/game/Res.java    ← cầu nối tài nguyên
│   │   └── com/mcvl/android/         ← MainActivity, GameView, McvlApplication
│   ├── res/                          ← icon, strings, theme
│   └── assets/                       ← 622 tài nguyên game
├── reference/decompiled/             ← 39 .java dịch ngược (chỉ tham khảo)
├── build_apk.sh                      ← script build không cần Gradle
├── debug.keystore                    ← khoá ký debug
└── out/MinhChuVoLam-2.0.3.apk        ← APK đã ký
```

---

## 4. Build

**Yêu cầu:** JDK 17, Android SDK (platform‑34 + build‑tools 34.0.0).

```bash
export ANDROID_SDK=/đường/dẫn/android-sdk
cd mcvl-android
./build_apk.sh
```

Pipeline (không dùng Gradle):

| Bước | Công cụ | Việc |
|------|---------|------|
| 1 | `javac` | biên dịch lớp tương thích + tầng app |
| 2 | — | copy 39 `.class` game đã port |
| 3 | `d8` | dex hoá (compat + game + app) |
| 4 | `aapt2 compile` | biên dịch `res/` |
| 5 | `aapt2 link` | gộp manifest + tài nguyên + `assets/` |
| 6 | `zipalign` + `apksigner` | căn chỉnh & ký |

Kết quả: `out/MinhChuVoLam-2.0.3.apk` (~2.37 MB, ký v1+v2+v3).

> **Lưu ý về `aapt2 link`:** tài nguyên phải truyền dưới dạng **đối số vị trí**
> (`"$BUILD/res.zip"`), KHÔNG dùng `-R` (vì `-R` mang ngữ nghĩa overlay, gây lỗi
> "resource … does not override an existing resource").

---

## 5. Quy trình chuyển bytecode (tái lập)

```bash
cd origjar
ASM_CP=$(ls lib/*.jar | tr '\n' ':')
javac -cp "$ASM_CP" -d tools/out tools/PortTool.java
java  -cp "tools/out:$ASM_CP" PortTool rewrite classes classes_ported
# → "rewrite: 39 classes, 22 call sites rewritten"

# Kiểm chứng toàn bộ tham chiếu (0 unresolved):
java -cp "tools/out:$ASM_CP" ResolveTool classes_ported \
     "classes_ported:/workspace/mcvl-android/build/app:/workspace/android-sdk/platforms/android-34/android.jar"
# → "indexed classes: 5831" / "=== UNRESOLVED (0) ==="
```

### Chi tiết quan trọng của bộ viết lại
Khi gặp `INVOKEVIRTUAL java/lang/Class.getResourceAsStream(String)`, stack là
`[..., Class, String]`. Ta cần bỏ **Class** (nằm *dưới* String) và giữ **String**
làm đối số cho `Res.open`:

```java
super.visitInsn(Opcodes.SWAP);   // [..., Class, String] → [..., String, Class]
super.visitInsn(Opcodes.POP);    // bỏ Class              → [..., String]
super.visitMethodInsn(INVOKESTATIC, "com/mcvl/game/Res", "open",
                      "(Ljava/lang/String;)Ljava/io/InputStream;", false);
```

> Dùng `POP` đơn thuần sẽ **bỏ nhầm String** và để lại `Class` → `VerifyError:
> Incompatible argument to function`. Đây chính là lỗi đã được phát hiện và sửa
> trong quá trình kiểm thử.

---

## 6. Kiểm thử

### 6.1 Kiểm chứng tham chiếu (tĩnh)
`ResolveTool` phân tích 39 class game, thu 980 method + 1715 field reference và
đối chiếu với lớp tương thích + `android.jar`. Kết quả: **0 unresolved**.

### 6.2 Smoke test trên JVM (động)
Vì sandbox không có emulator/KVM, dự án kèm một **runtime J2ME tối giản chạy trên
AWT** (`desktop-test/`) để chạy thật bytecode game và render ra PNG:

```bash
cd desktop-test
python3 gen.py
find src -name '*.java' > srcs.txt
javac -nowarn -d out @srcs.txt
java -cp "out:/workspace/origjar/classes_ported" Harness
# → startApp OK, current=c@…
# → rendered frame 1 / 30 / 60
# → TOTAL FRAMES RENDERED: 80
```

Kết quả render xác nhận game chạy đúng: **splash "MoGo / SilentFire"** và
**màn hình tiêu đề "Minh Chủ Võ Lâm (II) — Ấn phẩm bất kỳ để vào — V2.0.3"**.

---

## 7. Trạng thái & giới hạn

| Hạng mục | Trạng thái |
|----------|-----------|
| 39 class game chạy trên Android | ✅ |
| Lớp tương thích J2ME (lcdui/media/rms/io/wireless/nokia) | ✅ |
| Cầu nối tài nguyên `Res.open` | ✅ |
| APK ký hợp lệ (v1+v2+v3), cài được | ✅ |
| Gamepad ảo + ánh xạ phím | ✅ |
| Render thực tế (kiểm chứng trên JVM) | ✅ |
| Nhạc MIDI | ⚠️ im lặng trên Android (thiếu synth MIDI) |
| Mạng (Socket/HTTP) | ⚠️ stub — server gốc đã ngừng hoạt động |
| SMS (wireless.messaging) | ⚠️ stub |
| Kiểm thử trên máy thật/emulator | ⛔ không có trong sandbox |

---

## 8. Nguồn

- JAR gốc: `minhchvlm_XLzDI2f3.jar` (870 270 byte) — downloadwap.com
- Decompiler tham khảo: CFR 0.152 (`--renamedupmembers true`), Vineflower 1.10.1
- Bytecode rewrite: ASM 9.7
- Build: Android SDK build‑tools 34.0.0 (aapt2, d8, zipalign, apksigner), JDK 17
## 9. Embedded local server

The standalone `mcvl_server.py` protocol server has been ported to Java as
`com.mcvl.android.EmbeddedLocalServer`. `McvlApplication.onCreate()` starts a
`ServerSocket` bound exclusively to `127.0.0.1:9001`, so the game no longer needs
Termux/Python/a separate server process. Account data is stored in the app's
private files directory as `files/mcvl/accounts.json`.

The port preserves the local-server protocol implemented by `mcvl_server.py`:
version (9950), account/login (1003), registration (1027), character list (1020),
character creation (1012), enter-world (1011), movement/map (1005/2001), help
(9550), ping/status handling, and the same generated starter map.

During the bytecode rewrite, all occurrences of the original endpoint
`210.211.99.77:9001` are changed to `127.0.0.1:9001` in the game classes.

