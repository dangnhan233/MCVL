# MCVL — Embedded Local Server

This version ports `mcvl_server.py` to `com.mcvl.android.EmbeddedLocalServer` and starts it from `McvlApplication.onCreate()`.

## Runtime

- Server: Java `ServerSocket`
- Bind: `127.0.0.1:9001` only
- No Termux/Python process is required at runtime.
- Account database: app-private `files/mcvl/accounts.json`
- Client endpoint rewrite: `210.211.99.77:9001` -> `127.0.0.1:9001`

## Protocol ported

- 9950 version/server list
- 1003 account/login
- 1027 registration
- 1020 character list
- 1012 character creation
- 1011 enter world
- 1005 movement/map request
- 2001 map/entity response
- 9550 help
- 2002/3505 ignored/status/ping handling

## Build

The project uses the existing no-Gradle Android build pipeline. Requirements:

- JDK 17
- Android SDK platform 34
- Build-tools 34.0.0
- ASM jars already under `origjar/lib/`

From `mcvl-android/`:

```bash
export ANDROID_SDK=/path/to/android-sdk
./build_apk.sh
```

The build script now:

1. Rewrites the 39 original game classes and forces the local endpoint.
2. Compiles the compatibility layer, Android app, and embedded Java server.
3. Dexes all classes with d8.
4. Packages assets/resources with aapt2.
5. zipaligns and signs with apksigner V1/V2/V3.

Output:

```text
out/MinhChuVoLam-2.0.3.apk
```
