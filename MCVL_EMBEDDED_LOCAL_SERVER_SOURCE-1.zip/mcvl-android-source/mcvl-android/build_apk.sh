#!/usr/bin/env bash
#
# Build the MCVL Android APK without Gradle, using the Android SDK command line
# tools (aapt2 + d8 + zipalign + apksigner).
#
#   javac  ->  compile the J2ME compatibility layer + Android app classes
#   d8     ->  dex the compiled classes together with the ported game bytecode
#   aapt2  ->  compile/link resources and package assets
#   zipalign + apksigner -> align and sign the APK
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK:-/workspace/android-sdk}"
ANDROID_JAR="$SDK/platforms/android-34/android.jar"
BT="$SDK/build-tools/34.0.0"
AAPT2="$BT/aapt2"
D8="$BT/d8"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"

APP="$ROOT/app/src/main"
BUILD="$ROOT/build"
OUT="$ROOT/out"
ORIG_CLASSES="$ROOT/../origjar/classes"
GAME_CLASSES="$ROOT/../origjar/classes_ported_local"
ASM_CP=$(printf '%s:' "$ROOT/../origjar/lib"/*.jar | sed 's/:$//')

rm -rf "$BUILD" "$OUT" "$GAME_CLASSES"
mkdir -p "$BUILD/app" "$BUILD/game" "$BUILD/res" "$BUILD/dex" "$OUT" "$GAME_CLASSES"

echo "==> [1/7] Rewriting game bytecode + forcing local endpoint"
javac -cp "$ASM_CP" -d "$BUILD/porttool" "$ROOT/../origjar/tools/PortTool.java"
java -cp "$BUILD/porttool:$ASM_CP" PortTool rewrite "$ORIG_CLASSES" "$GAME_CLASSES"

echo "==> [2/7] Compiling compatibility layer + app classes + embedded ServerSocket"
find "$APP/java/javax" "$APP/java/com/nokia" "$APP/java/com/mcvl/android" -name '*.java' > "$BUILD/sources.txt"
echo "$APP/java/com/mcvl/game/Res.java" >> "$BUILD/sources.txt"
javac -source 8 -target 8 -nowarn -classpath "$ANDROID_JAR" -d "$BUILD/app" @"$BUILD/sources.txt"

echo "==> [3/7] Collecting ported game bytecode"
cp "$GAME_CLASSES"/*.class "$BUILD/game/"

echo "==> [4/7] Dexing (d8)"
find "$BUILD/app" "$BUILD/game" -name '*.class' > "$BUILD/classes.txt"
"$D8" --lib "$ANDROID_JAR" --min-api 21 --output "$BUILD/dex" @"$BUILD/classes.txt"

echo "==> [5/7] Compiling resources (aapt2)"
"$AAPT2" compile --dir "$APP/res" -o "$BUILD/res.zip"

echo "==> [6/7] Linking resources + assets (aapt2 link)"
"$AAPT2" link \
    -o "$BUILD/base.apk" \
    -I "$ANDROID_JAR" \
    --manifest "$APP/AndroidManifest.xml" \
    -A "$APP/assets" \
    --min-sdk-version 21 \
    --target-sdk-version 34 \
    --version-code 3 --version-name "2.0.3" \
    "$BUILD/res.zip"

echo "==> [7/7] Packaging, aligning and signing"
cp "$BUILD/base.apk" "$BUILD/unsigned.apk"
( cd "$BUILD/dex" && zip -q -X "$BUILD/unsigned.apk" classes.dex )

"$ZIPALIGN" -f 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk"

KS="$ROOT/debug.keystore"
if [ ! -f "$KS" ]; then
    keytool -genkeypair -keystore "$KS" -alias mcvl -keyalg RSA -keysize 2048 \
        -validity 10000 -storepass android -keypass android \
        -dname "CN=MCVL Port, OU=Android, O=MCVL, L=Hanoi, C=VN" >/dev/null 2>&1
fi

"$APKSIGNER" sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
    --out "$OUT/MinhChuVoLam-2.0.3.apk" "$BUILD/aligned.apk"

echo
echo "==> APK built: $OUT/MinhChuVoLam-2.0.3.apk"
"$AAPT2" dump badging "$OUT/MinhChuVoLam-2.0.3.apk" 2>/dev/null | head -8 || true
ls -la "$OUT/"
