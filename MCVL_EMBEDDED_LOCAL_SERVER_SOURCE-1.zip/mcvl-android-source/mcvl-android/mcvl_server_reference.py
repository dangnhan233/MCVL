#!/usr/bin/env python3
"""
Minh Chu Vo Lam (MCVL) - local game server
==========================================

Server giả lập cho client "MinhChuVoLam-2.0.3-capture-v8".
Giao thức được dịch ngược từ chính APK (class l/j/f/v/c...), không có
bản capture thật của server gốc nên dữ liệu thế giới (bản đồ, chỉ số...)
đều do server này tự sinh.

Chạy:   python3 mcvl_server.py            (cổng 9001, mọi giao diện)
        python3 mcvl_server.py --port 9001 --debug

Khung gói tin
-------------
Client -> Server (mỗi lần gửi = 1 "frame"):
    u8  z(=68)  u8 A(=51)  u8 'K'|'H'  s8 aT
    u16 n  (n == 9999 -> theo sau là s64 sessionId, ngược lại là n byte session-string)
    u16 blockLen
    block: u8 count ; count x { u16 len ; len byte (u16 packetId + payload) }

Server -> Client (mỗi frame client gửi PHẢI có đúng 1 phản hồi):
    u8 'M'(77)  u8 compressed(0)  s32 len
    payload: u16 count ; count x { u16 hdr ; (u16|s32) len ; data }
        hdr: bit15 = độ dài là s32, bit14 = cờ lỗi (data bắt đầu bằng s8 code + UTF msg), bit0-13 = id
"""
import argparse
import asyncio
import io
import json
import logging
import os
import random
import secrets
import struct
import sys
import time

log = logging.getLogger("mcvl")

# --------------------------------------------------------------------------------------
#  Java DataOutputStream / DataInputStream
# --------------------------------------------------------------------------------------


class W:
    """DataOutputStream"""

    def __init__(self):
        self.b = bytearray()

    def u8(self, v):
        self.b += struct.pack(">B", v & 0xFF)
        return self

    def s8(self, v):
        self.b += struct.pack(">b", ((v + 128) % 256) - 128)
        return self

    def s16(self, v):
        self.b += struct.pack(">h", ((v + 32768) % 65536) - 32768)
        return self

    def s32(self, v):
        self.b += struct.pack(">i", ((v + 2**31) % 2**32) - 2**31)
        return self

    def s64(self, v):
        self.b += struct.pack(">q", v)
        return self

    def utf(self, s):
        d = s.encode("utf-8")
        if len(d) > 65535:
            raise ValueError("UTF too long")
        self.b += struct.pack(">H", len(d)) + d
        return self

    def raw(self, d):
        self.b += d
        return self

    def bytes(self):
        return bytes(self.b)


class R:
    """DataInputStream"""

    def __init__(self, data):
        self.d = data
        self.p = 0

    def _t(self, n):
        if self.p + n > len(self.d):
            raise EOFError("read past end")
        v = self.d[self.p:self.p + n]
        self.p += n
        return v

    def u8(self):
        return self._t(1)[0]

    def s8(self):
        return struct.unpack(">b", self._t(1))[0]

    def s16(self):
        return struct.unpack(">h", self._t(2))[0]

    def u16(self):
        return struct.unpack(">H", self._t(2))[0]

    def s32(self):
        return struct.unpack(">i", self._t(4))[0]

    def s64(self):
        return struct.unpack(">q", self._t(8))[0]

    def utf(self):
        n = self.u16()
        return self._t(n).decode("utf-8", "replace")

    def left(self):
        return len(self.d) - self.p


# --------------------------------------------------------------------------------------
#  Gói tin id
# --------------------------------------------------------------------------------------
P_LOGIN_REG_ERR = 1002
P_ACCOUNT = 1003
P_MOVE = 1005          # lệnh trong game (byte đầu = mã lệnh con)
P_ENTER = 1011
P_CREATE = 1012
P_REGISTER_G = 1018
P_CHARLIST = 1020
P_DELETE = 1024
P_FASTSTART = 1026
P_REGISTER = 1027
P_MAP = 2001
P_STATUS = 2002
P_PING = 3505
P_HELP = 9550
P_VERSION = 9950

# --------------------------------------------------------------------------------------
#  Lưu trữ (JSON đơn giản)
# --------------------------------------------------------------------------------------


class Store:
    def __init__(self, path):
        self.path = path
        self.data = {"accounts": {}, "next_pid": 1000}
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
            except Exception as e:  # noqa
                log.warning("Không đọc được %s: %s", path, e)

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def account(self, name):
        return self.data["accounts"].get(name)

    def new_pid(self):
        self.data["next_pid"] += 1
        return self.data["next_pid"]

    def find_char(self, name):
        for acc in self.data["accounts"].values():
            for ch in acc["chars"]:
                if ch and ch["name"] == name:
                    return acc, ch
        return None, None


# --------------------------------------------------------------------------------------
#  Bản đồ tự sinh (map 1: đồng cỏ + hồ nước)
#  Ô = u16:  bit0-7 chỉ số tile (1..N, 1-based, ảnh /map/1.yy có 54 tile 16x16)
#            bit8-10 lật/xoay, bit15 = ô bị chặn (không đi được)
# --------------------------------------------------------------------------------------
MAP_W = 64   # số cột (byte dd)
MAP_H = 48   # số hàng (byte de)
SPAWN_TX, SPAWN_TY = 12, 38
TILE = 16


def build_map_tiles(w=MAP_W, h=MAP_H):
    rnd = random.Random(1234)
    grass = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    flowers = [10, 11, 12, 13, 14, 15, 16]
    tiles = []
    for y in range(h):
        for x in range(w):
            t = rnd.choice(grass) if rnd.random() < 0.85 else rnd.choice(flowers)
            tiles.append(t)
    BLOCK = 0x8000
    # viền bản đồ: đá chặn
    for x in range(w):
        for y in (0, 1, h - 2, h - 1):
            tiles[y * w + x] = 17 | BLOCK
    for y in range(h):
        for x in (0, 1, w - 2, w - 1):
            tiles[y * w + x] = 18 | BLOCK
    # hồ nước ở giữa
    cx, cy = w // 2, h // 2 - 4
    for y in range(h):
        for x in range(w):
            dx, dy = (x - cx) / 9.0, (y - cy) / 5.0
            if dx * dx + dy * dy <= 1.0:
                tiles[y * w + x] = 37 | BLOCK
    # con đường cát ngang
    for x in range(2, w - 2):
        for y in (h - 8, h - 7):
            tiles[y * w + x] = 51 + (x % 3)
    return tiles


MAP_TILES = build_map_tiles()

# --------------------------------------------------------------------------------------
#  Server
# --------------------------------------------------------------------------------------


class Session:
    def __init__(self, token, account):
        self.token = token
        self.account = account
        self.sid = random.getrandbits(62)
        self.char = None
        self.px = 0
        self.py = 0
        self.in_game = False


class Server:
    def __init__(self, store, args):
        self.store = store
        self.args = args
        self.sessions = {}      # token -> Session
        self.by_sid = {}        # sid   -> Session

    # ---- tiện ích tạo gói ------------------------------------------------------------
    @staticmethod
    def err(pid, code, msg):
        return (pid, True, W().s8(code).utf(msg).bytes())

    @staticmethod
    def ok(pid, data=b""):
        return (pid, False, bytes(data))

    # ---- xử lý 1 frame ---------------------------------------------------------------
    def handle_frame(self, frame, local_addr):
        r = R(frame)
        z = r.u8()
        a = r.u8()
        kind = chr(r.u8())
        at = r.s8()
        n = r.u16()
        sess = None
        if n == 9999:
            sid = r.s64()
            sess = self.by_sid.get(sid)
        else:
            tok = r._t(n).decode("utf-8", "replace")
            sess = self.sessions.get(tok)
        blen = r.u16()
        block = R(r._t(blen))
        cnt = block.u8()
        out = []
        for _ in range(cnt):
            plen = block.u16()
            pk = R(block._t(plen))
            pid = pk.u16()
            try:
                res = self.dispatch(pid, pk, sess, local_addr)
            except EOFError:
                log.warning("gói %d bị cụt: %s", pid, pk.d.hex())
                res = []
            except Exception:
                log.exception("lỗi xử lý gói %d", pid)
                res = []
            # session có thể đổi khi login/enter
            if res and isinstance(res, tuple) and res[0] == "SESS":
                sess = res[1]
                res = res[2]
            out.extend(res or [])
        return out

    def dispatch(self, pid, pk, sess, local_addr):
        if self.args.debug:
            log.debug("<- %d %s", pid, pk.d[pk.p:].hex())
        h = {
            P_VERSION: self.h_version,
            P_ACCOUNT: self.h_account,
            P_REGISTER: self.h_register,
            P_CHARLIST: self.h_charlist,
            P_CREATE: self.h_create,
            P_DELETE: self.h_delete,
            P_ENTER: self.h_enter,
            P_HELP: self.h_help,
            P_MOVE: self.h_move,
            P_STATUS: self.h_ignore,
            P_PING: self.h_ignore,
        }.get(pid)
        if h is None:
            log.info("gói chưa hỗ trợ id=%d len=%d data=%s", pid, pk.left(), pk.d[pk.p:].hex())
            return []
        return h(pk, sess, local_addr)

    # ---- 9950: kiểm tra phiên bản + danh sách máy chủ -------------------------------
    def h_version(self, pk, sess, local):
        host = self.args.public_addr or "%s:%d" % (local[0], local[1])
        w = W()
        w.utf("11")             # phiên bản yêu cầu tối thiểu (<= 11 là ok)
        w.utf("")               # thông báo kèm theo
        servers = [("Local Server", host, 0)]
        w.s8(len(servers))
        for name, addr, st in servers:
            w.utf(name)
            w.utf(addr)
            w.s8(st)            # chỉ số trạng thái: 0 = "Tốt"
            w.s8(0)             # aT (byte tiêu đề frame)
        for _ in servers:
            w.s16(51)           # f417A
            w.s16(68)           # z
        w.s16(0)                # bảng (int,int) -> ak.af (không dùng)
        return [self.ok(P_VERSION, w.bytes())]

    # ---- 1003: tài khoản (đăng nhập / đổi mật khẩu ...) -------------------------------
    def h_account(self, pk, sess, local):
        acct = pk.utf().strip()
        op = pk.u8()
        pk.u8()                 # aE
        pk.utf()                # c.a
        pk.u8()                 # =6
        if op == 0:
            pwd = pk.utf().strip()
            ver = pk.utf()
            return self.do_login(acct, pwd)
        if op == 1:
            old = pk.utf()
            new = pk.utf()
            ac = self.store.account(acct)
            if not ac or ac["pwd"] != old:
                return [self.err(P_ACCOUNT, 2, "Mật khẩu cũ không đúng.")]
            ac["pwd"] = new
            self.store.save()
            return [self.ok(P_ACCOUNT, W().utf("Đổi mật khẩu thành công.").bytes())]
        return [self.ok(P_ACCOUNT, W().utf("Chức năng này chưa hỗ trợ trên server local.").bytes())]

    def do_login(self, acct, pwd):
        if not acct:
            return [self.err(P_ACCOUNT, 2, "Tài khoản không được để trống.")]
        ac = self.store.account(acct)
        if ac is None:
            if not self.args.auto_register:
                return [self.err(P_ACCOUNT, 2, "Tài khoản không tồn tại.")]
            ac = {"pwd": pwd, "chars": [None, None]}
            self.store.data["accounts"][acct] = ac
            self.store.save()
            log.info("tạo tài khoản mới: %s", acct)
        elif ac["pwd"] != pwd and not self.args.any_password:
            return [self.err(P_ACCOUNT, 2, "Sai mật khẩu.")]
        tok = "s_" + secrets.token_hex(12)
        s = Session(tok, acct)
        self.sessions[tok] = s
        self.by_sid[s.sid] = s
        log.info("đăng nhập: %s", acct)
        return [self.ok(P_ACCOUNT, W().utf(tok).s8(0).bytes())]

    # ---- 1027: đăng ký --------------------------------------------------------------
    def h_register(self, pk, sess, local):
        typ = pk.u8()
        if typ == 0:
            pk.u8()
            acct = pk.utf().strip()
            pwd = pk.utf().strip()
            if not acct or not pwd:
                return [self.err(P_REGISTER, 1, "Thiếu tài khoản hoặc mật khẩu.")]
            if self.store.account(acct):
                return [self.err(P_REGISTER, 1, "Tài khoản đã tồn tại.")]
            self.store.data["accounts"][acct] = {"pwd": pwd, "chars": [None, None]}
            self.store.save()
            log.info("đăng ký: %s", acct)
            return [self.ok(P_REGISTER, W().s8(0).utf("Đăng ký thành công! Hãy đăng nhập.").bytes())]
        # type 1/2: kiểm tra mã xác nhận SMS -> bỏ qua
        return [self.ok(P_REGISTER, W().s8(2).utf("").bytes())]

    # ---- 1020: danh sách nhân vật ----------------------------------------------------
    def h_charlist(self, pk, sess, local):
        if sess is None:
            return [self.err(P_CHARLIST, 1, "Phiên đăng nhập hết hạn, hãy đăng nhập lại.")]
        ac = self.store.account(sess.account)
        chars = ac["chars"]
        n = sum(1 for c in chars if c)
        w = W()
        w.s8(n)
        # client chỉ nhận n phần tử đầu và gán vào các slot 0..n-1
        for c in [c for c in chars if c]:
            w.utf(c["name"])
            w.s8(1)                     # f388R: icon trạng thái
            w.s8(c["gender"])           # f383P
            w.s8(0)                     # bỏ qua
            w.s8(c["cls"])              # f386Q
            w.s8(0)                     # f389S
            for i in range(9):          # f410s: 9 short
                w.s16(c["cls"] if i == 0 else -1)
            for i in range(9):          # f405l
                w.s8(0)
            for i in range(9):          # m
                w.s8(0)
            w.s8(-1)                    # f391T: ngày còn lại trước khi xoá (-1 = không)
            w.s32(c["c1"])              # f416v[0]
            w.s32(c["c2"])              # f416v[1]
            w.s8(c["style"])            # f394U
        w.utf("")                       # bỏ qua
        return [self.ok(P_CHARLIST, w.bytes())]

    # ---- 1012: tạo nhân vật ----------------------------------------------------------
    def h_create(self, pk, sess, local):
        if sess is None:
            return [self.err(P_CREATE, 1, "Phiên đăng nhập hết hạn.")]
        name = pk.utf().strip()
        cls = pk.s8()
        gender = pk.s8()
        c1 = pk.s32()
        c2 = pk.s32()
        style = pk.s8()
        if not (1 <= len(name) <= 16):
            return [self.err(P_CREATE, 1, "Tên nhân vật không hợp lệ.")]
        acc, ch = self.store.find_char(name)
        if ch:
            return [self.err(P_CREATE, 1, "Tên nhân vật đã có người dùng.")]
        ac = self.store.account(sess.account)
        slot = None
        for i, c in enumerate(ac["chars"]):
            if c is None:
                slot = i
                break
        if slot is None:
            return [self.err(P_CREATE, 1, "Đã đủ số nhân vật.")]
        ac["chars"][slot] = {
            "name": name, "cls": cls, "gender": gender, "c1": c1, "c2": c2, "style": style,
            "pid": self.store.new_pid(), "level": 1, "gold": 1000, "exp": 0,
            "map": 0, "tx": SPAWN_TX, "ty": SPAWN_TY,
        }
        self.store.save()
        log.info("tạo nhân vật %s (acc %s)", name, sess.account)
        return [self.ok(P_CREATE, W().s8(0).utf("Tạo nhân vật thành công!").bytes())]

    def h_delete(self, pk, sess, local):
        return [self.err(P_DELETE, 1, "Server local chưa hỗ trợ xoá nhân vật (sửa file accounts.json).")]

    # ---- 9550: dữ liệu trợ giúp ------------------------------------------------------
    def h_help(self, pk, sess, local):
        w = W()
        w.utf("")
        w.utf("")
        w.utf("")
        w.s8(0)
        w.s8(0)
        return [self.ok(P_HELP, w.bytes())]

    def h_ignore(self, pk, sess, local):
        return []

    # ---- 1011: vào game --------------------------------------------------------------
    def h_enter(self, pk, sess, local):
        pk.u8()
        acct = pk.utf()
        name = pk.utf()
        if sess is None:
            return [self.err(P_ENTER, 1, "Phiên đăng nhập hết hạn, hãy đăng nhập lại.")]
        acc, ch = self.store.find_char(name)
        if ch is None or acc is not self.store.account(sess.account):
            return [self.err(P_ENTER, 1, "Không tìm thấy nhân vật.")]
        sess.char = ch
        sess.in_game = True
        sess.px = ch["tx"] * TILE
        sess.py = ch["ty"] * TILE
        log.info("vào game: %s", name)
        return [self.ok(P_ENTER, build_enter(ch, sess))]

    # ---- 1005: lệnh trong game ---------------------------------------------------------
    def h_move(self, pk, sess, local):
        if pk.left() < 1:
            return []
        sub = pk.s8()
        if sub == -12:            # yêu cầu dữ liệu bản đồ
            if sess is None or sess.char is None:
                return []
            return [self.ok(P_MAP, build_map(sess.char)), self.ok(P_MAP, build_entities(sess.char))]
        if sub == -14:            # client báo đã nạp xong
            return []
        if sub in (0, 1, 2, 3, 4, 5, 6, 7, 8) and pk.left() >= 6:
            pk.s8()
            x = pk.s16()
            y = pk.s16()
            if sess:
                sess.px, sess.py = x, y
                if sess.char:
                    sess.char["tx"] = max(0, min(MAP_W - 1, x // TILE))
                    sess.char["ty"] = max(0, min(MAP_H - 1, y // TILE))
            return []
        if self.args.debug:
            log.debug("1005 sub=%d rest=%s", sub, pk.d[pk.p:].hex())
        return []


# --------------------------------------------------------------------------------------
#  Dựng gói 1011 (dữ liệu nhân vật khi vào game)
#  Thứ tự đọc khớp 1-1 với j.a(int,int,DataInputStream) case 1011 của client.
# --------------------------------------------------------------------------------------


def stats_block(ch):
    """byte[50]: chỉ số nhân vật, little-endian, độ rộng 4B với offset 0/4/16/20, 2B với các offset còn lại."""
    b = bytearray(50)

    def put(off, val, width):
        for i in range(width):
            b[off + i] = (val >> (8 * i)) & 0xFF

    put(0, ch.get("gold", 1000), 4)       # Vàng
    put(4, ch.get("exp", 0), 4)           # Kinh nghiệm
    put(14, ch.get("level", 1), 2)        # Cấp
    put(16, 200, 4)                       # Khí huyết
    put(20, 200, 4)                       # Khí huyết giới hạn
    put(24, 100, 2)                       # Nội lực
    put(26, 100, 2)                       # Nội lực giới hạn
    for off in (28, 30, 32, 34):          # ngoại công, gân cốt, nội công, nguyên khí
        put(off, 10, 2)
    put(36, 0, 2)                         # phối điểm
    put(40, 10, 2)                        # thân pháp
    put(42, 5, 2)                         # bạo kích
    put(44, 10, 2)                        # chính xác
    put(46, 10, 2)                        # uy lực
    return bytes(b)


def build_enter(ch, sess):
    w = W()
    w.utf("")                      # af.W
    w.s32(ch["pid"])               # af.ah  (id nhân vật)
    w.s64(0)                       # bỏ qua
    w.s8(0)                        # c.u   (số hiệu máy chủ)
    w.utf(ch["name"])              # af.name
    w.s8(ch["gender"])             # v()  giới tính
    w.s8(ch["cls"])                # u()  môn phái / thân hình
    w.s8(0)                        # bZ
    w.raw(stats_block(ch))         # 50 byte chỉ số
    w.s16(0)                       # bỏ qua
    w.s32(1000)                    # aL
    w.s16(0)                       # bP
    w.s8(0)                        # bỏ qua
    for i in range(9):             # 9 ô trang bị
        w.s32(-1)                  # id  (-1 = trống)
        w.s8(0).s8(0).s8(0).s8(0).s8(0)
    for i in range(9):             # a(int[]) : 9 short
        w.s16(-1)
    for i in range(9):             # d(byte[])
        w.s8(0)
    for i in range(9):             # c(byte[])
        w.s8(0)
    for i in range(7):             # f518aA/ k  : (int, byte)
        w.s32(0).s8(0)
    w.s16(0)                       # af.p : danh sách võ công (0 phần tử)
    for i in range(16):            # ô phím tắt
        w.s32(-1).s8(-1)
    for i in range(12):            # ab[12] : (int, byte, UTF)
        w.s32(-1).s8(-1).utf("")
    for i in range(3):             # ac[3]  : (int, byte)
        w.s32(-1).s8(-1)
    w.s32(0)                       # f268n  : chỉ số bản đồ hiện tại (0 = map 1)
    w.s16(ch["tx"] * TILE)         # f260l  : x (pixel)
    w.s16(ch["ty"] * TILE)         # f265m  : y (pixel)
    w.s32(-1).s8(0).s8(0)          # (cưỡi / bang?) -1 = không
    w.s32(-1)                      # bF  (<0 : không có)
    w.s16(0)                       # độ dài ảnh avatar (0 = không)
    w.s32(0)                       # bL
    w.s16(0)                       # af.q : bảng kỹ năng (0 phần tử)
    w.s16(1)                       # ak.af : n
    w.s32(0).s32(0)
    # bảng bản đồ c.f241g : [fileId, mon1, mon2, mdatId]
    maps = [(1, -1, -1, 1)]
    w.s16(len(maps))
    for _ in maps:
        w.s8(0)                    # skipBytes(n) : mỗi map 1 byte
    w.s8(0)                        # +1 byte
    for m in maps:
        for v in m:
            w.s16(v)
    w.s8(0)                        # c.s
    w.s8(0)                        # c.n
    w.s8(0)                        # af.ad : 0 nhóm
    w.s8(0)                        # c.f245h : 0 phần tử
    for i in range(6):             # B C D F E G
        w.s32(0)
    w.s64(sess.sid)                # l.b  : session id (dùng ở tiêu đề các frame sau)
    w.utf(sess.token)              # l.C
    w.s8(0)                        # (available()>0 -> đọc 1 byte)
    w.s16(0)                       # bm
    w.s16(0)                       # bl
    w.s8(0)                        # af.P : không có
    w.s8(0)                        # af.S : không có
    w.s8(0)                        # bỏ qua
    w.s8(0)                        # n mục c.f165i... = 0
    w.s32(0)                       # bN
    w.s32(0)                       # bO
    w.s8(0)                        # ey
    w.s8(0)                        # p
    w.s8(0)                        # c.f132a : 0 cặp (UTF,UTF)
    w.s8(0)                        # c.f138b : 0 cặp
    w.s8(0)                        # c.f141c : 0
    w.s8(0)                        # c.f145d : 0
    w.s8(0)                        # c.o
    return w.bytes()


# --------------------------------------------------------------------------------------
#  Gói 2001: bản đồ + thực thể
# --------------------------------------------------------------------------------------


def build_map(ch):
    w = W()
    w.s8(1)                                # loại 1 = dữ liệu bản đồ
    w.s32(1)                               # aU
    w.s32(0)                               # f268n (chỉ số trong bảng bản đồ)
    w.s16(0)                               # f78bp
    w.s16(0)                               # aV
    w.s16(0)                               # bỏ qua
    w.utf("Đồng cỏ khởi đầu")              # aj : tên bản đồ
    w.s8(0)                                # cL
    w.s8(0)                                # cM
    w.s16(SPAWN_TY * MAP_W + SPAWN_TX)     # aE : ô xuất hiện
    w.s16(0)                               # bỏ qua
    for _ in range(4):
        w.s16(0).s16(0).utf("")
    w.s16(0)                               # bỏ qua
    w.s8(MAP_H)                            # de : số hàng
    w.s8(MAP_W)                            # dd : số cột
    w.s8(1)                                # df : số lớp
    for t in MAP_TILES:
        w.s16(t)
    w.s16(0)                               # bỏ qua
    for _ in range(3):                     # f543a[3][]
        w.s16(0)
    w.s16(0)                               # số ô bị đánh dấu thêm
    w.s16(0)                               # z[] rỗng
    w.s8(0)                                # c(): 0 = dùng ảnh bản đồ đóng gói trong APK
    w.s16(ch["ty"] * MAP_W + ch["tx"])     # f568aP : ô nhân vật
    w.utf("")                              # s
    return w.bytes()


def build_entities(ch):
    w = W()
    w.s8(0)        # loại 0 ; w.dC = 0 (không có quái)
    w.s8(0)        # NPC: 0
    w.s8(0)        # f(): 0
    w.s8(0)        # aD : 0
    return w.bytes()


# --------------------------------------------------------------------------------------
#  Tầng TCP
# --------------------------------------------------------------------------------------


def encode_response(packets):
    body = W()
    body.s16(len(packets))
    for pid, is_err, data in packets:
        hdr = pid & 0x3FFF
        if is_err:
            hdr |= 0x4000
        if len(data) >= 0x7FFF:
            body.u8(((hdr | 0x8000) >> 8) & 0xFF).u8(hdr & 0xFF)
            body.s32(len(data))
        else:
            body.s16(hdr if hdr < 0x8000 else hdr - 0x10000)
            body.s16(len(data))
        body.raw(data)
    payload = body.bytes() if packets else b""
    out = W()
    out.u8(77).u8(0).s32(len(payload)).raw(payload)
    return out.bytes()


async def read_frame(reader):
    """Đọc đúng 1 frame của client (xem phần đầu file)."""
    head = await reader.readexactly(4)          # z A K aT
    nb = await reader.readexactly(2)
    n = struct.unpack(">H", nb)[0]
    if n == 9999:
        mid = await reader.readexactly(8)
    else:
        mid = await reader.readexactly(n)
    bl = await reader.readexactly(2)
    blen = struct.unpack(">H", bl)[0]
    block = await reader.readexactly(blen)
    return head + nb + mid + bl + block


async def client_loop(server, reader, writer):
    peer = writer.get_extra_info("peername")
    local = writer.get_extra_info("sockname")
    log.info("kết nối từ %s", peer)
    try:
        while True:
            frame = await read_frame(reader)
            try:
                pkts = server.handle_frame(frame, local)
            except Exception:
                log.exception("lỗi frame")
                pkts = []
            if server.args.debug:
                for pid, e, d in pkts:
                    log.debug("-> %d%s %s", pid, " (ERR)" if e else "", d.hex()[:200])
            writer.write(encode_response(pkts))
            await writer.drain()
    except (asyncio.IncompleteReadError, ConnectionResetError, BrokenPipeError):
        pass
    finally:
        log.info("ngắt kết nối %s", peer)
        try:
            writer.close()
        except Exception:
            pass


async def amain(args):
    store = Store(args.db)
    server = Server(store, args)
    srv = await asyncio.start_server(lambda r, w: client_loop(server, r, w), args.host, args.port)
    addrs = ", ".join(str(s.getsockname()) for s in srv.sockets)
    log.info("MCVL server đang chạy tại %s", addrs)
    log.info("Dữ liệu tài khoản: %s", os.path.abspath(args.db))
    async with srv:
        await srv.serve_forever()


def main():
    ap = argparse.ArgumentParser(description="MCVL local server")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=9001)
    ap.add_argument("--db", default="accounts.json")
    ap.add_argument("--public-addr", default="", help="địa chỉ ip:port ghi trong danh sách máy chủ (mặc định: tự lấy theo kết nối)")
    ap.add_argument("--no-auto-register", dest="auto_register", action="store_false",
                    help="không tự tạo tài khoản khi đăng nhập tên lạ")
    ap.add_argument("--any-password", action="store_true", help="bỏ qua kiểm tra mật khẩu")
    ap.add_argument("--debug", action="store_true", help="in hex từng gói tin")
    args = ap.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
    try:
        asyncio.run(amain(args))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
