package javax.microedition.media;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ToneGenerator;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** J2ME (MMAPI) {@code Manager}. */
public final class Manager {

    private static Context context;

    private Manager() {
    }

    public static void setContext(Context ctx) {
        context = ctx;
    }

    public static Player createPlayer(String locator) throws IOException, MediaException {
        return new AndroidPlayer(locator, null, null);
    }

    public static Player createPlayer(String locator, long time) throws IOException, MediaException {
        return new AndroidPlayer(locator, null, null);
    }

    public static Player createPlayer(InputStream stream, String type) throws IOException, MediaException {
        if (stream == null) {
            throw new MediaException("null stream");
        }
        byte[] data = readAll(stream);
        return new AndroidPlayer(null, data, type);
    }

    public static void playTone(int note, int duration, int volume) throws MediaException {
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, Math.max(1, volume));
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, duration);
            tg.release();
        } catch (Exception e) {
            throw new MediaException(e.getMessage());
        }
    }

    public static String[] getSupportedContentTypes(String protocol) {
        return new String[]{"audio/x-wav", "audio/midi", "audio/mpeg"};
    }

    public static String[] getSupportedProtocols(String contentType) {
        return new String[]{"file", "http"};
    }

    private static byte[] readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            try {
                in.close();
            } catch (IOException ignored) {
            }
        }
    }

    static Context getContext() {
        return context;
    }

    /** Concrete player backed by Android's {@link MediaPlayer}. */
    static final class AndroidPlayer implements Player, javax.microedition.media.control.VolumeControl {

        private MediaPlayer mp;
        private int state = UNREALIZED;
        private int loopCount = 1;
        private int level = 100;
        private boolean muted;
        private final String contentType;

        AndroidPlayer(String locator, byte[] data, String type) {
            this.contentType = type;
            try {
                if (locator != null) {
                    mp = new MediaPlayer();
                    mp.setDataSource(locator);
                    mp.prepare();
                    state = PREFETCHED;
                } else if (data != null && context != null) {
                    File tmp = File.createTempFile("mcvl_", ext(type), context.getCacheDir());
                    FileOutputStream fos = new FileOutputStream(tmp);
                    fos.write(data);
                    fos.close();
                    mp = new MediaPlayer();
                    mp.setDataSource(tmp.getAbsolutePath());
                    mp.prepare();
                    state = PREFETCHED;
                    tmp.deleteOnExit();
                }
            } catch (Exception e) {
                // MIDI (and other unsupported formats) simply degrade to silence.
                mp = null;
                state = UNREALIZED;
            }
        }

        private static String ext(String type) {
            if (type == null) {
                return ".tmp";
            }
            if (type.contains("wav")) {
                return ".wav";
            }
            if (type.contains("midi") || type.contains("mid")) {
                return ".mid";
            }
            if (type.contains("mpeg") || type.contains("mp3")) {
                return ".mp3";
            }
            return ".tmp";
        }

        public void realize() throws MediaException {
            if (state == UNREALIZED) {
                state = REALIZED;
            }
        }

        public void prefetch() throws MediaException {
            if (state == REALIZED || state == UNREALIZED) {
                state = PREFETCHED;
            }
        }

        public void start() throws MediaException {
            if (mp == null) {
                state = STARTED;
                return;
            }
            try {
                if (loopCount == -1) {
                    mp.setLooping(true);
                } else {
                    mp.setLooping(loopCount > 1);
                }
                mp.setVolume(muted ? 0f : level / 100f, muted ? 0f : level / 100f);
                mp.start();
                state = STARTED;
            } catch (Exception e) {
                throw new MediaException(e.getMessage());
            }
        }

        public void stop() throws MediaException {
            if (mp != null) {
                try {
                    mp.pause();
                } catch (Exception ignored) {
                }
            }
            state = PREFETCHED;
        }

        public void deallocate() {
            if (mp != null) {
                try {
                    mp.reset();
                } catch (Exception ignored) {
                }
            }
            state = REALIZED;
        }

        public void close() {
            if (mp != null) {
                try {
                    mp.release();
                } catch (Exception ignored) {
                }
                mp = null;
            }
            state = CLOSED;
        }

        public void setLoopCount(int count) {
            this.loopCount = count;
        }

        public void setMediaTime(long now) throws MediaException {
            if (mp != null) {
                try {
                    mp.seekTo((int) now);
                } catch (Exception ignored) {
                }
            }
        }

        public long getMediaTime() {
            if (mp != null) {
                try {
                    return mp.getCurrentPosition();
                } catch (Exception ignored) {
                }
            }
            return 0;
        }

        public long getDuration() {
            if (mp != null) {
                try {
                    return mp.getDuration();
                } catch (Exception ignored) {
                }
            }
            return TIME_UNKNOWN;
        }

        public String getContentType() {
            return contentType;
        }

        public void addPlayerListener(PlayerListener playerListener) {
        }

        public void removePlayerListener(PlayerListener playerListener) {
        }

        public Control getControl(String controlType) {
            if (controlType != null && controlType.endsWith("VolumeControl")) {
                return this;
            }
            return null;
        }

        public Control[] getControls() {
            return new Control[]{this};
        }

        // ---- VolumeControl ---------------------------------------------------

        public void setMute(boolean mute) {
            this.muted = mute;
            if (mp != null) {
                mp.setVolume(mute ? 0f : level / 100f, mute ? 0f : level / 100f);
            }
        }

        public boolean isMuted() {
            return muted;
        }

        public int setLevel(int level) {
            this.level = Math.max(0, Math.min(100, level));
            if (mp != null) {
                mp.setVolume(muted ? 0f : this.level / 100f, muted ? 0f : this.level / 100f);
            }
            return this.level;
        }

        public int getLevel() {
            return level;
        }
    }
}
