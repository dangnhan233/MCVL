package javax.microedition.lcdui;

import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;

/**
 * J2ME (MIDP) {@code Font} re-implemented on top of Android's {@link Paint}.
 *
 * <p>The original game only ever requests the small system font, but the full
 * MIDP 1.0 surface is provided so that the ported game code keeps compiling and
 * behaving as it did on a feature phone.</p>
 */
public final class Font {

    // ---- MIDP face constants -------------------------------------------------
    public static final int FACE_SYSTEM = 0;
    public static final int FACE_MONOSPACE = 32;
    public static final int FACE_PROPORTIONAL = 64;

    // ---- MIDP style constants ------------------------------------------------
    public static final int STYLE_PLAIN = 0;
    public static final int STYLE_BOLD = 1;
    public static final int STYLE_ITALIC = 2;
    public static final int STYLE_UNDERLINED = 4;

    // ---- MIDP size constants -------------------------------------------------
    public static final int SIZE_SMALL = 8;
    public static final int SIZE_MEDIUM = 0;
    public static final int SIZE_LARGE = 16;

    private static final int FACE_MASK = 96;   // 0x60
    private static final int STYLE_MASK = 7;   // 0x07
    private static final int SIZE_MASK = 24;   // 0x18

    private static Font defaultFont;

    private final int face;
    private final int style;
    private final int size;

    /** Underlying Android paint used both for measuring and drawing. */
    final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Font(int face, int style, int size) {
        this.face = face & FACE_MASK;
        this.style = style & STYLE_MASK;
        this.size = size & SIZE_MASK;

        int textSize;
        switch (this.size) {
            case SIZE_LARGE:
                textSize = 18;
                break;
            case SIZE_MEDIUM:
                textSize = 14;
                break;
            case SIZE_SMALL:
            default:
                textSize = 11;
                break;
        }
        paint.setTextSize(textSize);
        paint.setFakeBoldText((this.style & STYLE_BOLD) != 0);
        paint.setTextSkewX((this.style & STYLE_ITALIC) != 0 ? -0.25f : 0f);
        paint.setUnderlineText((this.style & STYLE_UNDERLINED) != 0);

        Typeface tf;
        if (this.face == FACE_MONOSPACE) {
            tf = Typeface.MONOSPACE;
        } else {
            tf = Typeface.SANS_SERIF;
        }
        if ((this.style & STYLE_BOLD) != 0) {
            tf = Typeface.create(tf, Typeface.BOLD);
        }
        if ((this.style & STYLE_ITALIC) != 0) {
            tf = Typeface.create(tf, Typeface.ITALIC);
        }
        paint.setTypeface(tf);
    }

    public static Font getFont(int face, int style, int size) {
        // MIDP caches fonts; a small cache keeps allocations down on the render thread.
        return new Font(face, style, size);
    }

    public static Font getDefaultFont() {
        if (defaultFont == null) {
            defaultFont = new Font(FACE_SYSTEM, STYLE_PLAIN, SIZE_MEDIUM);
        }
        return defaultFont;
    }

    public int getFace() {
        return face;
    }

    public int getStyle() {
        return style;
    }

    public int getSize() {
        return size;
    }

    public boolean isPlain() {
        return style == STYLE_PLAIN;
    }

    public boolean isBold() {
        return (style & STYLE_BOLD) != 0;
    }

    public boolean isItalic() {
        return (style & STYLE_ITALIC) != 0;
    }

    public boolean isUnderlined() {
        return (style & STYLE_UNDERLINED) != 0;
    }

    public int getHeight() {
        Paint.FontMetricsInt fm = paint.getFontMetricsInt();
        return fm.descent - fm.ascent;
    }

    public int getBaselinePosition() {
        return -paint.getFontMetricsInt().ascent;
    }

    public int charWidth(char ch) {
        return (int) Math.ceil(paint.measureText(String.valueOf(ch)));
    }

    public int charsWidth(char[] ch, int offset, int length) {
        return (int) Math.ceil(paint.measureText(ch, offset, length));
    }

    public int stringWidth(String str) {
        if (str == null) {
            return 0;
        }
        return (int) Math.ceil(paint.measureText(str));
    }

    public int substringWidth(String str, int offset, int length) {
        return (int) Math.ceil(paint.measureText(str, offset, offset + length));
    }

    public int getPointSize() {
        return (int) paint.getTextSize();
    }

    /** Helper used by {@link Graphics} for text drawing. */
    Rect measureBounds(String str) {
        Rect r = new Rect();
        paint.getTextBounds(str, 0, str.length(), r);
        return r;
    }
}
