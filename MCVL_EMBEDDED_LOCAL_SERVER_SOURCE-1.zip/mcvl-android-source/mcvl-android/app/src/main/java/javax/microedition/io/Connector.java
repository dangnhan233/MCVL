package javax.microedition.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * J2ME (CLDC) {@code Connector}.
 *
 * <p>This port implements the {@code socket://} protocol on top of
 * {@link java.net.Socket} and delegates {@code sms://} to the
 * {@code javax.wireless.messaging} compatibility layer. Other protocols raise
 * {@link ConnectionNotFoundException}, which the original game already handles
 * defensively.</p>
 */
public final class Connector {

    public static final int READ = 1;
    public static final int WRITE = 2;
    public static final int READ_WRITE = 3;

    private Connector() {
    }

    public static Connection open(String name) throws IOException {
        return open(name, READ_WRITE, false);
    }

    public static Connection open(String name, int mode) throws IOException {
        return open(name, mode, false);
    }

    public static Connection open(String name, int mode, boolean timeouts) throws IOException {
        if (name == null) {
            throw new IllegalArgumentException("null connection name");
        }
        if (name.startsWith("socket://")) {
            return new SocketConnectionImpl(name);
        }
        if (name.startsWith("sms://")) {
            return new javax.wireless.messaging.MessageConnectionImpl(name);
        }
        throw new ConnectionNotFoundException("Unsupported protocol: " + name);
    }

    public static InputStream openInputStream(String name) throws IOException {
        return ((InputConnection) open(name, READ)).openInputStream();
    }

    public static DataInputStream openDataInputStream(String name) throws IOException {
        return ((InputConnection) open(name, READ)).openDataInputStream();
    }

    public static OutputStream openOutputStream(String name) throws IOException {
        return ((OutputConnection) open(name, WRITE)).openOutputStream();
    }

    public static DataOutputStream openDataOutputStream(String name) throws IOException {
        return ((OutputConnection) open(name, WRITE)).openDataOutputStream();
    }

    /** Concrete {@link SocketConnection} backed by {@link java.net.Socket}. */
    static final class SocketConnectionImpl implements SocketConnection {

        private final java.net.Socket socket;
        private final String host;
        private final int port;
        private int delay;
        private int linger = -1;
        private boolean keepAlive;
        private int rcvbuf;
        private int sndbuf;

        SocketConnectionImpl(String url) throws IOException {
            // socket://host:port
            String rest = url.substring("socket://".length());
            int colon = rest.lastIndexOf(':');
            if (colon < 0) {
                throw new ConnectionNotFoundException("Malformed socket URL: " + url);
            }
            this.host = rest.substring(0, colon);
            this.port = Integer.parseInt(rest.substring(colon + 1));
            this.socket = new java.net.Socket();
            this.socket.setTcpNoDelay(true);
            this.socket.setKeepAlive(true);
            this.socket.connect(new java.net.InetSocketAddress(host, port), 10000);
        }

        public InputStream openInputStream() throws IOException {
            return socket.getInputStream();
        }

        public DataInputStream openDataInputStream() throws IOException {
            return new DataInputStream(socket.getInputStream());
        }

        public OutputStream openOutputStream() throws IOException {
            return socket.getOutputStream();
        }

        public DataOutputStream openDataOutputStream() throws IOException {
            return new DataOutputStream(socket.getOutputStream());
        }

        public void setSocketOption(byte option, int value) throws IOException {
            switch (option) {
                case DELAY:
                    delay = value;
                    socket.setTcpNoDelay(value == 0);
                    break;
                case LINGER:
                    linger = value;
                    socket.setSoLinger(value > 0, value);
                    break;
                case KEEPALIVE:
                    keepAlive = value != 0;
                    socket.setKeepAlive(keepAlive);
                    break;
                case RCVBUF:
                    rcvbuf = value;
                    socket.setReceiveBufferSize(value);
                    break;
                case SNDBUF:
                    sndbuf = value;
                    socket.setSendBufferSize(value);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown option: " + option);
            }
        }

        public int getSocketOption(byte option) throws IOException {
            switch (option) {
                case DELAY:
                    return delay;
                case LINGER:
                    return linger;
                case KEEPALIVE:
                    return keepAlive ? 1 : 0;
                case RCVBUF:
                    return socket.getReceiveBufferSize();
                case SNDBUF:
                    return socket.getSendBufferSize();
                default:
                    throw new IllegalArgumentException("Unknown option: " + option);
            }
        }

        public String getLocalAddress() throws IOException {
            return socket.getLocalAddress().getHostAddress();
        }

        public int getLocalPort() throws IOException {
            return socket.getLocalPort();
        }

        public String getAddress() throws IOException {
            return host;
        }

        public int getPort() throws IOException {
            return port;
        }

        public void close() throws IOException {
            socket.close();
        }
    }
}
