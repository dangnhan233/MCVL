package javax.microedition.lcdui;

/** J2ME (MIDP) {@code Command}. */
public class Command {

    public static final int SCREEN = 1;
    public static final int BACK = 2;
    public static final int CANCEL = 3;
    public static final int OK = 4;
    public static final int HELP = 5;
    public static final int STOP = 6;
    public static final int EXIT = 7;
    public static final int ITEM = 8;

    private final String label;
    private final String longLabel;
    private final int type;
    private final int priority;

    public Command(String label, int commandType, int priority) {
        this(label, null, commandType, priority);
    }

    public Command(String shortLabel, String longLabel, int commandType, int priority) {
        this.label = shortLabel == null ? "" : shortLabel;
        this.longLabel = longLabel;
        this.type = commandType;
        this.priority = priority;
    }

    public String getLabel() {
        return label;
    }

    public String getLongLabel() {
        return longLabel == null ? label : longLabel;
    }

    public int getCommandType() {
        return type;
    }

    public int getPriority() {
        return priority;
    }
}
