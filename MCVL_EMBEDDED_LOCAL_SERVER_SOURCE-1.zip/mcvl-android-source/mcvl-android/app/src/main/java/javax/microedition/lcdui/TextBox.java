package javax.microedition.lcdui;

/** J2ME (MIDP) {@code TextBox} — an editable text screen. */
public class TextBox extends Screen {

    private String text;
    private int maxSize;
    private int constraints;
    private int caret;

    public TextBox(String title, String text, int maxSize, int constraints) {
        setTitle(title);
        this.text = text == null ? "" : text;
        this.maxSize = maxSize;
        this.constraints = constraints;
        if (this.text.length() > maxSize) {
            this.text = this.text.substring(0, maxSize);
        }
    }

    public String getString() {
        return text;
    }

    public void setString(String text) {
        this.text = text == null ? "" : text;
        if (this.text.length() > maxSize) {
            this.text = this.text.substring(0, maxSize);
        }
    }

    public int getMaxSize() {
        return maxSize;
    }

    public int setMaxSize(int maxSize) {
        this.maxSize = maxSize;
        return maxSize;
    }

    public int getConstraints() {
        return constraints;
    }

    public void setConstraints(int constraints) {
        this.constraints = constraints;
    }

    public int size() {
        return text.length();
    }

    public int getChars(char[] data) {
        int len = Math.min(data.length, text.length());
        text.getChars(0, len, data, 0);
        return len;
    }

    public void setChars(char[] data, int offset, int length) {
        text = data == null ? "" : new String(data, offset, length);
    }

    public void insert(String src, int position) {
        text = text.substring(0, position) + src + text.substring(position);
    }

    public void insert(char[] data, int offset, int length, int position) {
        insert(new String(data, offset, length), position);
    }

    public void delete(int offset, int length) {
        text = text.substring(0, offset) + text.substring(offset + length);
    }

    public int getCaretPosition() {
        return caret;
    }

    public void setCaretPosition(int position) {
        this.caret = position;
    }
}
