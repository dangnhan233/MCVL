package javax.microedition.lcdui;

import java.util.Vector;

/** J2ME (MIDP) {@code Form} — a screen composed of {@link Item}s. */
public class Form extends Screen {

    private final Vector<Item> items = new Vector<Item>();

    public Form(String title) {
        setTitle(title);
    }

    public Form(String title, Item[] items) {
        setTitle(title);
        if (items != null) {
            for (Item item : items) {
                append(item);
            }
        }
    }

    public int append(Item item) {
        items.addElement(item);
        if (item != null) {
            item.listener = itemStateListener;
        }
        return items.size() - 1;
    }

    public int append(String str) {
        return append(new StringItem(null, str));
    }

    public int append(Image img) {
        return append(new ImageItem(null, img, ImageItem.LAYOUT_DEFAULT, null));
    }

    public void insert(int index, Item item) {
        items.insertElementAt(item, index);
    }

    public void delete(int index) {
        items.removeElementAt(index);
    }

    public void deleteAll() {
        items.removeAllElements();
    }

    public void set(int index, Item item) {
        items.setElementAt(item, index);
    }

    public Item get(int index) {
        return items.elementAt(index);
    }

    public int size() {
        return items.size();
    }

    private ItemStateListener itemStateListener;

    public void setItemStateListener(ItemStateListener listener) {
        this.itemStateListener = listener;
        for (int i = 0; i < items.size(); i++) {
            items.elementAt(i).listener = listener;
        }
    }

    /** Exposes the item list to the host dialog renderer. */
    public Vector<Item> getItems() {
        return items;
    }
}
