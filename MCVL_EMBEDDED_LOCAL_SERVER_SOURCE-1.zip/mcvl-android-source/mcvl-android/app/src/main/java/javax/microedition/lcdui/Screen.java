package javax.microedition.lcdui;

/** J2ME (MIDP) {@code Screen} — a displayable with a title and an optional ticker. */
public abstract class Screen extends Displayable {

    Screen() {
        super();
    }
}
