package javax.wireless.messaging;

import java.io.IOException;
import java.util.Date;

/**
 * Minimal WMA {@link MessageConnection} implementation.
 *
 * <p>The original game only uses SMS as an optional "invite a friend" feature.
 * On modern Android sending SMS requires the {@code SEND_SMS} runtime permission
 * and a user grant, so this implementation is intentionally a no-op transport
 * that keeps the exact J2ME contract: messages can be created, filled and
 * "sent" without throwing, which is what the game expects.</p>
 */
public final class MessageConnectionImpl implements MessageConnection {

    private final String address;
    private MessageListener listener;

    public MessageConnectionImpl(String url) {
        // sms://[+number]
        this.address = url != null && url.length() > 6 ? url.substring(6) : "";
    }

    public Message newMessage(String type) {
        return newMessage(type, address);
    }

    public Message newMessage(String type, String address) {
        if (BINARY_MESSAGE.equals(type)) {
            return new BinaryMessageImpl(address);
        }
        return new TextMessageImpl(address);
    }

    public int numberOfSegments(Message message) {
        if (message instanceof TextMessage) {
            String text = ((TextMessage) message).getPayloadText();
            if (text == null) {
                return 0;
            }
            return Math.max(1, (text.length() + 159) / 160);
        }
        return 1;
    }

    public Message receive() throws IOException {
        throw new IOException("No inbound messages");
    }

    public void send(Message message) throws IOException {
        // Transport is a no-op in this port; see class javadoc.
    }

    public void setMessageListener(MessageListener listener) throws IOException {
        this.listener = listener;
    }

    public void close() throws IOException {
        this.listener = null;
    }

    // ------------------------------------------------------------------ impls

    static final class TextMessageImpl implements TextMessage {
        private String address;
        private String payload = "";
        private final Date timestamp = new Date();

        TextMessageImpl(String address) {
            this.address = address;
        }

        public String getPayloadText() {
            return payload;
        }

        public void setPayloadText(String data) {
            this.payload = data == null ? "" : data;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String addr) {
            this.address = addr;
        }

        public Date getTimestamp() {
            return timestamp;
        }
    }

    static final class BinaryMessageImpl implements BinaryMessage {
        private String address;
        private byte[] payload = new byte[0];
        private final Date timestamp = new Date();

        BinaryMessageImpl(String address) {
            this.address = address;
        }

        public byte[] getPayloadData() {
            return payload;
        }

        public void setPayloadData(byte[] data) {
            this.payload = data == null ? new byte[0] : data;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String addr) {
            this.address = addr;
        }

        public Date getTimestamp() {
            return timestamp;
        }
    }
}
