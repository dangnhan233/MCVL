package javax.microedition.io;

/** J2ME (CLDC) {@code ContentConnection}. */
public interface ContentConnection extends StreamConnection {
    String getType();

    String getEncoding();

    long getLength();
}
