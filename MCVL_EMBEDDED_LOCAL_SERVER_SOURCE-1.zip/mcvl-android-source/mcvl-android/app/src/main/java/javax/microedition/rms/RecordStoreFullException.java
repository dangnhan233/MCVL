package javax.microedition.rms;

/** J2ME (RMS) {@code RecordStoreFullException}. */
public class RecordStoreFullException extends RecordStoreException {
    public RecordStoreFullException() {
        super();
    }

    public RecordStoreFullException(String message) {
        super(message);
    }
}
