package javax.microedition.lcdui;

/** J2ME (MIDP) {@code Alert} — a transient message screen. */
public class Alert extends Screen {

    public static final int FOREVER = -2;
    public static final int DEFAULT_TIMEOUT = 2000;

    private String string;
    private Image image;
    private AlertType type;
    private int timeout = DEFAULT_TIMEOUT;

    public Alert(String title) {
        this(title, null, null, null);
    }

    public Alert(String title, String alertText, Image alertImage, AlertType alertType) {
        setTitle(title);
        this.string = alertText;
        this.image = alertImage;
        this.type = alertType;
    }

    public String getString() {
        return string;
    }

    public void setString(String str) {
        this.string = str;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image img) {
        this.image = img;
    }

    public AlertType getType() {
        return type;
    }

    public void setType(AlertType type) {
        this.type = type;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int time) {
        this.timeout = time;
    }

    public void setIndicator(Object indicator) {
    }
}
