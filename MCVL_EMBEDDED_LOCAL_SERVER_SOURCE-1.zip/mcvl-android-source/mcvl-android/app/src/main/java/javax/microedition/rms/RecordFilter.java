package javax.microedition.rms;

/** J2ME (RMS) {@code RecordFilter}. */
public interface RecordFilter {
    boolean matches(byte[] candidate);
}
