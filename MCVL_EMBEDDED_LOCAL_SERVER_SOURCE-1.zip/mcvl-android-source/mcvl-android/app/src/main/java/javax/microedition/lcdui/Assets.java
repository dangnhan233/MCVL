package javax.microedition.lcdui;

import android.content.res.AssetManager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Bridge between the J2ME resource model ({@code getResourceAsStream("/img/...")})
 * and Android's {@link AssetManager}.
 *
 * <p>All of the original game resources live under {@code app/src/main/assets}.
 * The MIDlet used to read them from the JAR classpath; here they are served from
 * the APK assets instead.</p>
 */
public final class Assets {

    /** PNG signature that the {@code .yy}/{@code .myy} containers strip out. */
    static final byte[] PNG_SIGNATURE = {
            (byte) 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
    };

    private static AssetManager assetManager;

    private Assets() {
    }

    public static void init(AssetManager am) {
        assetManager = am;
    }

    public static boolean isReady() {
        return assetManager != null;
    }

    /** Opens a raw asset stream, or {@code null} when the asset is missing. */
    public static InputStream open(String path) {
        if (assetManager == null || path == null) {
            return null;
        }
        String clean = path.startsWith("/") ? path.substring(1) : path;
        try {
            return assetManager.open(clean);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Reads a game image. The original {@code .yy}/{@code .myy} files are PNGs
     * with the 8 byte signature removed and a big-endian length prefix added.
     * Plain PNGs are returned untouched.
     */
    public static byte[] readImageBytes(String path) throws IOException {
        InputStream in = open(path);
        if (in == null) {
            throw new IOException("Asset not found: " + path);
        }
        try {
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                raw.write(buf, 0, n);
            }
            byte[] data = raw.toByteArray();
            return normalizePng(data);
        } finally {
            try {
                in.close();
            } catch (IOException ignored) {
            }
        }
    }

    /** Re-attaches the PNG signature to a stripped {@code .yy} blob when needed. */
    public static byte[] normalizePng(byte[] data) {
        if (data == null || data.length == 0) {
            return data;
        }
        if (startsWith(data, PNG_SIGNATURE)) {
            return data;
        }
        if (data.length >= 4) {
            int len = ((data[0] & 0xFF) << 24) | ((data[1] & 0xFF) << 16)
                    | ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);
            if (len > 0 && len <= data.length - 4) {
                byte[] out = new byte[len + PNG_SIGNATURE.length];
                System.arraycopy(PNG_SIGNATURE, 0, out, 0, PNG_SIGNATURE.length);
                System.arraycopy(data, 4, out, PNG_SIGNATURE.length, len);
                return out;
            }
        }
        return data;
    }

    private static boolean startsWith(byte[] data, byte[] prefix) {
        if (data.length < prefix.length) {
            return false;
        }
        for (int i = 0; i < prefix.length; i++) {
            if (data[i] != prefix[i]) {
                return false;
            }
        }
        return true;
    }

    public static InputStream openImageStream(String path) throws IOException {
        return new ByteArrayInputStream(readImageBytes(path));
    }
}
