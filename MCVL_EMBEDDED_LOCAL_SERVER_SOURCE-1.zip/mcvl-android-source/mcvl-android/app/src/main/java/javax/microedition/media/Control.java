package javax.microedition.media;

/** J2ME (MMAPI) {@code Control}. */
public interface Control {
}
