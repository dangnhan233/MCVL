package javax.microedition.lcdui;

import java.util.Vector;

/** J2ME (MIDP) {@code ChoiceGroup}. */
public class ChoiceGroup extends Item implements Choice {

    private final int choiceType;
    private final Vector<String> strings = new Vector<String>();
    private final Vector<Image> images = new Vector<Image>();
    private final Vector<Boolean> selected = new Vector<Boolean>();

    public ChoiceGroup(String label, int choiceType) {
        setLabel(label);
        this.choiceType = choiceType;
    }

    public ChoiceGroup(String label, int choiceType, String[] stringElements, Image[] imageElements) {
        setLabel(label);
        this.choiceType = choiceType;
        if (stringElements != null) {
            for (int i = 0; i < stringElements.length; i++) {
                Image img = (imageElements != null && i < imageElements.length) ? imageElements[i] : null;
                append(stringElements[i], img);
            }
        }
    }

    public int getType() {
        return choiceType;
    }

    public int size() {
        return strings.size();
    }

    public String getString(int elementNum) {
        return strings.elementAt(elementNum);
    }

    public Image getImage(int elementNum) {
        return images.elementAt(elementNum);
    }

    public int append(String stringPart, Image imagePart) {
        strings.addElement(stringPart == null ? "" : stringPart);
        images.addElement(imagePart);
        selected.addElement(Boolean.FALSE);
        if (choiceType == EXCLUSIVE && strings.size() == 1) {
            selected.setElementAt(Boolean.TRUE, 0);
        }
        return strings.size() - 1;
    }

    public void insert(int elementNum, String stringPart, Image imagePart) {
        strings.insertElementAt(stringPart == null ? "" : stringPart, elementNum);
        images.insertElementAt(imagePart, elementNum);
        selected.insertElementAt(Boolean.FALSE, elementNum);
    }

    public void delete(int elementNum) {
        strings.removeElementAt(elementNum);
        images.removeElementAt(elementNum);
        selected.removeElementAt(elementNum);
    }

    public void deleteAll() {
        strings.removeAllElements();
        images.removeAllElements();
        selected.removeAllElements();
    }

    public void set(int elementNum, String stringPart, Image imagePart) {
        strings.setElementAt(stringPart == null ? "" : stringPart, elementNum);
        images.setElementAt(imagePart, elementNum);
    }

    public boolean isSelected(int elementNum) {
        return selected.elementAt(elementNum);
    }

    public int getSelectedIndex() {
        for (int i = 0; i < selected.size(); i++) {
            if (selected.elementAt(i)) {
                return i;
            }
        }
        return -1;
    }

    public int getSelectedFlags(boolean[] selectedArray_return) {
        int count = 0;
        for (int i = 0; i < selectedArray_return.length; i++) {
            boolean sel = i < selected.size() && selected.elementAt(i);
            selectedArray_return[i] = sel;
            if (sel) {
                count++;
            }
        }
        return count;
    }

    public void setSelectedIndex(int elementNum, boolean isSelected) {
        if (choiceType == EXCLUSIVE || choiceType == IMPLICIT || choiceType == POPUP) {
            for (int i = 0; i < selected.size(); i++) {
                selected.setElementAt(Boolean.FALSE, i);
            }
            selected.setElementAt(Boolean.TRUE, elementNum);
        } else {
            selected.setElementAt(isSelected, elementNum);
        }
    }

    public void setSelectedFlags(boolean[] selectedArray) {
        for (int i = 0; i < selected.size() && i < selectedArray.length; i++) {
            selected.setElementAt(selectedArray[i], i);
        }
    }
}
