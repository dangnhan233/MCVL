package javax.microedition.lcdui;

/** J2ME (MIDP) {@code CommandListener}. */
public interface CommandListener {
    void commandAction(Command c, Displayable d);
}
