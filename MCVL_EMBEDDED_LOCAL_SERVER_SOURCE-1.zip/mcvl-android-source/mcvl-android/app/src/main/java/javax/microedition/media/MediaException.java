package javax.microedition.media;

/** J2ME (MMAPI) {@code MediaException}. */
public class MediaException extends Exception {

    public MediaException() {
        super();
    }

    public MediaException(String reason) {
        super(reason);
    }
}
