package javax.microedition.lcdui;

/** J2ME (MIDP) {@code StringItem}. */
public class StringItem extends Item {

    private String text;
    private Font font;

    public StringItem(String label, String text) {
        this(label, text, null);
    }

    public StringItem(String label, String text, int appearanceMode) {
        this(label, text, null);
    }

    public StringItem(String label, String text, Font font) {
        setLabel(label);
        this.text = text == null ? "" : text;
        this.font = font;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text == null ? "" : text;
    }

    public Font getFont() {
        return font;
    }

    public void setFont(Font font) {
        this.font = font;
    }
}
