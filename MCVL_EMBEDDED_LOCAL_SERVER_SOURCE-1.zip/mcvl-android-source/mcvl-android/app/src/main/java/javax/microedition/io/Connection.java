package javax.microedition.io;

import java.io.Closeable;
import java.io.IOException;

/** J2ME (CLDC) {@code Connection}. */
public interface Connection extends Closeable {
    @Override
    void close() throws IOException;
}
