package javax.microedition.lcdui;

/** J2ME (MIDP) {@code ImageItem}. */
public class ImageItem extends Item {

    public static final int LAYOUT_DEFAULT = 0;
    public static final int LAYOUT_LEFT = 1;
    public static final int LAYOUT_RIGHT = 2;
    public static final int LAYOUT_CENTER = 3;
    public static final int LAYOUT_NEWLINE_BEFORE = 0x100;
    public static final int LAYOUT_NEWLINE_AFTER = 0x200;

    private Image image;
    private String altText;

    public ImageItem(String label, Image image, int layout, String altText) {
        setLabel(label);
        this.image = image;
        this.layout = layout;
        this.altText = altText;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public String getAltText() {
        return altText;
    }

    public void setAltText(String altText) {
        this.altText = altText;
    }
}
