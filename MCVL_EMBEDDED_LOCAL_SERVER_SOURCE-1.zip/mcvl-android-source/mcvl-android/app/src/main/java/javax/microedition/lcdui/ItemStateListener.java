package javax.microedition.lcdui;

/** J2ME (MIDP) {@code ItemStateListener}. */
public interface ItemStateListener {
    void itemStateChanged(Item item);
}
