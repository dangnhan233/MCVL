package javax.microedition.lcdui.game;

import javax.microedition.lcdui.Canvas;

/**
 * J2ME (MIDP) {@code javax.microedition.lcdui.game.GameCanvas}.
 *
 * <p>The original MIDlet's main class extends this class and drives its own
 * render thread. Rendering is delegated to the Android host view through
 * {@link javax.microedition.lcdui.Canvas#repaint()}; {@link #flushGraphics()}
 * therefore simply requests a redraw of the off-screen buffer.</p>
 */
public class GameCanvas extends Canvas {

    public static final int UP_PRESSED = 0x0002;
    public static final int DOWN_PRESSED = 0x0040;
    public static final int LEFT_PRESSED = 0x0004;
    public static final int RIGHT_PRESSED = 0x0020;
    public static final int FIRE_PRESSED = 0x0100;
    public static final int GAME_A_PRESSED = 0x0200;
    public static final int GAME_B_PRESSED = 0x0400;
    public static final int GAME_C_PRESSED = 0x0800;
    public static final int GAME_D_PRESSED = 0x1000;

    private final boolean suppressKeyEvents;

    public GameCanvas(boolean suppressKeyEvents) {
        super();
        this.suppressKeyEvents = suppressKeyEvents;
    }

    /**
     * Polling API. The ported game reads input through the
     * {@code keyPressed}/{@code keyReleased} callbacks, so no polling state is
     * maintained here.
     */
    public int getKeyStates() {
        return 0;
    }

    public void flushGraphics() {
        repaint();
    }

    public void flushGraphics(int x, int y, int width, int height) {
        repaint();
    }

    public boolean isSuppressKeyEvents() {
        return suppressKeyEvents;
    }
}
