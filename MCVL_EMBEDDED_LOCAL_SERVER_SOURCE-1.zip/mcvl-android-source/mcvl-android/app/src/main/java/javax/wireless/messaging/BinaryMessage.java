package javax.wireless.messaging;

/** J2ME (WMA) {@code BinaryMessage}. */
public interface BinaryMessage extends Message {
    byte[] getPayloadData();

    void setPayloadData(byte[] data);
}
