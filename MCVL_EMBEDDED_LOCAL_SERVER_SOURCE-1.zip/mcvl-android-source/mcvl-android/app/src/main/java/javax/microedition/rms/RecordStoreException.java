package javax.microedition.rms;

/** J2ME (RMS) {@code RecordStoreException}. */
public class RecordStoreException extends Exception {
    public RecordStoreException() {
        super();
    }

    public RecordStoreException(String message) {
        super(message);
    }
}
