package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

/**
 * J2ME (MIDP) {@code Graphics} re-implemented on top of Android's
 * {@link android.graphics.Canvas}. All coordinates are expressed in the
 * game's logical pixel space (240 wide) and are scaled by the host view.
 */
public class Graphics {

    // ---- anchor constants ----------------------------------------------------
    public static final int HCENTER = 1;
    public static final int VCENTER = 2;
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int TOP = 16;
    public static final int BOTTOM = 32;
    public static final int BASELINE = 64;

    // ---- stroke styles -------------------------------------------------------
    public static final int SOLID = 0;
    public static final int DOTTED = 1;

    private final android.graphics.Canvas canvas;
    private final Paint paint = new Paint();
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int width;
    private final int height;

    private Font font = Font.getDefaultFont();
    private int color = 0;          // 0x00RRGGBB
    private int grayScale = 0;
    private int strokeStyle = SOLID;
    private int translateX = 0;
    private int translateY = 0;
    private int clipX = 0;
    private int clipY = 0;
    private int clipW;
    private int clipH;

    private final Image target;

    public Graphics(android.graphics.Canvas canvas, int width, int height, Image target) {
        this.canvas = canvas;
        this.width = width;
        this.height = height;
        this.target = target;
        this.clipW = width;
        this.clipH = height;
        paint.setAntiAlias(false);
        paint.setStrokeWidth(1f);
        paint.setStyle(Paint.Style.STROKE);
        fillPaint.setStyle(Paint.Style.FILL);
        setColor(0);
    }

    // ------------------------------------------------------------------- colour

    public void setColor(int rgb) {
        this.color = rgb & 0x00FFFFFF;
        int argb = 0xFF000000 | color;
        paint.setColor(argb);
        fillPaint.setColor(argb);
        this.grayScale = (int) (0.299 * ((rgb >> 16) & 0xFF)
                + 0.587 * ((rgb >> 8) & 0xFF)
                + 0.114 * (rgb & 0xFF));
    }

    public void setColor(int red, int green, int blue) {
        setColor(((red & 0xFF) << 16) | ((green & 0xFF) << 8) | (blue & 0xFF));
    }

    public int getColor() {
        return color;
    }

    public int getRedComponent() {
        return (color >> 16) & 0xFF;
    }

    public int getGreenComponent() {
        return (color >> 8) & 0xFF;
    }

    public int getBlueComponent() {
        return color & 0xFF;
    }

    public void setGrayScale(int value) {
        this.grayScale = value & 0xFF;
        setColor((grayScale << 16) | (grayScale << 8) | grayScale);
    }

    public int getGrayScale() {
        return grayScale;
    }

    // --------------------------------------------------------------------- font

    public void setFont(Font font) {
        if (font != null) {
            this.font = font;
        }
    }

    public Font getFont() {
        return font;
    }

    // --------------------------------------------------------------- transforms

    public void translate(int x, int y) {
        canvas.translate(x, y);
        translateX += x;
        translateY += y;
    }

    public int getTranslateX() {
        return translateX;
    }

    public int getTranslateY() {
        return translateY;
    }

    public void setClip(int x, int y, int w, int h) {
        // MIDP replaces the clip; Android intersects. Reset the canvas matrix
        // first (restore to the state saved when this Graphics was created) and
        // re-apply the accumulated translation.
        canvas.restore();
        canvas.save();
        canvas.translate(translateX, translateY);
        canvas.clipRect(x, y, x + w, y + h);
        clipX = x;
        clipY = y;
        clipW = w;
        clipH = h;
    }

    public void clipRect(int x, int y, int w, int h) {
        canvas.clipRect(x, y, x + w, y + h);
        int nx = Math.max(clipX, x);
        int ny = Math.max(clipY, y);
        int nx2 = Math.min(clipX + clipW, x + w);
        int ny2 = Math.min(clipY + clipH, y + h);
        clipX = nx;
        clipY = ny;
        clipW = Math.max(0, nx2 - nx);
        clipH = Math.max(0, ny2 - ny);
    }

    public int getClipX() {
        return clipX - translateX;
    }

    public int getClipY() {
        return clipY - translateY;
    }

    public int getClipWidth() {
        return clipW;
    }

    public int getClipHeight() {
        return clipH;
    }

    // ------------------------------------------------------------------ drawing

    public void drawLine(int x1, int y1, int x2, int y2) {
        applyStroke();
        canvas.drawLine(x1, y1, x2, y2, paint);
    }

    public void drawRect(int x, int y, int w, int h) {
        applyStroke();
        canvas.drawRect(x, y, x + w, y + h, paint);
    }

    public void fillRect(int x, int y, int w, int h) {
        canvas.drawRect(x, y, x + w, y + h, fillPaint);
    }

    public void drawRoundRect(int x, int y, int w, int h, int arcW, int arcH) {
        applyStroke();
        canvas.drawRoundRect(new RectF(x, y, x + w, y + h), arcW / 2f, arcH / 2f, paint);
    }

    public void fillRoundRect(int x, int y, int w, int h, int arcW, int arcH) {
        canvas.drawRoundRect(new RectF(x, y, x + w, y + h), arcW / 2f, arcH / 2f, fillPaint);
    }

    public void drawArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        applyStroke();
        canvas.drawArc(new RectF(x, y, x + w, y + h), startAngle, arcAngle, false, paint);
    }

    public void fillArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        canvas.drawArc(new RectF(x, y, x + w, y + h), startAngle, arcAngle, true, fillPaint);
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        p.lineTo(x3, y3);
        p.close();
        canvas.drawPath(p, fillPaint);
    }

    public void drawImage(Image img, int x, int y, int anchor) {
        if (img == null) {
            return;
        }
        drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), Image.TRANS_NONE, x, y, anchor);
    }

    public void drawRegion(Image src, int xSrc, int ySrc, int w, int h,
                           int transform, int xDest, int yDest, int anchor) {
        if (src == null) {
            return;
        }
        Bitmap bmp = src.bitmap;

        boolean swap = transform == Image.TRANS_ROT90 || transform == Image.TRANS_ROT270
                || transform == Image.TRANS_MIRROR_ROT90 || transform == Image.TRANS_MIRROR_ROT270;
        int dw = swap ? h : w;
        int dh = swap ? w : h;

        int left = xDest;
        int top = yDest;
        if ((anchor & HCENTER) != 0) {
            left = xDest - dw / 2;
        } else if ((anchor & RIGHT) != 0) {
            left = xDest - dw;
        }
        if ((anchor & VCENTER) != 0) {
            top = yDest - dh / 2;
        } else if ((anchor & BOTTOM) != 0) {
            top = yDest - dh;
        }

        if (transform == Image.TRANS_NONE) {
            Rect srcRect = new Rect(xSrc, ySrc, xSrc + w, ySrc + h);
            Rect dstRect = new Rect(left, top, left + w, top + h);
            canvas.drawBitmap(bmp, srcRect, dstRect, paint);
            return;
        }

        Matrix m = new Matrix();
        m.postTranslate(-xSrc, -ySrc);
        switch (transform) {
            case Image.TRANS_ROT90:
                m.postRotate(90);
                break;
            case Image.TRANS_ROT180:
                m.postRotate(180);
                break;
            case Image.TRANS_ROT270:
                m.postRotate(270);
                break;
            case Image.TRANS_MIRROR:
                m.postScale(-1, 1);
                break;
            case Image.TRANS_MIRROR_ROT90:
                m.postScale(-1, 1);
                m.postRotate(90);
                break;
            case Image.TRANS_MIRROR_ROT180:
                m.postScale(-1, 1);
                m.postRotate(180);
                break;
            case Image.TRANS_MIRROR_ROT270:
                m.postScale(-1, 1);
                m.postRotate(270);
                break;
            default:
                break;
        }
        float[] pts = {0, 0, w, 0, 0, h, w, h};
        m.mapPoints(pts);
        float minX = Math.min(Math.min(pts[0], pts[2]), Math.min(pts[4], pts[6]));
        float minY = Math.min(Math.min(pts[1], pts[3]), Math.min(pts[5], pts[7]));
        m.postTranslate(left - minX, top - minY);
        canvas.drawBitmap(bmp, m, paint);
    }

    public void drawRGB(int[] rgbData, int offset, int scanlength, int x, int y,
                        int width, int height, boolean processAlpha) {
        Bitmap bmp = Bitmap.createBitmap(rgbData, offset, scanlength, width, height,
                Bitmap.Config.ARGB_8888);
        canvas.drawBitmap(bmp, x, y, paint);
        bmp.recycle();
    }

    public void copyArea(int xSrc, int ySrc, int w, int h, int xDest, int yDest, int anchor) {
        // Not exercised by the game; kept for API completeness.
    }

    // --------------------------------------------------------------------- text

    public void drawString(String str, int x, int y, int anchor) {
        drawSubstring(str, 0, str.length(), x, y, anchor);
    }

    public void drawSubstring(String str, int offset, int len, int x, int y, int anchor) {
        if (str == null) {
            return;
        }
        Paint.FontMetricsInt fm = font.paint.getFontMetricsInt();
        String sub = str.substring(offset, offset + len);
        int w = font.stringWidth(sub);

        int drawX = x;
        if ((anchor & HCENTER) != 0) {
            drawX = x - w / 2;
        } else if ((anchor & RIGHT) != 0) {
            drawX = x - w;
        }

        int baseline = y;
        if ((anchor & BASELINE) != 0) {
            baseline = y;
        } else if ((anchor & TOP) != 0) {
            baseline = y - fm.ascent;
        } else if ((anchor & BOTTOM) != 0) {
            baseline = y - fm.descent;
        } else if ((anchor & VCENTER) != 0) {
            baseline = y - (fm.ascent + fm.descent) / 2;
        }

        canvas.drawText(sub, drawX, baseline, font.paint);
    }

    public void drawChar(char character, int x, int y, int anchor) {
        drawString(String.valueOf(character), x, y, anchor);
    }

    public void drawChars(char[] data, int offset, int length, int x, int y, int anchor) {
        drawString(new String(data, offset, length), x, y, anchor);
    }

    // -------------------------------------------------------------------- misc

    public void setStrokeStyle(int style) {
        this.strokeStyle = style;
    }

    public int getStrokeStyle() {
        return strokeStyle;
    }

    private void applyStroke() {
        if (strokeStyle == DOTTED) {
            paint.setPathEffect(new DashPathEffect(new float[]{2f, 2f}, 0));
        } else {
            paint.setPathEffect(null);
        }
    }

    public int getDisplayColor(int color) {
        return color;
    }

    /** Exposes the backing canvas for the host view / image compositing. */
    public android.graphics.Canvas getAndroidCanvas() {
        return canvas;
    }

    public Image getTargetImage() {
        return target;
    }
}
