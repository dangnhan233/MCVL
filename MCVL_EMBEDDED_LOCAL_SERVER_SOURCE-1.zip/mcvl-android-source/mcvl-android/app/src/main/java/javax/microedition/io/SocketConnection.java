package javax.microedition.io;

import java.io.IOException;

/** J2ME (CLDC) {@code SocketConnection}. */
public interface SocketConnection extends StreamConnection {
    byte DELAY = 0;
    byte LINGER = 1;
    byte KEEPALIVE = 2;
    byte RCVBUF = 3;
    byte SNDBUF = 4;

    void setSocketOption(byte option, int value) throws IOException;

    int getSocketOption(byte option) throws IOException;

    String getLocalAddress() throws IOException;

    int getLocalPort() throws IOException;

    String getAddress() throws IOException;

    int getPort() throws IOException;
}
