package javax.microedition.lcdui;

/** J2ME (MIDP) {@code Ticker}. */
public class Ticker {

    private String string;

    public Ticker(String str) {
        this.string = str == null ? "" : str;
    }

    public String getString() {
        return string;
    }

    public void setString(String str) {
        this.string = str == null ? "" : str;
    }
}
