package javax.microedition.rms;

/** J2ME (RMS) {@code RecordStoreNotFoundException}. */
public class RecordStoreNotFoundException extends RecordStoreException {
    public RecordStoreNotFoundException() {
        super();
    }

    public RecordStoreNotFoundException(String message) {
        super(message);
    }
}
