package javax.wireless.messaging;

/** J2ME (WMA) {@code MessageListener}. */
public interface MessageListener {
    void notifyIncomingMessage(MessageConnection conn);
}
