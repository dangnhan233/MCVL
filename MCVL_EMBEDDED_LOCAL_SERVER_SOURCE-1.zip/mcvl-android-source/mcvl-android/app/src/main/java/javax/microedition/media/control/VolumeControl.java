package javax.microedition.media.control;

import javax.microedition.media.Control;

/** J2ME (MMAPI) {@code VolumeControl}. */
public interface VolumeControl extends Control {
    void setMute(boolean mute);

    boolean isMuted();

    int setLevel(int level);

    int getLevel();
}
