package javax.microedition.lcdui;

import java.util.Vector;

/** J2ME (MIDP) {@code Displayable} — base class for anything shown on screen. */
public abstract class Displayable {

    String title = "";
    Ticker ticker;
    CommandListener commandListener;
    final Vector<Command> commands = new Vector<Command>();
    boolean shown;

    Displayable() {
    }

    public int getWidth() {
        return Display.getScreenWidth();
    }

    public int getHeight() {
        return Display.getScreenHeight();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? "" : title;
    }

    public Ticker getTicker() {
        return ticker;
    }

    public void setTicker(Ticker ticker) {
        this.ticker = ticker;
    }

    public void addCommand(Command cmd) {
        if (cmd != null && !commands.contains(cmd)) {
            commands.addElement(cmd);
        }
    }

    public void removeCommand(Command cmd) {
        commands.removeElement(cmd);
    }

    public void setCommandListener(CommandListener l) {
        this.commandListener = l;
    }

    public boolean isShown() {
        return shown;
    }

    /** Invoked by {@link Display} when this displayable becomes current. */
    void notifyShown() {
        shown = true;
    }

    /** Invoked by {@link Display} when this displayable stops being current. */
    void notifyHidden() {
        shown = false;
    }
}
