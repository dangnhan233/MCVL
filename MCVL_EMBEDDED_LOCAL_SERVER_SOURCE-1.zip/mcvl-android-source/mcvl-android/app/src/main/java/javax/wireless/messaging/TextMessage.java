package javax.wireless.messaging;

/** J2ME (WMA) {@code TextMessage}. */
public interface TextMessage extends Message {
    String getPayloadText();

    void setPayloadText(String data);
}
