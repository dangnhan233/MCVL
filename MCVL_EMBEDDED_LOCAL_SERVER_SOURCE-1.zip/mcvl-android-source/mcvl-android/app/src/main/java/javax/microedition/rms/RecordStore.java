package javax.microedition.rms;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;

/**
 * J2ME (RMS) {@code RecordStore} persisted as a simple file per store inside the
 * app's private storage. This keeps the original save-game semantics (record IDs
 * starting at 1, byte[] records) intact on Android.
 */
public class RecordStore {

    private static File baseDir;

    private final String name;
    private final File file;
    private final Vector<Integer> ids = new Vector<Integer>();
    private final Vector<byte[]> records = new Vector<byte[]>();
    private int nextRecordId = 1;
    private long lastModified = System.currentTimeMillis();
    private int version = 1;
    private boolean open = true;

    private RecordStore(String name, File file) {
        this.name = name;
        this.file = file;
    }

    public static void setBaseDir(File dir) {
        baseDir = dir;
    }

    public static RecordStore openRecordStore(String recordStoreName, boolean createIfNecessary)
            throws RecordStoreException {
        return openRecordStore(recordStoreName, createIfNecessary, 0, true);
    }

    public static RecordStore openRecordStore(String recordStoreName, boolean createIfNecessary,
                                              int authmode, boolean writable)
            throws RecordStoreException {
        if (baseDir == null) {
            throw new RecordStoreException("RecordStore base directory not configured");
        }
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }
        File f = new File(baseDir, sanitize(recordStoreName) + ".rms");
        if (!f.exists()) {
            if (!createIfNecessary) {
                throw new RecordStoreNotFoundException(recordStoreName);
            }
            try {
                f.createNewFile();
            } catch (Exception e) {
                throw new RecordStoreException(e.getMessage());
            }
        }
        RecordStore rs = new RecordStore(recordStoreName, f);
        rs.load();
        return rs;
    }

    public static void deleteRecordStore(String recordStoreName) throws RecordStoreException {
        if (baseDir == null) {
            return;
        }
        File f = new File(baseDir, sanitize(recordStoreName) + ".rms");
        if (f.exists() && !f.delete()) {
            throw new RecordStoreException("Unable to delete " + recordStoreName);
        }
    }

    public static String[] listRecordStores() {
        if (baseDir == null || !baseDir.exists()) {
            return null;
        }
        File[] files = baseDir.listFiles((dir, n) -> n.endsWith(".rms"));
        if (files == null || files.length == 0) {
            return null;
        }
        String[] names = new String[files.length];
        for (int i = 0; i < files.length; i++) {
            String n = files[i].getName();
            names[i] = n.substring(0, n.length() - 4);
        }
        return names;
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^A-Za-z0-9_.-]", "_");
    }

    private void load() {
        ids.clear();
        records.clear();
        nextRecordId = 1;
        if (file.length() == 0) {
            return;
        }
        try (DataInputStream in = new DataInputStream(new FileInputStream(file))) {
            version = in.readInt();
            lastModified = in.readLong();
            nextRecordId = in.readInt();
            int count = in.readInt();
            for (int i = 0; i < count; i++) {
                int id = in.readInt();
                int len = in.readInt();
                byte[] data = new byte[len];
                in.readFully(data);
                ids.addElement(id);
                records.addElement(data);
            }
        } catch (Exception e) {
            ids.clear();
            records.clear();
            nextRecordId = 1;
        }
    }

    private void persist() throws RecordStoreException {
        try (DataOutputStream out = new DataOutputStream(new FileOutputStream(file))) {
            out.writeInt(version);
            out.writeLong(lastModified);
            out.writeInt(nextRecordId);
            out.writeInt(records.size());
            for (int i = 0; i < records.size(); i++) {
                out.writeInt(ids.elementAt(i));
                byte[] data = records.elementAt(i);
                out.writeInt(data.length);
                out.write(data);
            }
        } catch (Exception e) {
            throw new RecordStoreException(e.getMessage());
        }
    }

    private int indexOf(int recordId) {
        return ids.indexOf(recordId);
    }

    public void closeRecordStore() throws RecordStoreException {
        if (open) {
            persist();
            open = false;
        }
    }

    public String getName() throws RecordStoreNotOpenException {
        return name;
    }

    public int getVersion() throws RecordStoreNotOpenException {
        return version;
    }

    public long getLastModified() throws RecordStoreNotOpenException {
        return lastModified;
    }

    public int getNumRecords() throws RecordStoreNotOpenException {
        return records.size();
    }

    public int getSize() throws RecordStoreNotOpenException {
        int total = 0;
        for (byte[] r : records) {
            total += r.length;
        }
        return total;
    }

    public int getSizeAvailable() throws RecordStoreNotOpenException {
        return 1024 * 1024;
    }

    public int addRecord(byte[] data, int offset, int numBytes) throws RecordStoreException {
        int id = nextRecordId++;
        byte[] copy = new byte[numBytes];
        if (data != null && numBytes > 0) {
            System.arraycopy(data, offset, copy, 0, numBytes);
        }
        ids.addElement(id);
        records.addElement(copy);
        lastModified = System.currentTimeMillis();
        version++;
        persist();
        return id;
    }

    public void deleteRecord(int recordId) throws RecordStoreException {
        int idx = indexOf(recordId);
        if (idx < 0) {
            throw new InvalidRecordIDException(String.valueOf(recordId));
        }
        ids.removeElementAt(idx);
        records.removeElementAt(idx);
        lastModified = System.currentTimeMillis();
        version++;
        persist();
    }

    public byte[] getRecord(int recordId) throws RecordStoreException {
        int idx = indexOf(recordId);
        if (idx < 0) {
            throw new InvalidRecordIDException(String.valueOf(recordId));
        }
        return records.elementAt(idx).clone();
    }

    public int getRecord(int recordId, byte[] buffer, int offset) throws RecordStoreException {
        byte[] data = getRecord(recordId);
        System.arraycopy(data, 0, buffer, offset, data.length);
        return data.length;
    }

    public int getRecordSize(int recordId) throws RecordStoreException {
        int idx = indexOf(recordId);
        if (idx < 0) {
            throw new InvalidRecordIDException(String.valueOf(recordId));
        }
        return records.elementAt(idx).length;
    }

    public void setRecord(int recordId, byte[] newData, int offset, int numBytes)
            throws RecordStoreException {
        int idx = indexOf(recordId);
        if (idx < 0) {
            throw new InvalidRecordIDException(String.valueOf(recordId));
        }
        byte[] copy = new byte[numBytes];
        if (newData != null && numBytes > 0) {
            System.arraycopy(newData, offset, copy, 0, numBytes);
        }
        records.setElementAt(copy, idx);
        lastModified = System.currentTimeMillis();
        version++;
        persist();
    }

    public int getNextRecordID() throws RecordStoreNotOpenException {
        return nextRecordId;
    }

    public int[] getRecordIDs() throws RecordStoreNotOpenException {
        int[] result = new int[ids.size()];
        for (int i = 0; i < ids.size(); i++) {
            result[i] = ids.elementAt(i);
        }
        return result;
    }

    public void addRecordListener(RecordListener listener) {
    }

    public void removeRecordListener(RecordListener listener) {
    }
}
