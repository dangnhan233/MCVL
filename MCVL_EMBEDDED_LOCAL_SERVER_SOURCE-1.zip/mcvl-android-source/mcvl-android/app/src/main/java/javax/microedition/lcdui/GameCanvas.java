package javax.microedition.lcdui;

/**
 * J2ME (MIDP) {@code GameCanvas}. The original game extends this class and
 * drives its own render thread through {@link #repaint()}. The off-screen buffer
 * is provided by the Android host view, so {@link #flushGraphics()} simply
 * requests a redraw.
 */
public class GameCanvas extends Canvas {

    public static final int UP_PRESSED = 0x0002;
    public static final int DOWN_PRESSED = 0x0040;
    public static final int LEFT_PRESSED = 0x0004;
    public static final int RIGHT_PRESSED = 0x0020;
    public static final int FIRE_PRESSED = 0x0100;
    public static final int GAME_A_PRESSED = 0x0200;
    public static final int GAME_B_PRESSED = 0x0400;
    public static final int GAME_C_PRESSED = 0x0800;
    public static final int GAME_D_PRESSED = 0x1000;

    private final boolean suppressKeyEvents;

    public GameCanvas(boolean suppressKeyEvents) {
        super();
        this.suppressKeyEvents = suppressKeyEvents;
    }

    public int getKeyStates() {
        // The ported game reads input through the keyPressed/keyReleased
        // callbacks, so no polling state is required.
        return 0;
    }

    public void flushGraphics() {
        repaint();
    }

    public void flushGraphics(int x, int y, int width, int height) {
        repaint();
    }

    public boolean isSuppressKeyEvents() {
        return suppressKeyEvents;
    }
}
