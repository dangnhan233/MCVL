package javax.microedition.rms;

/** J2ME (RMS) {@code InvalidRecordIDException}. */
public class InvalidRecordIDException extends RecordStoreException {
    public InvalidRecordIDException() {
        super();
    }

    public InvalidRecordIDException(String message) {
        super(message);
    }
}
