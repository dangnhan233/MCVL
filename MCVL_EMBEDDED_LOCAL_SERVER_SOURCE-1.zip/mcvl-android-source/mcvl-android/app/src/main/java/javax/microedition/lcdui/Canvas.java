package javax.microedition.lcdui;

/**
 * J2ME (MIDP) {@code Canvas}. Rendering is driven by the host view which calls
 * {@link #paint(Graphics)} and forwards input through the protected callbacks.
 */
public class Canvas extends Displayable {

    // ---- key codes -----------------------------------------------------------
    public static final int KEY_NUM0 = 48;
    public static final int KEY_NUM1 = 49;
    public static final int KEY_NUM2 = 50;
    public static final int KEY_NUM3 = 51;
    public static final int KEY_NUM4 = 52;
    public static final int KEY_NUM5 = 53;
    public static final int KEY_NUM6 = 54;
    public static final int KEY_NUM7 = 55;
    public static final int KEY_NUM8 = 56;
    public static final int KEY_NUM9 = 57;
    public static final int KEY_STAR = 42;
    public static final int KEY_POUND = 35;

    // ---- game actions --------------------------------------------------------
    public static final int UP = 1;
    public static final int DOWN = 6;
    public static final int LEFT = 2;
    public static final int RIGHT = 5;
    public static final int FIRE = 8;
    public static final int GAME_A = 9;
    public static final int GAME_B = 10;
    public static final int GAME_C = 11;
    public static final int GAME_D = 12;

    private boolean fullScreen;
    private boolean doubleBuffered = true;

    public Canvas() {
        super();
    }

    public boolean isDoubleBuffered() {
        return doubleBuffered;
    }

    public boolean hasPointerEvents() {
        return true;
    }

    public boolean hasPointerMotionEvents() {
        return true;
    }

    public boolean hasRepeatEvents() {
        return false;
    }

    public void setFullScreenMode(boolean mode) {
        this.fullScreen = mode;
    }

    public boolean isFullScreenMode() {
        return fullScreen;
    }

    public int getGameAction(int keyCode) {
        switch (keyCode) {
            case -1:
                return UP;
            case -2:
                return DOWN;
            case -3:
                return LEFT;
            case -4:
                return RIGHT;
            case -5:
                return FIRE;
            case -6:
                return GAME_A;
            case -7:
                return GAME_B;
            case -8:
                return GAME_C;
            case -9:
                return GAME_D;
            default:
                return 0;
        }
    }

    public int getKeyCode(int gameAction) {
        switch (gameAction) {
            case UP:
                return -1;
            case DOWN:
                return -2;
            case LEFT:
                return -3;
            case RIGHT:
                return -4;
            case FIRE:
                return -5;
            case GAME_A:
                return -6;
            case GAME_B:
                return -7;
            case GAME_C:
                return -8;
            case GAME_D:
                return -9;
            default:
                return 0;
        }
    }

    public String getKeyName(int keyCode) {
        return String.valueOf(keyCode);
    }

    public void repaint() {
        Display.requestRepaint();
    }

    public void repaint(int x, int y, int width, int height) {
        Display.requestRepaint();
    }

    public void serviceRepaints() {
        Display.serviceRepaints();
    }

    public void callSerially(Runnable r) {
        if (r != null) {
            r.run();
        }
    }

    // ---- callbacks (overridden by the game) ---------------------------------

    protected void paint(Graphics g) {
    }

    protected void keyPressed(int keyCode) {
    }

    protected void keyReleased(int keyCode) {
    }

    protected void keyRepeated(int keyCode) {
    }

    protected void pointerPressed(int x, int y) {
    }

    protected void pointerReleased(int x, int y) {
    }

    protected void pointerDragged(int x, int y) {
    }

    protected void showNotify() {
    }

    protected void hideNotify() {
    }

    protected void sizeChanged(int w, int h) {
    }

    // ---- bridges used by the host view --------------------------------------

    public final void __paint(Graphics g) {
        paint(g);
    }

    public final void __keyPressed(int keyCode) {
        keyPressed(keyCode);
    }

    public final void __keyReleased(int keyCode) {
        keyReleased(keyCode);
    }

    public final void __keyRepeated(int keyCode) {
        keyRepeated(keyCode);
    }

    public final void __pointerPressed(int x, int y) {
        pointerPressed(x, y);
    }

    public final void __pointerReleased(int x, int y) {
        pointerReleased(x, y);
    }

    public final void __pointerDragged(int x, int y) {
        pointerDragged(x, y);
    }

    public final void __showNotify() {
        showNotify();
    }

    public final void __hideNotify() {
        hideNotify();
    }

    public final void __sizeChanged(int w, int h) {
        sizeChanged(w, h);
    }
}
