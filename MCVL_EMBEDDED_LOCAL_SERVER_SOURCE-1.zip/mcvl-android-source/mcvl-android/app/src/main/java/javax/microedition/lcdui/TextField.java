package javax.microedition.lcdui;

/** J2ME (MIDP) {@code TextField}. */
public class TextField extends Item {

    public static final int ANY = 0;
    public static final int EMAILADDR = 1;
    public static final int NUMERIC = 2;
    public static final int PHONENUMBER = 3;
    public static final int URL = 4;
    public static final int DECIMAL = 5;
    public static final int PASSWORD = 0x10000;
    public static final int UNEDITABLE = 0x20000;
    public static final int SENSITIVE = 0x40000;
    public static final int NON_PREDICTIVE = 0x80000;
    public static final int INITIAL_CAPS_WORD = 0x100000;
    public static final int INITIAL_CAPS_SENTENCE = 0x200000;
    public static final int CONSTRAINT_MASK = 0xFFFF;

    private String text;
    private int maxSize;
    private int constraints;
    private int caret;

    public TextField(String label, String text, int maxSize, int constraints) {
        setLabel(label);
        this.text = text == null ? "" : text;
        this.maxSize = maxSize;
        this.constraints = constraints;
        if (this.text.length() > maxSize) {
            this.text = this.text.substring(0, maxSize);
        }
    }

    public String getString() {
        return text;
    }

    public void setString(String text) {
        this.text = text == null ? "" : text;
        if (this.text.length() > maxSize) {
            this.text = this.text.substring(0, maxSize);
        }
    }

    public int getMaxSize() {
        return maxSize;
    }

    public int setMaxSize(int maxSize) {
        this.maxSize = maxSize;
        if (text.length() > maxSize) {
            text = text.substring(0, maxSize);
        }
        return maxSize;
    }

    public int getConstraints() {
        return constraints;
    }

    public void setConstraints(int constraints) {
        this.constraints = constraints;
    }

    public int size() {
        return text.length();
    }

    public int getChars(char[] data) {
        int len = Math.min(data.length, text.length());
        text.getChars(0, len, data, 0);
        return len;
    }

    public void setChars(char[] data, int offset, int length) {
        if (data == null) {
            text = "";
        } else {
            text = new String(data, offset, length);
        }
    }

    public void insert(String src, int position) {
        text = text.substring(0, position) + src + text.substring(position);
    }

    public void insert(char[] data, int offset, int length, int position) {
        insert(new String(data, offset, length), position);
    }

    public void delete(int offset, int length) {
        text = text.substring(0, offset) + text.substring(offset + length);
    }

    public int getCaretPosition() {
        return caret;
    }

    public void setCaretPosition(int position) {
        this.caret = position;
    }
}
