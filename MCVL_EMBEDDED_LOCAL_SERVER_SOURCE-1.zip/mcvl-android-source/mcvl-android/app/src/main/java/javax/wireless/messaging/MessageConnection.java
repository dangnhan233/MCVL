package javax.wireless.messaging;

import java.io.IOException;

import javax.microedition.io.Connection;

/** J2ME (WMA) {@code MessageConnection}. */
public interface MessageConnection extends Connection {
    String TEXT_MESSAGE = "text";
    String BINARY_MESSAGE = "binary";

    Message newMessage(String type);

    Message newMessage(String type, String address);

    int numberOfSegments(Message message);

    Message receive() throws IOException;

    void send(Message message) throws IOException;

    void setMessageListener(MessageListener listener) throws IOException;
}
