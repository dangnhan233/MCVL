package javax.microedition.rms;

/** J2ME (RMS) {@code RecordStoreNotOpenException}. */
public class RecordStoreNotOpenException extends RecordStoreException {
    public RecordStoreNotOpenException() {
        super();
    }

    public RecordStoreNotOpenException(String message) {
        super(message);
    }
}
