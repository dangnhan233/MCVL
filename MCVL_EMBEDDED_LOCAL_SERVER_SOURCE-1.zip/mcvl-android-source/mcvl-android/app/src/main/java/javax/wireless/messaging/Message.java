package javax.wireless.messaging;

/** J2ME (WMA) {@code Message}. */
public interface Message {
    String getAddress();

    void setAddress(String addr);

    java.util.Date getTimestamp();
}
