package javax.microedition.rms;

/** J2ME (RMS) {@code RecordComparator}. */
public interface RecordComparator {
    int EQUIVALENT = 0;
    int PRECEDES = -1;
    int FOLLOWS = 1;

    int compare(byte[] rec1, byte[] rec2);
}
