package javax.microedition.media;

/** J2ME (MMAPI) {@code Controllable}. */
public interface Controllable {
    Control getControl(String controlType);

    Control[] getControls();
}
