package javax.microedition.io;

/** J2ME (CLDC) {@code StreamConnection}. */
public interface StreamConnection extends InputConnection, OutputConnection {
}
