package javax.microedition.lcdui;

/**
 * Implemented by the Android view that hosts the J2ME display. Keeps the
 * compatibility layer free of any direct dependency on the app package.
 */
public interface DisplayHost {

    /** Called when {@link Display#setCurrent(Displayable)} selects a new screen. */
    void onDisplayableChanged(Displayable d);

    /** Called when the game requests a repaint from its render thread. */
    void onRepaintRequested();

    /** Blocks until the pending frame has been drawn. */
    void onServiceRepaints();

    /** Shows a J2ME {@link Alert} as a transient dialog. */
    void onShowAlert(Alert alert, Displayable next);

    int getScreenWidth();

    int getScreenHeight();
}
