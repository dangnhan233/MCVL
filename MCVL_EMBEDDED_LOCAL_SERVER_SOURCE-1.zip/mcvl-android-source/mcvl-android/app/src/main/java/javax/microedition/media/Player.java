package javax.microedition.media;

/** J2ME (MMAPI) {@code Player}. */
public interface Player extends Controllable {

    int UNREALIZED = 100;
    int REALIZED = 200;
    int PREFETCHED = 300;
    int STARTED = 400;
    int CLOSED = 0;
    long TIME_UNKNOWN = -1L;

    void realize() throws MediaException;

    void prefetch() throws MediaException;

    void start() throws MediaException;

    void stop() throws MediaException;

    void deallocate();

    void close();

    void setLoopCount(int count);

    void setMediaTime(long now) throws MediaException;

    long getMediaTime();

    long getDuration();

    String getContentType();

    void addPlayerListener(PlayerListener playerListener);

    void removePlayerListener(PlayerListener playerListener);
}
