package javax.microedition.lcdui;

import java.util.Vector;

/** J2ME (MIDP) {@code Item} — base class for form components. */
public abstract class Item {

    public static final int LAYOUT_DEFAULT = 0;
    public static final int LAYOUT_LEFT = 1;
    public static final int LAYOUT_RIGHT = 2;
    public static final int LAYOUT_CENTER = 3;
    public static final int LAYOUT_TOP = 16;
    public static final int LAYOUT_BOTTOM = 32;
    public static final int LAYOUT_VCENTER = 48;
    public static final int LAYOUT_NEWLINE_BEFORE = 256;
    public static final int LAYOUT_NEWLINE_AFTER = 512;
    public static final int LAYOUT_SHRINK = 1024;
    public static final int LAYOUT_EXPAND = 2048;
    public static final int LAYOUT_VSHRINK = 4096;
    public static final int LAYOUT_VEXPAND = 8192;
    public static final int LAYOUT_2 = 16384;

    String label = "";
    int layout = LAYOUT_DEFAULT;
    Command defaultCommand;
    final Vector<Command> commands = new Vector<Command>();
    ItemStateListener listener;

    Item() {
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label == null ? "" : label;
    }

    public int getLayout() {
        return layout;
    }

    public void setLayout(int layout) {
        this.layout = layout;
    }

    public void addCommand(Command cmd) {
        if (cmd != null && !commands.contains(cmd)) {
            commands.addElement(cmd);
        }
    }

    public void removeCommand(Command cmd) {
        commands.removeElement(cmd);
    }

    public void setDefaultCommand(Command cmd) {
        this.defaultCommand = cmd;
    }

    public void setItemCommandListener(Object l) {
        // MIDP 2.0 hook — unused by the game.
    }

    public int getMinimumWidth() {
        return -1;
    }

    public int getMinimumHeight() {
        return -1;
    }

    public int getPreferredWidth() {
        return -1;
    }

    public int getPreferredHeight() {
        return -1;
    }

    public void notifyStateChanged() {
        if (listener != null) {
            listener.itemStateChanged(this);
        }
    }
}
