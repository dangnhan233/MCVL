package javax.microedition.midlet;

import java.util.Hashtable;

/**
 * J2ME (MIDP) {@code MIDlet}. The Android launcher instantiates the concrete
 * MIDlet declared in the JAR manifest and drives its lifecycle.
 */
public abstract class MIDlet {

    private static Hashtable<String, String> appProperties = new Hashtable<String, String>();
    private static Runnable destroyCallback;
    private static android.content.Context context;

    protected MIDlet() {
    }

    /** Android context used by {@link #platformRequest(String)}. */
    public static void setContext(android.content.Context ctx) {
        context = ctx;
    }

    /** Supplies the JAR manifest attributes to {@link #getAppProperty(String)}. */
    public static void setAppProperties(Hashtable<String, String> props) {
        appProperties = props == null ? new Hashtable<String, String>() : props;
    }

    /** Registers the callback used by {@link #notifyDestroyed()}. */
    public static void setDestroyCallback(Runnable callback) {
        destroyCallback = callback;
    }

    public String getAppProperty(String key) {
        return appProperties.get(key);
    }

    public final void notifyDestroyed() {
        if (destroyCallback != null) {
            destroyCallback.run();
        }
    }

    public final void notifyPaused() {
    }

    public final void resumeRequest() {
    }

    /**
     * Opens the given URL with the platform's default handler (a browser). This
     * mirrors the MIDP behaviour used by the game for "open homepage" actions.
     */
    public final boolean platformRequest(String url) {
        if (context == null || url == null) {
            return false;
        }
        try {
            android.content.Intent intent = new android.content.Intent(
                    android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    protected abstract void startApp();

    protected abstract void pauseApp();

    protected abstract void destroyApp(boolean unconditional);

    // ---- bridges used by the Android launcher -------------------------------

    public final void __startApp() {
        startApp();
    }

    public final void __pauseApp() {
        pauseApp();
    }

    public final void __destroyApp(boolean unconditional) {
        destroyApp(unconditional);
    }
}
