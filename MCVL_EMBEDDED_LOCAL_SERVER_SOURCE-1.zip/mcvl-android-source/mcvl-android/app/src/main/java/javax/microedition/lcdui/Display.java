package javax.microedition.lcdui;

import javax.microedition.midlet.MIDlet;

/** J2ME (MIDP) {@code Display} — the screen manager. */
public class Display {

    private static Display instance;
    private static DisplayHost host;
    private static int screenWidth = 240;
    private static int screenHeight = 320;

    private final MIDlet midlet;
    private Displayable current;

    private Display(MIDlet midlet) {
        this.midlet = midlet;
    }

    public static Display getDisplay(MIDlet midlet) {
        if (instance == null) {
            instance = new Display(midlet);
        }
        return instance;
    }

    // ---- host wiring ---------------------------------------------------------

    public static void setHost(DisplayHost displayHost) {
        host = displayHost;
    }

    public static DisplayHost getHost() {
        return host;
    }

    public static void setScreenSize(int w, int h) {
        if (w > 0 && h > 0) {
            screenWidth = w;
            screenHeight = h;
        }
    }

    public static int getScreenWidth() {
        return screenWidth;
    }

    public static int getScreenHeight() {
        return screenHeight;
    }

    // ---- displayable management ---------------------------------------------

    public void setCurrent(Displayable next) {
        if (current != null) {
            current.notifyHidden();
        }
        current = next;
        if (current != null) {
            current.notifyShown();
        }
        if (host != null) {
            host.onDisplayableChanged(current);
        }
    }

    public void setCurrent(Alert alert, Displayable next) {
        if (host != null) {
            host.onShowAlert(alert, next);
        } else {
            setCurrent(next);
        }
    }

    public Displayable getCurrent() {
        return current;
    }

    public void callSerially(Runnable r) {
        if (r != null) {
            r.run();
        }
    }

    // ---- capabilities --------------------------------------------------------

    public boolean isColor() {
        return true;
    }

    public int numColors() {
        return 16777216;
    }

    public int numAlphaLevels() {
        return 256;
    }

    public int getBestImageWidth(int imageType) {
        return screenWidth;
    }

    public int getBestImageHeight(int imageType) {
        return screenHeight;
    }

    public void flashBacklight(int duration) {
    }

    public boolean vibrate(int duration) {
        return false;
    }

    // ---- render plumbing (used by Canvas) -----------------------------------

    public static void requestRepaint() {
        if (host != null) {
            host.onRepaintRequested();
        }
    }

    public static void serviceRepaints() {
        if (host != null) {
            host.onServiceRepaints();
        }
    }
}
