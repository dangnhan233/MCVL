package javax.microedition.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/** J2ME (CLDC) {@code Datagram}. */
public interface Datagram extends java.io.DataInput, java.io.DataOutput {
    String getAddress();

    byte[] getData();

    int getLength();

    int getOffset();

    void setAddress(String addr) throws IOException;

    void setAddress(Datagram reference);

    void setData(byte[] buffer, int offset, int len);

    void setLength(int len);

    void reset();

    DataInputStream openDataInputStream() throws IOException;

    DataOutputStream openDataOutputStream() throws IOException;
}
