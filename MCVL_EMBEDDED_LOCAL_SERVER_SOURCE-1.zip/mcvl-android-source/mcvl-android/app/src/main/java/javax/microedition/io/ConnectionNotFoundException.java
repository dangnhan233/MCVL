package javax.microedition.io;

import java.io.IOException;

/** J2ME (CLDC) {@code ConnectionNotFoundException}. */
public class ConnectionNotFoundException extends IOException {
    public ConnectionNotFoundException() {
        super();
    }

    public ConnectionNotFoundException(String reason) {
        super(reason);
    }
}
