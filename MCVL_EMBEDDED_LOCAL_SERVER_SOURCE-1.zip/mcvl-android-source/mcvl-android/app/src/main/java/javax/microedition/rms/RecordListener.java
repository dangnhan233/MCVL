package javax.microedition.rms;

/** J2ME (RMS) {@code RecordListener}. */
public interface RecordListener {
    void recordAdded(RecordStore recordStore, int recordId);

    void recordChanged(RecordStore recordStore, int recordId);

    void recordDeleted(RecordStore recordStore, int recordId);
}
