package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * J2ME (MIDP) {@code Image} backed by an Android {@link Bitmap}.
 */
public class Image {

    // ---- MIDP transform constants -------------------------------------------
    public static final int TRANS_NONE = 0;
    public static final int TRANS_ROT90 = 5;
    public static final int TRANS_ROT180 = 3;
    public static final int TRANS_ROT270 = 6;
    public static final int TRANS_MIRROR = 2;
    public static final int TRANS_MIRROR_ROT90 = 7;
    public static final int TRANS_MIRROR_ROT180 = 1;
    public static final int TRANS_MIRROR_ROT270 = 4;

    final Bitmap bitmap;
    private final boolean mutable;

    Image(Bitmap bitmap, boolean mutable) {
        this.bitmap = bitmap;
        this.mutable = mutable;
    }

    // ------------------------------------------------------------------ factory

    public static Image createImage(String name) throws IOException {
        byte[] data = Assets.readImageBytes(name);
        Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
        if (bmp == null) {
            throw new IOException("Unable to decode image: " + name);
        }
        bmp.setDensity(Bitmap.DENSITY_NONE);
        return new Image(bmp, false);
    }

    public static Image createImage(byte[] imageData, int imageOffset, int imageLength) {
        Bitmap bmp = BitmapFactory.decodeByteArray(imageData, imageOffset, imageLength);
        if (bmp == null) {
            return null;
        }
        bmp.setDensity(Bitmap.DENSITY_NONE);
        return new Image(bmp, false);
    }

    public static Image createImage(InputStream stream) throws IOException {
        if (stream == null) {
            return null;
        }
        try {
            byte[] data = readAll(stream);
            data = Assets.normalizePng(data);
            Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
            if (bmp == null) {
                return null;
            }
            bmp.setDensity(Bitmap.DENSITY_NONE);
            return new Image(bmp, false);
        } finally {
            try {
                stream.close();
            } catch (IOException ignored) {
            }
        }
    }

    public static Image createImage(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Image dimensions must be positive");
        }
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmp.setDensity(Bitmap.DENSITY_NONE);
        return new Image(bmp, true);
    }

    public static Image createImage(Image source) {
        if (source == null) {
            return null;
        }
        Bitmap copy = source.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        copy.setDensity(Bitmap.DENSITY_NONE);
        return new Image(copy, true);
    }

    public static Image createImage(Image image, int x, int y, int width, int height, int transform) {
        if (image == null) {
            return null;
        }
        Bitmap src = image.bitmap;
        Bitmap region = Bitmap.createBitmap(src, x, y, width, height);
        Bitmap result = applyTransform(region, transform);
        result.setDensity(Bitmap.DENSITY_NONE);
        return new Image(result, false);
    }

    public static Image createRGBImage(int[] rgb, int width, int height, boolean processAlpha) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmp.setPixels(rgb, 0, width, 0, 0, width, height);
        bmp.setDensity(Bitmap.DENSITY_NONE);
        return new Image(bmp, false);
    }

    // ------------------------------------------------------------------ helpers

    static Bitmap applyTransform(Bitmap src, int transform) {
        int w = src.getWidth();
        int h = src.getHeight();
        Matrix m = new Matrix();
        boolean swap = false;
        switch (transform) {
            case TRANS_NONE:
                return src;
            case TRANS_ROT90:
                m.postRotate(90);
                swap = true;
                break;
            case TRANS_ROT180:
                m.postRotate(180);
                break;
            case TRANS_ROT270:
                m.postRotate(270);
                swap = true;
                break;
            case TRANS_MIRROR:
                m.postScale(-1, 1);
                break;
            case TRANS_MIRROR_ROT90:
                m.postScale(-1, 1);
                m.postRotate(90);
                swap = true;
                break;
            case TRANS_MIRROR_ROT180:
                m.postScale(-1, 1);
                m.postRotate(180);
                break;
            case TRANS_MIRROR_ROT270:
                m.postScale(-1, 1);
                m.postRotate(270);
                swap = true;
                break;
            default:
                return src;
        }
        Bitmap out = Bitmap.createBitmap(swap ? h : w, swap ? w : h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.translate(out.getWidth() / 2f, out.getHeight() / 2f);
        c.drawBitmap(src, m, null);
        // drawBitmap with a matrix positions the bitmap's top-left at the origin of
        // the supplied matrix; the translate above centres the rotation.
        return out;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    // ------------------------------------------------------------------- public

    public int getWidth() {
        return bitmap.getWidth();
    }

    public int getHeight() {
        return bitmap.getHeight();
    }

    public boolean isMutable() {
        return mutable;
    }

    public Graphics getGraphics() {
        if (!mutable) {
            return null;
        }
        return new Graphics(new Canvas(bitmap), bitmap.getWidth(), bitmap.getHeight(), this);
    }

    public void getRGB(int[] rgbData, int offset, int scanlength,
                       int x, int y, int width, int height) {
        bitmap.getPixels(rgbData, offset, scanlength, x, y, width, height);
    }

    /** Internal accessor for {@link Graphics}. */
    public Bitmap getBitmap() {
        return bitmap;
    }

    /** Creates a mutable image from raw PNG bytes (used by the game loader). */
    public static Image fromPngBytes(byte[] png) {
        Bitmap bmp = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (bmp == null) {
            return null;
        }
        bmp.setDensity(Bitmap.DENSITY_NONE);
        return new Image(bmp, false);
    }

    static Image fromStream(ByteArrayInputStream stream) {
        try {
            return createImage(stream);
        } catch (IOException e) {
            return null;
        }
    }
}
