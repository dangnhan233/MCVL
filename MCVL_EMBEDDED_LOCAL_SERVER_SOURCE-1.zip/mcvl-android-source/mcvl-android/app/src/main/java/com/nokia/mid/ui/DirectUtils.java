package com.nokia.mid.ui;

import javax.microedition.lcdui.Graphics;

/**
 * Minimal re-implementation of the Nokia UI API entry point
 * {@code com.nokia.mid.ui.DirectUtils}. The original MIDlet only uses
 * {@link #getDirectGraphics(Graphics)} together with
 * {@link DirectGraphics#setARGBColor(int)}.
 */
public final class DirectUtils {

    private DirectUtils() {
    }

    public static DirectGraphics getDirectGraphics(Graphics g) {
        return new DirectGraphicsImpl(g);
    }
}
