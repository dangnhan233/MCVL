package com.mcvl.android;

import android.app.Application;
import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;

import javax.microedition.lcdui.Assets;
import javax.microedition.media.Manager;
import javax.microedition.midlet.MIDlet;

/**
 * Application entry point. Wires the J2ME compatibility layer to the Android
 * runtime: the asset bridge, the audio manager and the MIDlet app properties
 * (read from the original {@code META-INF/MANIFEST.MF}).
 */
public class McvlApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Assets.init(getAssets());
        Manager.setContext(this);
        MIDlet.setContext(this);
        MIDlet.setAppProperties(loadManifest(getAssets()));
        // Embedded local MCVL server: the game client connects to 127.0.0.1:9001.
        EmbeddedLocalServer.start(this);
    }

    /** Parses a JAR manifest into a key/value table. */
    private static Hashtable<String, String> loadManifest(AssetManager am) {
        Hashtable<String, String> props = new Hashtable<String, String>();
        InputStream in = null;
        try {
            in = am.open("META-INF/MANIFEST.MF");
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            String key = null;
            StringBuilder value = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (line.length() == 0) {
                    continue;
                }
                if (line.charAt(0) == ' ' && key != null) {
                    value.append(line.substring(1));
                    continue;
                }
                if (key != null) {
                    props.put(key, value.toString());
                }
                int colon = line.indexOf(':');
                if (colon > 0) {
                    key = line.substring(0, colon).trim();
                    value = new StringBuilder(line.substring(colon + 1).trim());
                } else {
                    key = null;
                    value = new StringBuilder();
                }
            }
            if (key != null) {
                props.put(key, value.toString());
            }
        } catch (Exception ignored) {
            // Manifest is optional; the game only reads MIDlet-Version.
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception ignored) {
                }
            }
        }
        return props;
    }
}
