package com.mcvl.android;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Embedded local MCVL server. This is the Android/Java port of mcvl_server.py.
 * It listens only on 127.0.0.1:9001 and is started by McvlApplication.
 */
public final class EmbeddedLocalServer {
    public static final String HOST = "127.0.0.1";
    public static final int PORT = 9001;

    private static final int P_ACCOUNT = 1003;
    private static final int P_MOVE = 1005;
    private static final int P_ENTER = 1011;
    private static final int P_CREATE = 1012;
    private static final int P_CHARLIST = 1020;
    private static final int P_DELETE = 1024;
    private static final int P_REGISTER = 1027;
    private static final int P_MAP = 2001;
    private static final int P_STATUS = 2002;
    private static final int P_PING = 3505;
    private static final int P_HELP = 9550;
    private static final int P_VERSION = 9950;

    private static final int MAP_W = 64;
    private static final int MAP_H = 48;
    private static final int SPAWN_TX = 12;
    private static final int SPAWN_TY = 38;
    private static final int TILE = 16;

    private static final SecureRandom RNG = new SecureRandom();
    private static volatile EmbeddedLocalServer instance;

    private final Context context;
    private final File dbFile;
    private final Store store;
    private final Map<String, Session> sessions = new ConcurrentHashMap<String, Session>();
    private final Map<Long, Session> bySid = new ConcurrentHashMap<Long, Session>();
    private final int[] mapTiles = buildMapTiles();
    private volatile boolean running;
    private volatile ServerSocket serverSocket;
    private Thread acceptThread;

    private EmbeddedLocalServer(Context context) {
        this.context = context.getApplicationContext();
        File dir = new File(this.context.getFilesDir(), "mcvl");
        if (!dir.exists()) dir.mkdirs();
        this.dbFile = new File(dir, "accounts.json");
        this.store = new Store(dbFile);
    }

    public static synchronized void start(Context context) {
        if (instance != null && instance.running) return;
        instance = new EmbeddedLocalServer(context);
        instance.startInternal();
    }

    public static synchronized void stop() {
        if (instance == null) return;
        instance.stopInternal();
        instance = null;
    }

    public static boolean isRunning() {
        return instance != null && instance.running;
    }

    private void startInternal() {
        if (running) return;
        try {
            serverSocket = new ServerSocket(PORT, 32, InetAddress.getByName(HOST));
            running = true;
            acceptThread = new Thread(new Runnable() {
                @Override public void run() { acceptLoop(); }
            }, "MCVL-LocalServer");
            acceptThread.setDaemon(true);
            acceptThread.start();
        } catch (IOException e) {
            running = false;
            serverSocket = null;
            e.printStackTrace();
        }
    }

    private void stopInternal() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
        serverSocket = null;
        for (Session s : sessions.values()) closeQuietly(s.socket);
        sessions.clear();
        bySid.clear();
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket socket = serverSocket.accept();
                Thread t = new Thread(new Runnable() {
                    @Override public void run() { clientLoop(socket); }
                }, "MCVL-Client");
                t.setDaemon(true);
                t.start();
            } catch (SocketException e) {
                if (running) e.printStackTrace();
            } catch (IOException e) {
                if (running) e.printStackTrace();
            }
        }
    }

    private void clientLoop(Socket socket) {
        Session active = null;
        try {
            socket.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            while (running && !socket.isClosed()) {
                byte[] frame = readFrame(in);
                if (frame == null) break;
                PacketList response;
                try {
                    response = handleFrame(frame, socket);
                } catch (Throwable t) {
                    t.printStackTrace();
                    response = new PacketList();
                }
                writeResponse(out, response);
                out.flush();
                if (response.session != null) active = response.session;
            }
        } catch (EOFException ignored) {
        } catch (IOException ignored) {
        } finally {
            if (active != null && active.socket == socket) active.socket = null;
            closeQuietly(socket);
        }
    }

    private byte[] readFrame(DataInputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int z;
        try { z = in.readUnsignedByte(); } catch (EOFException e) { return null; }
        b.write(z);
        b.write(in.readUnsignedByte());
        b.write(in.readUnsignedByte());
        b.write(in.readByte());
        int n = in.readUnsignedShort();
        writeU16(b, n);
        if (n == 9999) {
            byte[] x = new byte[8]; in.readFully(x); b.write(x);
        } else {
            byte[] x = new byte[n]; in.readFully(x); b.write(x);
        }
        int blen = in.readUnsignedShort();
        writeU16(b, blen);
        byte[] block = new byte[blen]; in.readFully(block); b.write(block);
        return b.toByteArray();
    }

    private PacketList handleFrame(byte[] frame, Socket socket) throws IOException {
        DataInputStream r = new DataInputStream(new ByteArrayInputStream(frame));
        r.readUnsignedByte();
        r.readUnsignedByte();
        r.readUnsignedByte();
        r.readByte();
        int n = r.readUnsignedShort();
        Session sess;
        if (n == 9999) {
            sess = bySid.get(r.readLong());
        } else {
            byte[] token = new byte[n]; r.readFully(token);
            sess = sessions.get(new String(token, StandardCharsets.UTF_8));
        }
        int blen = r.readUnsignedShort();
        byte[] block = new byte[blen]; r.readFully(block);
        DataInputStream br = new DataInputStream(new ByteArrayInputStream(block));
        int cnt = br.readUnsignedByte();
        PacketList out = new PacketList();
        out.session = sess;
        for (int i = 0; i < cnt; i++) {
            int plen = br.readUnsignedShort();
            byte[] packet = new byte[plen]; br.readFully(packet);
            DataInputStream pk = new DataInputStream(new ByteArrayInputStream(packet));
            int pid = pk.readUnsignedShort();
            PacketResult result = dispatch(pid, pk, sess, socket);
            if (result.session != null) { sess = result.session; out.session = sess; }
            out.packets.addAll(result.packets);
        }
        return out;
    }

    private PacketResult dispatch(int pid, DataInputStream pk, Session sess, Socket local) throws IOException {
        switch (pid) {
            case P_VERSION: return hVersion();
            case P_ACCOUNT: return hAccount(pk, local);
            case P_REGISTER: return hRegister(pk);
            case P_CHARLIST: return hCharList(sess);
            case P_CREATE: return hCreate(pk, sess);
            case P_DELETE: return error(P_DELETE, 1, "Server local chưa hỗ trợ xoá nhân vật.");
            case P_ENTER: return hEnter(pk, sess);
            case P_HELP: return hHelp();
            case P_MOVE: return hMove(pk, sess);
            case P_STATUS:
            case P_PING: return new PacketResult();
            default: return new PacketResult();
        }
    }

    private PacketResult hVersion() throws IOException {
        W w = new W();
        w.utf("11").utf("");
        w.s8(1).utf("Local Server").utf(HOST + ":" + PORT).s8(0).s8(0);
        w.s16(51).s16(68);
        w.s16(0);
        return ok(P_VERSION, w.bytes());
    }

    private PacketResult hAccount(DataInputStream pk, Socket local) throws IOException {
        String acct = readUtf(pk).trim();
        int op = pk.readUnsignedByte();
        pk.readUnsignedByte();
        readUtf(pk);
        pk.readUnsignedByte();
        if (op == 0) {
            String pwd = readUtf(pk).trim();
            readUtf(pk);
            return doLogin(acct, pwd, local);
        }
        if (op == 1) {
            String oldPwd = readUtf(pk);
            String newPwd = readUtf(pk);
            Account a = store.account(acct);
            if (a == null || !a.pwd.equals(oldPwd)) return error(P_ACCOUNT, 2, "Mật khẩu cũ không đúng.");
            a.pwd = newPwd; store.save();
            return ok(P_ACCOUNT, new W().utf("Đổi mật khẩu thành công.").bytes());
        }
        return ok(P_ACCOUNT, new W().utf("Chức năng này chưa hỗ trợ trên server local.").bytes());
    }

    private PacketResult doLogin(String acct, String pwd, Socket socket) throws IOException {
        if (acct.length() == 0) return error(P_ACCOUNT, 2, "Tài khoản không được để trống.");
        Account a = store.account(acct);
        if (a == null) {
            a = new Account(); a.pwd = pwd; a.chars = new CharData[2];
            store.accounts.put(acct, a); store.save();
        } else if (!a.pwd.equals(pwd)) {
            return error(P_ACCOUNT, 2, "Sai mật khẩu.");
        }
        String token = "s_" + Long.toHexString(RNG.nextLong()) + Long.toHexString(RNG.nextLong());
        Session s = new Session(token, acct, socket);
        sessions.put(token, s); bySid.put(s.sid, s);
        return session(P_ACCOUNT, new W().utf(token).s8(0).bytes(), s);
    }


    private PacketResult hRegister(DataInputStream pk) throws IOException {
        int typ = pk.readUnsignedByte();
        if (typ == 0) {
            pk.readUnsignedByte();
            String acct = readUtf(pk).trim();
            String pwd = readUtf(pk).trim();
            if (acct.length() == 0 || pwd.length() == 0) return error(P_REGISTER, 1, "Thiếu tài khoản hoặc mật khẩu.");
            if (store.accounts.containsKey(acct)) return error(P_REGISTER, 1, "Tài khoản đã tồn tại.");
            Account a = new Account(); a.pwd = pwd; a.chars = new CharData[2];
            store.accounts.put(acct, a); store.save();
            return ok(P_REGISTER, new W().s8(0).utf("Đăng ký thành công! Hãy đăng nhập.").bytes());
        }
        return ok(P_REGISTER, new W().s8(2).utf("").bytes());
    }

    private PacketResult hCharList(Session s) throws IOException {
        if (s == null) return error(P_CHARLIST, 1, "Phiên đăng nhập hết hạn, hãy đăng nhập lại.");
        Account a = store.account(s.account);
        W w = new W();
        int n = 0; for (CharData c : a.chars) if (c != null) n++;
        w.s8(n);
        for (CharData c : a.chars) if (c != null) {
            w.utf(c.name).s8(1).s8(c.gender).s8(0).s8(c.cls).s8(0);
            for (int i=0;i<9;i++) w.s16(i==0?c.cls:-1);
            for (int i=0;i<9;i++) w.s8(0);
            for (int i=0;i<9;i++) w.s8(0);
            w.s8(-1).s32(c.c1).s32(c.c2).s8(c.style);
        }
        w.utf("");
        return ok(P_CHARLIST, w.bytes());
    }

    private PacketResult hCreate(DataInputStream pk, Session s) throws IOException {
        if (s == null) return error(P_CREATE, 1, "Phiên đăng nhập hết hạn.");
        String name = readUtf(pk).trim();
        int cls = pk.readByte(), gender = pk.readByte();
        int c1 = pk.readInt(), c2 = pk.readInt();
        int style = pk.readByte();
        if (name.length() < 1 || name.length() > 16) return error(P_CREATE, 1, "Tên nhân vật không hợp lệ.");
        if (store.findChar(name) != null) return error(P_CREATE, 1, "Tên nhân vật đã có người dùng.");
        Account a = store.account(s.account);
        int slot = -1; for (int i=0;i<a.chars.length;i++) if (a.chars[i] == null) { slot=i; break; }
        if (slot < 0) return error(P_CREATE, 1, "Đã đủ số nhân vật.");
        CharData c = new CharData(); c.name=name; c.cls=cls; c.gender=gender; c.c1=c1; c.c2=c2; c.style=style;
        c.pid = store.nextPid++; c.level=1; c.gold=1000; c.exp=0; c.map=0; c.tx=SPAWN_TX; c.ty=SPAWN_TY;
        a.chars[slot]=c; store.save();
        return ok(P_CREATE, new W().s8(0).utf("Tạo nhân vật thành công!").bytes());
    }

    private PacketResult hEnter(DataInputStream pk, Session s) throws IOException {
        pk.readUnsignedByte(); String acct=readUtf(pk); String name=readUtf(pk);
        if (s == null) return error(P_ENTER, 1, "Phiên đăng nhập hết hạn, hãy đăng nhập lại.");
        CharRef ref = store.findChar(name);
        if (ref == null || !ref.account.equals(s.account)) return error(P_ENTER, 1, "Không tìm thấy nhân vật.");
        s.ch = ref.ch; s.inGame=true; s.px=s.ch.tx*TILE; s.py=s.ch.ty*TILE;
        return ok(P_ENTER, buildEnter(s.ch, s));
    }

    private PacketResult hMove(DataInputStream pk, Session s) throws IOException {
        if (pk.available() < 1) return new PacketResult();
        int sub = pk.readByte();
        if (sub == -12) {
            if (s == null || s.ch == null) return new PacketResult();
            PacketResult out = new PacketResult(); out.packets.add(okPacket(P_MAP, buildMap(s.ch))); out.packets.add(okPacket(P_MAP, buildEntities(s.ch))); return out;
        }
        if (sub == -14) return new PacketResult();
        if (sub >= 0 && sub <= 8 && pk.available() >= 6) {
            pk.readByte(); int x=pk.readShort(), y=pk.readShort();
            if (s != null) { s.px=x; s.py=y; if (s.ch != null) { s.ch.tx=Math.max(0,Math.min(MAP_W-1,x/TILE)); s.ch.ty=Math.max(0,Math.min(MAP_H-1,y/TILE)); store.save(); } }
        }
        return new PacketResult();
    }

    private PacketResult hHelp() throws IOException {
        return ok(P_HELP, new W().utf("").utf("").utf("").s8(0).s8(0).bytes());
    }

    private static PacketResult ok(int pid, byte[] data) { PacketResult r=new PacketResult(); r.packets.add(okPacket(pid,data)); return r; }
    private static PacketResult error(int pid, int code, String msg) throws IOException { PacketResult r=new PacketResult(); r.packets.add(new Packet(pid,true,new W().s8(code).utf(msg).bytes())); return r; }
    private static PacketResult session(int pid, byte[] data, Session s) { PacketResult r=ok(pid,data); r.session=s; return r; }
    private static Packet okPacket(int pid, byte[] data) { return new Packet(pid,false,data); }

    private void writeResponse(DataOutputStream out, PacketList response) throws IOException {
        ByteArrayOutputStream bodyBytes=new ByteArrayOutputStream();
        DataOutputStream body=new DataOutputStream(bodyBytes);
        body.writeShort(response.packets.size());
        for (Packet p:response.packets) {
            int hdr=p.pid & 0x3fff; if (p.error) hdr|=0x4000;
            if (p.data.length>=0x7fff) { body.writeShort(hdr|0x8000); body.writeInt(p.data.length); }
            else { body.writeShort(hdr); body.writeShort(p.data.length); }
            body.write(p.data);
        }
        body.flush(); byte[] payload=bodyBytes.toByteArray();
        out.writeByte(77); out.writeByte(0); out.writeInt(payload.length); out.write(payload);
    }

    private static String readUtf(DataInputStream in) throws IOException {
        int n=in.readUnsignedShort(); byte[] b=new byte[n]; in.readFully(b); return new String(b, StandardCharsets.UTF_8);
    }

    private static int[] buildMapTiles() {
        int[] tiles=new int[MAP_W*MAP_H]; java.util.Random rnd=new java.util.Random(1234L);
        for(int y=0;y<MAP_H;y++) for(int x=0;x<MAP_W;x++) tiles[y*MAP_W+x]=rnd.nextDouble()<0.85?(1+rnd.nextInt(9)):(10+rnd.nextInt(7));
        int block=0x8000;
        for(int x=0;x<MAP_W;x++) for(int y:new int[]{0,1,MAP_H-2,MAP_H-1}) tiles[y*MAP_W+x]=17|block;
        for(int y=0;y<MAP_H;y++) for(int x:new int[]{0,1,MAP_W-2,MAP_W-1}) tiles[y*MAP_W+x]=18|block;
        int cx=MAP_W/2, cy=MAP_H/2-4;
        for(int y=0;y<MAP_H;y++) for(int x=0;x<MAP_W;x++){double dx=(x-cx)/9.0,dy=(y-cy)/5.0;if(dx*dx+dy*dy<=1.0)tiles[y*MAP_W+x]=37|block;}
        for(int x=2;x<MAP_W-2;x++) for(int y:new int[]{MAP_H-8,MAP_H-7}) tiles[y*MAP_W+x]=51+(x%3);
        return tiles;
    }

    private static byte[] statsBlock(CharData c) {
        byte[] b=new byte[50]; putLE(b,0,c.gold,4); putLE(b,4,c.exp,4); putLE(b,14,c.level,2); putLE(b,16,200,4); putLE(b,20,200,4); putLE(b,24,100,2); putLE(b,26,100,2);
        for(int off:new int[]{28,30,32,34})putLE(b,off,10,2); putLE(b,36,0,2); putLE(b,40,10,2); putLE(b,42,5,2); putLE(b,44,10,2); putLE(b,46,10,2); return b;
    }
    private static void putLE(byte[] b,int off,int v,int width){for(int i=0;i<width;i++)b[off+i]=(byte)(v>>(8*i));}

    private static byte[] buildEnter(CharData c, Session s) throws IOException {
        W w=new W(); w.utf("").s32(c.pid).s64(0).s8(0).utf(c.name).s8(c.gender).s8(c.cls).s8(0).raw(statsBlock(c)).s16(0).s32(1000).s16(0).s8(0);
        for(int i=0;i<9;i++)w.s32(-1).s8(0).s8(0).s8(0).s8(0).s8(0);
        for(int i=0;i<9;i++)w.s16(-1); for(int i=0;i<9;i++)w.s8(0); for(int i=0;i<9;i++)w.s8(0); for(int i=0;i<7;i++)w.s32(0).s8(0);
        w.s16(0); for(int i=0;i<16;i++)w.s32(-1).s8(-1); for(int i=0;i<12;i++)w.s32(-1).s8(-1).utf(""); for(int i=0;i<3;i++)w.s32(-1).s8(-1);
        w.s32(0).s16(c.tx*TILE).s16(c.ty*TILE).s32(-1).s8(0).s8(0).s32(-1).s16(0).s32(0).s16(0).s16(1).s32(0).s32(0);
        w.s16(1).s8(0).s8(0).s16(1).s16(-1).s16(-1).s16(1); w.s8(0).s8(0).s8(0).s8(0); w.s32(0).s32(0).s32(0).s32(0).s32(0).s32(0);
        w.s64(s.sid).utf(s.token).s8(0).s16(0).s16(0).s8(0).s8(0).s8(0).s8(0).s32(0).s32(0).s8(0).s8(0).s8(0).s8(0).s8(0).s8(0).s8(0).s8(0);
        return w.bytes();
    }

    private byte[] buildMap(CharData c) throws IOException {
        W w=new W(); w.s8(1).s32(1).s32(0).s16(0).s16(0).s16(0).utf("Đồng cỏ khởi đầu").s8(0).s8(0).s16(SPAWN_TY*MAP_W+SPAWN_TX).s16(0);
        for(int i=0;i<4;i++)w.s16(0).s16(0).utf(""); w.s16(0).s8(MAP_H).s8(MAP_W).s8(1); for(int t:mapTiles)w.s16(t); w.s16(0); for(int i=0;i<3;i++)w.s16(0); w.s16(0).s16(0).s8(0).s16(c.ty*MAP_W+c.tx).utf(""); return w.bytes();
    }
    private byte[] buildEntities(CharData c) throws IOException { return new W().s8(0).s8(0).s8(0).s8(0).bytes(); }

    private static void writeU16(ByteArrayOutputStream b,int v)throws IOException{b.write((v>>>8)&255);b.write(v&255);}
    private static void closeQuietly(Socket s){if(s!=null)try{s.close();}catch(Exception ignored){}}

    private static final class Session { final String token,account; final long sid=RNG.nextLong()&0x3fffffffffffffffL; Socket socket; CharData ch; int px,py; boolean inGame; Session(String t,String a,Socket s){token=t;account=a;socket=s;} }
    private static final class Packet { final int pid; final boolean error; final byte[] data; Packet(int p,boolean e,byte[] d){pid=p;error=e;data=d;} }
    private static class PacketList { final java.util.ArrayList<Packet> packets=new java.util.ArrayList<Packet>(); Session session; }
    private static final class PacketResult extends PacketList {}
    private static final class CharRef { final String account; final CharData ch; CharRef(String a,CharData c){account=a;ch=c;} }

    private static final class Account { String pwd=""; CharData[] chars=new CharData[2]; }
    private static final class CharData { String name=""; int cls,gender,c1,c2,style,pid,level=1,gold=1000,exp,map,tx=SPAWN_TX,ty=SPAWN_TY; }

    private static final class Store {
        final File file; final Map<String,Account> accounts=new ConcurrentHashMap<String,Account>(); int nextPid=1000;
        Store(File f){file=f;load();}
        synchronized Account account(String n){return accounts.get(n);}
        synchronized CharRef findChar(String name){for(Map.Entry<String,Account>e:accounts.entrySet())for(CharData c:e.getValue().chars)if(c!=null&&name.equals(c.name))return new CharRef(e.getKey(),c);return null;}
        synchronized void save(){try{JSONObject root=new JSONObject();root.put("next_pid",nextPid);JSONArray aa=new JSONArray();for(Map.Entry<String,Account>e:accounts.entrySet()){JSONObject a=new JSONObject();a.put("name",e.getKey());a.put("pwd",e.getValue().pwd);JSONArray cc=new JSONArray();for(CharData c:e.getValue().chars){if(c==null){cc.put(JSONObject.NULL);continue;}JSONObject o=new JSONObject();o.put("name",c.name).put("cls",c.cls).put("gender",c.gender).put("c1",c.c1).put("c2",c.c2).put("style",c.style).put("pid",c.pid).put("level",c.level).put("gold",c.gold).put("exp",c.exp).put("map",c.map).put("tx",c.tx).put("ty",c.ty);cc.put(o);}a.put("chars",cc);aa.put(a);}root.put("accounts",aa);File tmp=new File(file.getParentFile(),file.getName()+".tmp");FileOutputStream fos=new FileOutputStream(tmp);fos.write(root.toString().getBytes(StandardCharsets.UTF_8));fos.close();if(file.exists())file.delete();tmp.renameTo(file);}catch(Exception e){e.printStackTrace();}}
        void load(){if(!file.exists())return;try{byte[]b=readAll(file);JSONObject root=new JSONObject(new String(b,StandardCharsets.UTF_8));nextPid=root.optInt("next_pid",1000);JSONArray aa=root.optJSONArray("accounts");if(aa==null)return;for(int i=0;i<aa.length();i++){JSONObject a=aa.getJSONObject(i);Account ac=new Account();ac.pwd=a.optString("pwd","");JSONArray cc=a.optJSONArray("chars");if(cc!=null)for(int j=0;j<Math.min(2,cc.length());j++){if(cc.isNull(j))continue;JSONObject o=cc.getJSONObject(j);CharData c=new CharData();c.name=o.optString("name","");c.cls=o.optInt("cls");c.gender=o.optInt("gender");c.c1=o.optInt("c1");c.c2=o.optInt("c2");c.style=o.optInt("style");c.pid=o.optInt("pid");c.level=o.optInt("level",1);c.gold=o.optInt("gold",1000);c.exp=o.optInt("exp",0);c.map=o.optInt("map",0);c.tx=o.optInt("tx",SPAWN_TX);c.ty=o.optInt("ty",SPAWN_TY);ac.chars[j]=c;}accounts.put(a.optString("name"),ac);}}catch(Exception e){e.printStackTrace();}}
        private static byte[] readAll(File f)throws IOException{FileInputStream in=new FileInputStream(f);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[]x=new byte[4096];int n;while((n=in.read(x))!=-1)b.write(x,0,n);in.close();return b.toByteArray();}
    }

    private static final class W {
        final ByteArrayOutputStream b=new ByteArrayOutputStream(); final DataOutputStream o=new DataOutputStream(b);
        W s8(int v)throws IOException{o.writeByte(v);return this;} W s16(int v)throws IOException{o.writeShort(v);return this;} W s32(int v)throws IOException{o.writeInt(v);return this;} W s64(long v)throws IOException{o.writeLong(v);return this;}
        W utf(String s)throws IOException{byte[]d=s.getBytes(StandardCharsets.UTF_8);o.writeShort(d.length);o.write(d);return this;} W raw(byte[]d)throws IOException{o.write(d);return this;} byte[] bytes()throws IOException{o.flush();return b.toByteArray();}
    }
}
