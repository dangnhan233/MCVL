package com.mcvl.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.DisplayHost;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;

/**
 * Android host for the J2ME display. It owns the off-screen buffer the game
 * renders into, blits it to the screen and translates touch input into the
 * MIDP key codes the game expects (including a virtual game pad).
 */
public class GameView extends View implements DisplayHost {

    // ---- MIDP key codes ------------------------------------------------------
    private static final int KEY_UP = -1;
    private static final int KEY_DOWN = -2;
    private static final int KEY_LEFT = -3;
    private static final int KEY_RIGHT = -4;
    private static final int KEY_FIRE = -5;
    private static final int KEY_GAME_A = -6;
    private static final int KEY_GAME_B = -7;

    private final int logicalW;
    private final int logicalH;

    private final Bitmap gameBitmap;
    private final RectF destRect = new RectF();

    private volatile Displayable current;
    private volatile boolean repaintPending;

    private final Paint blitPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint padFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint padStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint padText = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final List<PadButton> buttons = new ArrayList<PadButton>();
    private final Map<Integer, PadButton> activePointers = new HashMap<Integer, PadButton>();

    public GameView(Context context) {
        super(context);
        this.logicalW = Display.getScreenWidth();
        this.logicalH = Display.getScreenHeight();
        this.gameBitmap = Bitmap.createBitmap(logicalW, logicalH, Bitmap.Config.ARGB_8888);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setKeepScreenOn(true);

        padFill.setColor(Color.argb(90, 255, 255, 255));
        padStroke.setColor(Color.argb(160, 0, 0, 0));
        padStroke.setStyle(Paint.Style.STROKE);
        padStroke.setStrokeWidth(2f);
        padText.setColor(Color.argb(220, 255, 255, 255));
        padText.setTextAlign(Paint.Align.CENTER);
    }

    // ------------------------------------------------------------ DisplayHost

    @Override
    public void onDisplayableChanged(Displayable d) {
        this.current = d;
        postInvalidateOnAnimation();
    }

    @Override
    public void onRepaintRequested() {
        if (!repaintPending) {
            repaintPending = true;
            postInvalidateOnAnimation();
        }
    }

    @Override
    public void onServiceRepaints() {
        // The game only uses repaint(); keep this non-blocking to avoid deadlock.
        onRepaintRequested();
    }

    @Override
    public void onShowAlert(final Alert alert, final Displayable next) {
        if (alert != null && alert.getTitle() != null) {
            post(new Runnable() {
                public void run() {
                    Toast.makeText(getContext(), alert.getTitle(), Toast.LENGTH_SHORT).show();
                }
            });
        }
        if (next != null) {
            Display.getDisplay(null).setCurrent(next);
        }
    }

    @Override
    public int getScreenWidth() {
        return logicalW;
    }

    @Override
    public int getScreenHeight() {
        return logicalH;
    }

    // ------------------------------------------------------------------ render

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        repaintPending = false;

        Displayable d = current;
        if (d instanceof javax.microedition.lcdui.Canvas) {
            Canvas androidCanvas = new Canvas(gameBitmap);
            Graphics g = new Graphics(androidCanvas, logicalW, logicalH, null);
            ((javax.microedition.lcdui.Canvas) d).__paint(g);
        }

        computeDestRect();
        canvas.drawBitmap(gameBitmap, null, destRect, blitPaint);
        drawGamepad(canvas);
    }

    private void computeDestRect() {
        float w = getWidth();
        float h = getHeight();
        float scale = Math.min(w / logicalW, h / logicalH);
        float dw = logicalW * scale;
        float dh = logicalH * scale;
        float left = (w - dw) / 2f;
        float top = (h - dh) / 2f;
        destRect.set(left, top, left + dw, top + dh);
    }

    // ---------------------------------------------------------------- gamepad

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        buildGamepad(w, h);
    }

    private void buildGamepad(int w, int h) {
        buttons.clear();
        float unit = Math.min(w, h) / 10f;
        float margin = unit * 0.4f;

        // --- D-pad (bottom-left) ---
        float cx = margin + unit * 2f;
        float cy = h - margin - unit * 2f;
        float c = unit * 1.1f;
        addButton(cx - c / 2, cy - c * 1.5f, cx + c / 2, cy - c * 0.5f, KEY_UP, "\u25B2");
        addButton(cx - c / 2, cy + c * 0.5f, cx + c / 2, cy + c * 1.5f, KEY_DOWN, "\u25BC");
        addButton(cx - c * 1.5f, cy - c / 2, cx - c * 0.5f, cy + c / 2, KEY_LEFT, "\u25C0");
        addButton(cx + c * 0.5f, cy - c / 2, cx + c * 1.5f, cy + c / 2, KEY_RIGHT, "\u25B6");
        addButton(cx - c / 2, cy - c / 2, cx + c / 2, cy + c / 2, KEY_FIRE, "OK");

        // --- Numeric keypad (bottom-right) ---
        float k = unit * 0.95f;
        float gridW = 3 * k;
        float gridH = 4 * k;
        float gx = w - margin - gridW;
        float gy = h - margin - gridH;
        String[] labels = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"};
        int[] keys = {49, 50, 51, 52, 53, 54, 55, 56, 57, 42, 48, 35};
        for (int i = 0; i < labels.length; i++) {
            int col = i % 3;
            int row = i / 3;
            float bx = gx + col * k;
            float by = gy + row * k;
            addButton(bx, by, bx + k, by + k, keys[i], labels[i]);
        }

        // --- Soft keys (top corners) ---
        float s = unit * 1.3f;
        addButton(margin, margin, margin + s, margin + s, KEY_GAME_A, "A");
        addButton(w - margin - s, margin, w - margin, margin + s, KEY_GAME_B, "B");
    }

    private void addButton(float l, float t, float r, float b, int key, String label) {
        buttons.add(new PadButton(new RectF(l, t, r, b), key, label));
    }

    private void drawGamepad(Canvas canvas) {
        for (PadButton btn : buttons) {
            padFill.setAlpha(btn.pressed ? 160 : 80);
            canvas.drawRoundRect(btn.rect, 10f, 10f, padFill);
            canvas.drawRoundRect(btn.rect, 10f, 10f, padStroke);
            padText.setTextSize(btn.rect.height() * 0.5f);
            float cx = btn.rect.centerX();
            float cy = btn.rect.centerY() - (padText.descent() + padText.ascent()) / 2f;
            canvas.drawText(btn.label, cx, cy, padText);
        }
    }

    private PadButton hitTest(float x, float y) {
        for (PadButton btn : buttons) {
            if (btn.rect.contains(x, y)) {
                return btn;
            }
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int idx = event.getActionIndex();
                int id = event.getPointerId(idx);
                PadButton btn = hitTest(event.getX(idx), event.getY(idx));
                if (btn != null) {
                    activePointers.put(id, btn);
                    press(btn);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int id = event.getPointerId(i);
                    PadButton current = activePointers.get(id);
                    PadButton hit = hitTest(event.getX(i), event.getY(i));
                    if (hit != current) {
                        if (current != null) {
                            release(current);
                            activePointers.remove(id);
                        }
                        if (hit != null) {
                            activePointers.put(id, hit);
                            press(hit);
                        }
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int idx = event.getActionIndex();
                int id = event.getPointerId(idx);
                PadButton btn = activePointers.remove(id);
                if (btn != null) {
                    release(btn);
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL: {
                for (PadButton btn : activePointers.values()) {
                    release(btn);
                }
                activePointers.clear();
                return true;
            }
            default:
                return super.onTouchEvent(event);
        }
    }

    private void press(PadButton btn) {
        btn.pressed = true;
        Displayable d = current;
        if (d instanceof javax.microedition.lcdui.Canvas) {
            ((javax.microedition.lcdui.Canvas) d).__keyPressed(btn.key);
        }
        invalidate();
    }

    private void release(PadButton btn) {
        btn.pressed = false;
        Displayable d = current;
        if (d instanceof javax.microedition.lcdui.Canvas) {
            ((javax.microedition.lcdui.Canvas) d).__keyReleased(btn.key);
        }
        invalidate();
    }

    /** A single virtual button. */
    private static final class PadButton {
        final RectF rect;
        final int key;
        final String label;
        boolean pressed;

        PadButton(RectF rect, int key, String label) {
            this.rect = rect;
            this.key = key;
            this.label = label;
        }
    }
}
