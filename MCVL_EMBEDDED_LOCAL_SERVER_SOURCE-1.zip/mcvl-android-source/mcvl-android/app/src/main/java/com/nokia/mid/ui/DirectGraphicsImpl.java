package com.nokia.mid.ui;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/**
 * Implementation of {@link DirectGraphics} backed by the J2ME compatibility
 * {@link Graphics}. Only the operations the ported game relies on are fully
 * functional; the remaining methods degrade gracefully.
 */
final class DirectGraphicsImpl implements DirectGraphics {

    private final Graphics g;
    private int alpha = 255;

    DirectGraphicsImpl(Graphics g) {
        this.g = g;
    }

    public void setARGBColor(int argbColor) {
        this.alpha = (argbColor >>> 24) & 0xFF;
        this.g.setColor(argbColor & 0x00FFFFFF);
    }

    public int getAlphaComponent() {
        return alpha;
    }

    public void drawImage(Image img, int x, int y, int anchor, int manipulation) {
        // Manipulation (flip/rotate) is not required by the game; draw normally.
        this.g.drawImage(img, x, y, anchor);
    }

    public void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int argbColor) {
        int saved = this.g.getColor();
        this.g.setColor(argbColor & 0x00FFFFFF);
        this.g.drawLine(x1, y1, x2, y2);
        this.g.drawLine(x2, y2, x3, y3);
        this.g.drawLine(x3, y3, x1, y1);
        this.g.setColor(saved);
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int argbColor) {
        int saved = this.g.getColor();
        this.g.setColor(argbColor & 0x00FFFFFF);
        this.g.fillTriangle(x1, y1, x2, y2, x3, y3);
        this.g.setColor(saved);
    }

    public void drawPolygon(int[] xPoints, int xOffset, int[] yPoints, int yOffset, int nPoints, int argbColor) {
        int saved = this.g.getColor();
        this.g.setColor(argbColor & 0x00FFFFFF);
        for (int i = 0; i < nPoints; i++) {
            int j = (i + 1) % nPoints;
            this.g.drawLine(xPoints[xOffset + i], yPoints[yOffset + i],
                    xPoints[xOffset + j], yPoints[yOffset + j]);
        }
        this.g.setColor(saved);
    }

    public void fillPolygon(int[] xPoints, int xOffset, int[] yPoints, int yOffset, int nPoints, int argbColor) {
        int saved = this.g.getColor();
        this.g.setColor(argbColor & 0x00FFFFFF);
        // Fan triangulation.
        for (int i = 1; i < nPoints - 1; i++) {
            this.g.fillTriangle(xPoints[xOffset], yPoints[yOffset],
                    xPoints[xOffset + i], yPoints[yOffset + i],
                    xPoints[xOffset + i + 1], yPoints[yOffset + i + 1]);
        }
        this.g.setColor(saved);
    }
}
