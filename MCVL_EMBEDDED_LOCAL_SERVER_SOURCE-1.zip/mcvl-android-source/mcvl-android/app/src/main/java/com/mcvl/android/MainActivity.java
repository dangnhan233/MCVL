package com.mcvl.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;

/**
 * Launches the ported MIDlet ({@code SFMIDlet}) inside the Android host view.
 */
public class MainActivity extends Activity {

    /** Logical resolution the game was designed for (Nokia S40 class). */
    private static final int LOGICAL_WIDTH = 240;
    private static final int LOGICAL_HEIGHT = 320;

    private GameView gameView;
    private MIDlet midlet;
    private boolean started;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Display.setScreenSize(LOGICAL_WIDTH, LOGICAL_HEIGHT);

        gameView = new GameView(this);
        Display.setHost(gameView);
        setContentView(gameView);

        startMidlet();
    }

    private void startMidlet() {
        try {
            Class<?> midletClass = Class.forName("SFMIDlet");
            midlet = (MIDlet) midletClass.getDeclaredConstructor().newInstance();
            midlet.__startApp();
            started = true;
        } catch (Throwable t) {
            Toast.makeText(this, "Không khởi động được game: " + t, Toast.LENGTH_LONG).show();
            t.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (started && midlet != null) {
            midlet.__startApp();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (midlet != null) {
            midlet.__pauseApp();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (midlet != null) {
            midlet.__destroyApp(true);
        }
    }
}
