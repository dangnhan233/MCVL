package com.mcvl.game;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.lcdui.Assets;

/**
 * Resource helper used by the ported game code.
 *
 * <p>The original MIDlet loaded its data with
 * {@code getClass().getResourceAsStream("/img/...")}. During the port those call
 * sites were rewritten to {@code Res.open("/img/...")}. This class forwards the
 * request to the Android {@link Assets} bridge, which reads from
 * {@code app/src/main/assets}.</p>
 *
 * <p>When the asset is missing a non-null empty stream is returned so that the
 * game's defensive {@code try/catch} blocks behave exactly like they did on a
 * device where a resource was absent.</p>
 */
public final class Res {

    private Res() {
    }

    /**
     * Opens a packaged resource.
     *
     * @param path absolute path inside the original JAR, e.g. {@code "/img/001.yy"}
     * @return a stream over the resource, never {@code null}
     */
    public static InputStream open(String path) {
        InputStream in = Assets.open(path);
        if (in == null) {
            // Keep the legacy contract: callers assume a usable stream.
            return new ByteArrayInputStream(new byte[0]);
        }
        return in;
    }

    /** Convenience overload for classpath-style lookups. */
    public static InputStream open(String path, String ignored) throws IOException {
        return open(path);
    }
}
