extends Node2D
## Nạp layout.json của một map: dựng TileMapLayer + các vật thể (Sprite2D, gốc ở chân vật thể).
## Dùng: gắn script vào node gốc của maps/map_XX/map.tscn (đã gắn sẵn).
@export var map_id: int = 1

func _ready() -> void:
	var dir := "res://maps/map_%02d" % map_id
	var f := FileAccess.open(dir + "/layout.json", FileAccess.READ)
	var data: Dictionary = JSON.parse_string(f.get_as_text())
	var ground: TileMapLayer = $Ground
	var w: int = data["width"]
	var arr: Array = data["ground"]
	for i in arr.size():
		ground.set_cell(Vector2i(i % w, i / w), 0, Vector2i(int(arr[i]), 0))
	var holder: Node2D = $Objects
	for o in data["objects"]:
		var tex: Texture2D = load(dir + "/objects/" + o["file"])
		var s := Sprite2D.new()
		s.texture = tex
		s.centered = false
		s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height())
		s.position = Vector2(o["x"], o["y"])
		holder.add_child(s)
	# Ô chặn đường (nước): data["blocked"] cùng kích thước với data["ground"].
